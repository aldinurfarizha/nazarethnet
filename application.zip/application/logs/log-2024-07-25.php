<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-07-25 06:15:27 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-25 06:15:27 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-25 06:15:27 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-25 06:16:39 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-25 06:16:39 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-25 06:16:39 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-25 06:16:41 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-25 06:16:41 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-25 06:16:41 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-25 06:16:41 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-25 06:16:46 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-25 06:16:46 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-25 06:16:46 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-25 06:16:46 --> Severity: Warning --> Undefined variable $class_id /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/fancy.php 96
ERROR - 2024-07-25 06:16:46 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-25 06:16:46 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-25 06:16:46 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-25 06:16:46 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-25 06:16:46 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-25 06:16:46 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-25 06:16:46 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-25 06:16:48 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-25 06:16:48 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-25 06:16:48 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-25 06:16:48 --> Severity: Warning --> Undefined variable $class_id /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/fancy.php 96
ERROR - 2024-07-25 06:16:48 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-25 06:16:50 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-25 06:16:50 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-25 06:16:50 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-25 06:16:50 --> Severity: Warning --> Undefined variable $class_id /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/fancy.php 96
ERROR - 2024-07-25 06:16:50 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-25 06:17:00 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-25 06:17:00 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-25 06:17:00 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-25 06:17:03 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-25 06:17:03 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-25 06:17:03 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-25 06:17:03 --> Severity: Warning --> Attempt to read property "name" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-25 06:17:03 --> Severity: Warning --> Attempt to read property "name" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-25 06:17:03 --> Severity: Warning --> Attempt to read property "name" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-25 06:17:03 --> Severity: Warning --> Attempt to read property "name" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-25 06:17:03 --> Severity: Warning --> Attempt to read property "name" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-25 06:17:03 --> Severity: Warning --> Attempt to read property "name" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-25 06:17:03 --> Severity: Warning --> Attempt to read property "name" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-25 06:17:03 --> Severity: Warning --> Attempt to read property "name" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-25 06:17:03 --> Severity: Warning --> Attempt to read property "name" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-25 06:17:03 --> Severity: Warning --> Attempt to read property "name" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-25 06:17:03 --> Severity: Warning --> Attempt to read property "name" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-25 06:17:03 --> Severity: Warning --> Attempt to read property "name" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-25 06:17:03 --> Severity: Warning --> Attempt to read property "name" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-25 06:17:03 --> Severity: Warning --> Attempt to read property "name" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-25 06:17:03 --> Severity: Warning --> Attempt to read property "name" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-25 06:17:03 --> Severity: Warning --> Attempt to read property "name" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-25 06:17:03 --> Severity: Warning --> Attempt to read property "name" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-25 06:17:05 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-25 06:17:05 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-25 06:17:05 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-25 06:17:05 --> Severity: Warning --> Attempt to read property "name" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/student_portal.php 74
ERROR - 2024-07-25 06:17:05 --> Severity: Warning --> Attempt to read property "first_name" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/student_portal.php 98
ERROR - 2024-07-25 06:17:05 --> Severity: Warning --> Attempt to read property "last_name" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/student_portal.php 98
ERROR - 2024-07-25 06:17:05 --> Severity: Warning --> Attempt to read property "route_name" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/student_portal.php 115
ERROR - 2024-07-25 06:17:08 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-25 06:17:08 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-25 06:17:08 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-25 06:17:42 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-25 06:17:42 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-25 06:17:42 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-25 06:17:44 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-25 06:17:44 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-25 06:17:44 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-25 06:17:47 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-25 06:17:47 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-25 06:17:47 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-25 06:17:49 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-25 06:17:49 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-25 06:17:49 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-25 06:17:50 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-25 06:17:51 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-25 06:17:51 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-25 06:17:51 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-25 06:17:51 --> Severity: Warning --> Undefined variable $class_id /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/fancy.php 96
ERROR - 2024-07-25 06:17:51 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-25 06:17:51 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-25 06:17:51 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-25 06:17:51 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-25 06:17:51 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-25 06:17:51 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-25 06:17:51 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-25 06:17:54 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-25 06:17:54 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-25 06:17:54 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-25 06:17:54 --> Severity: Warning --> Undefined variable $class_id /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/fancy.php 96
ERROR - 2024-07-25 06:17:54 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-25 06:18:05 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-25 06:18:05 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-25 06:18:05 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-25 06:18:06 --> Severity: Warning --> Undefined variable $class_id /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/fancy.php 96
ERROR - 2024-07-25 06:18:06 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-25 06:21:18 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-25 06:21:18 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-25 06:21:18 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-25 06:21:18 --> Severity: Warning --> Undefined variable $class_id /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/fancy.php 96
ERROR - 2024-07-25 06:21:18 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-25 06:21:27 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-25 06:21:27 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-25 06:21:27 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-25 06:21:27 --> Severity: Warning --> Undefined variable $class_id /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/fancy.php 96
ERROR - 2024-07-25 06:21:27 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-25 06:21:30 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-25 06:21:30 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-25 06:21:30 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-25 06:21:30 --> Severity: Warning --> Undefined variable $class_id /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/fancy.php 96
ERROR - 2024-07-25 06:21:30 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-25 08:15:09 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-25 08:15:09 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-25 08:15:09 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-25 08:15:10 --> Severity: Warning --> Undefined variable $class_id /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/fancy.php 96
ERROR - 2024-07-25 08:15:10 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-25 08:29:43 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-25 08:29:43 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-25 08:29:43 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-25 08:29:43 --> Severity: Warning --> Undefined variable $class_id /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/fancy.php 96
ERROR - 2024-07-25 08:29:43 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-25 08:56:34 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-25 08:56:34 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-25 08:56:34 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-25 08:56:34 --> Severity: Warning --> Undefined variable $class_id /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/fancy.php 96
ERROR - 2024-07-25 08:56:34 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-25 09:05:03 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-25 09:05:03 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-25 09:05:03 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-25 09:05:03 --> Severity: Warning --> Undefined variable $class_id /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/fancy.php 96
ERROR - 2024-07-25 09:05:03 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-25 09:17:26 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-25 09:17:26 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-25 09:17:26 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-25 09:17:26 --> Severity: Warning --> Undefined variable $class_id /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/fancy.php 96
ERROR - 2024-07-25 09:17:26 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-25 09:17:48 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-25 09:17:48 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-25 09:17:48 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-25 09:17:48 --> Severity: Warning --> Undefined variable $class_id /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/fancy.php 96
ERROR - 2024-07-25 09:17:48 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-25 09:18:33 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-25 09:18:33 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-25 09:18:33 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-25 09:18:33 --> Severity: Warning --> Undefined variable $class_id /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/fancy.php 96
ERROR - 2024-07-25 09:18:33 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-25 09:18:38 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-25 09:18:38 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-25 09:18:38 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-25 09:18:38 --> Severity: Warning --> Undefined variable $class_id /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/fancy.php 96
ERROR - 2024-07-25 09:18:38 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-25 09:18:45 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-25 09:18:45 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-25 09:18:45 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-25 09:18:45 --> Severity: Warning --> Undefined variable $class_id /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/fancy.php 96
ERROR - 2024-07-25 09:18:45 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-25 09:21:34 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-25 09:21:34 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-25 09:21:35 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-25 09:21:35 --> Severity: Warning --> Undefined variable $class_id /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/fancy.php 96
ERROR - 2024-07-25 09:21:35 --> Severity: error --> Exception: Unsupported operand types: int + string /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/upload_marks.php 144
ERROR - 2024-07-25 09:21:35 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-25 09:21:39 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-25 09:21:39 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-25 09:21:39 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-25 09:21:39 --> Severity: Warning --> Undefined variable $class_id /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/fancy.php 96
ERROR - 2024-07-25 09:21:39 --> Severity: error --> Exception: Unsupported operand types: int + string /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/upload_marks.php 144
ERROR - 2024-07-25 09:21:39 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-25 09:21:40 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-25 09:21:40 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-25 09:21:40 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-25 09:21:40 --> Severity: Warning --> Undefined variable $class_id /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/fancy.php 96
ERROR - 2024-07-25 09:21:40 --> Severity: error --> Exception: Unsupported operand types: int + string /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/upload_marks.php 144
ERROR - 2024-07-25 09:21:40 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-25 09:21:40 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-25 09:21:45 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-25 09:21:45 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-25 09:21:45 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-25 09:21:45 --> Severity: Warning --> Undefined variable $class_id /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/fancy.php 96
ERROR - 2024-07-25 09:21:46 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-25 09:21:47 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-25 09:21:47 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-25 09:21:47 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-25 09:21:47 --> Severity: Warning --> Undefined variable $class_id /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/fancy.php 96
ERROR - 2024-07-25 09:21:47 --> Severity: error --> Exception: Unsupported operand types: int + string /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/upload_marks.php 144
ERROR - 2024-07-25 09:21:47 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-25 09:22:18 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-25 09:22:18 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-25 09:22:18 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-25 09:22:20 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-25 09:22:20 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-25 09:22:20 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-25 09:22:20 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-25 09:22:22 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-25 09:22:22 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-25 09:22:22 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-25 09:22:22 --> Severity: Warning --> Undefined variable $class_id /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/fancy.php 96
ERROR - 2024-07-25 09:22:22 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-25 09:22:22 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-25 09:22:22 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-25 09:22:22 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-25 09:22:22 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-25 09:22:22 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-25 09:22:22 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-25 09:22:23 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-25 09:22:23 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-25 09:22:23 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-25 09:22:24 --> Severity: Warning --> Undefined variable $class_id /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/fancy.php 96
ERROR - 2024-07-25 09:22:24 --> Severity: error --> Exception: Unsupported operand types: int + string /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/upload_marks.php 144
ERROR - 2024-07-25 09:22:24 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-25 09:22:26 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-25 09:22:26 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-25 09:22:26 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-25 09:22:26 --> Severity: Warning --> Undefined variable $class_id /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/fancy.php 96
ERROR - 2024-07-25 09:22:26 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-25 09:22:30 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-25 09:22:30 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-25 09:22:30 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-25 09:22:30 --> Severity: Warning --> Undefined variable $class_id /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/fancy.php 96
ERROR - 2024-07-25 09:22:30 --> Severity: error --> Exception: Unsupported operand types: int + string /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/upload_marks.php 144
ERROR - 2024-07-25 09:22:30 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-25 09:23:19 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-25 09:23:19 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-25 09:23:19 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-25 09:23:19 --> Severity: Warning --> Undefined variable $class_id /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/fancy.php 96
ERROR - 2024-07-25 09:23:19 --> Severity: error --> Exception: Unsupported operand types: int + string /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/upload_marks.php 144
ERROR - 2024-07-25 09:23:20 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-25 09:24:20 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-25 09:24:20 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-25 09:24:20 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-25 09:24:20 --> Severity: Warning --> Undefined variable $class_id /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/fancy.php 96
ERROR - 2024-07-25 09:24:20 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-25 09:24:32 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-25 09:24:32 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-25 09:24:32 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-25 09:24:32 --> Severity: Warning --> Undefined variable $class_id /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/fancy.php 96
ERROR - 2024-07-25 09:24:32 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-25 09:24:42 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-25 09:24:42 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-25 09:24:42 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-25 09:24:42 --> Severity: Warning --> Undefined variable $class_id /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/fancy.php 96
ERROR - 2024-07-25 09:24:42 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-25 09:24:47 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-25 09:24:47 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-25 09:24:47 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-25 09:24:47 --> Severity: Warning --> Undefined variable $class_id /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/fancy.php 96
ERROR - 2024-07-25 09:24:47 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-25 09:24:54 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-25 09:24:54 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-25 09:24:54 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-25 09:24:54 --> Severity: Warning --> Undefined variable $class_id /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/fancy.php 96
ERROR - 2024-07-25 09:24:54 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-25 09:29:33 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-25 09:29:33 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-25 09:29:33 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-25 09:29:33 --> Severity: Warning --> Undefined variable $class_id /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/fancy.php 96
ERROR - 2024-07-25 09:29:33 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-25 09:29:37 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-25 09:29:37 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-25 09:29:37 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-25 09:29:37 --> Severity: Warning --> Undefined variable $class_id /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/fancy.php 96
ERROR - 2024-07-25 09:29:37 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-25 09:36:32 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-25 09:36:32 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-25 09:36:32 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-25 09:36:32 --> Severity: Warning --> Undefined variable $class_id /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/fancy.php 96
ERROR - 2024-07-25 09:38:16 --> Severity: Warning --> Undefined variable $ci /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/helpers/global_helper.php 340
ERROR - 2024-07-25 09:38:16 --> Severity: Warning --> Attempt to read property "db" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/helpers/global_helper.php 340
ERROR - 2024-07-25 09:38:16 --> Severity: error --> Exception: Call to a member function insert() on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/helpers/global_helper.php 340
ERROR - 2024-07-25 09:38:25 --> Severity: Warning --> Undefined variable $ci /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/helpers/global_helper.php 340
ERROR - 2024-07-25 09:38:25 --> Severity: Warning --> Attempt to read property "db" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/helpers/global_helper.php 340
ERROR - 2024-07-25 09:38:25 --> Severity: error --> Exception: Call to a member function insert() on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/helpers/global_helper.php 340
ERROR - 2024-07-25 09:38:37 --> Severity: Warning --> Undefined variable $ci /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/helpers/global_helper.php 340
ERROR - 2024-07-25 09:38:37 --> Severity: Warning --> Attempt to read property "db" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/helpers/global_helper.php 340
ERROR - 2024-07-25 09:38:37 --> Severity: error --> Exception: Call to a member function insert() on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/helpers/global_helper.php 340
ERROR - 2024-07-25 09:40:30 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-25 09:40:30 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-25 09:40:30 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-25 09:40:30 --> Severity: Warning --> Undefined variable $class_id /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/fancy.php 96
ERROR - 2024-07-25 09:40:30 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-25 09:40:30 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-25 09:40:37 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-25 09:40:37 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-25 09:40:37 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-25 09:41:33 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-25 09:41:34 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-25 09:41:34 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-25 09:41:40 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-25 09:41:40 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-25 09:41:40 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-25 09:41:41 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-25 09:41:41 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-25 09:41:41 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-25 09:41:43 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-25 09:41:43 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-25 09:41:43 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-25 09:41:43 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-25 09:41:45 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-25 09:41:45 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-25 09:41:45 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-25 09:41:45 --> Severity: Warning --> Undefined variable $class_id /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/fancy.php 96
ERROR - 2024-07-25 09:41:45 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-25 09:41:45 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-25 09:41:45 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-25 09:41:45 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-25 09:41:45 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-25 09:41:45 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-25 09:41:45 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-25 09:41:45 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-25 09:41:45 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-25 09:41:59 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-25 09:41:59 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-25 09:41:59 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-25 09:41:59 --> Severity: Warning --> Undefined variable $class_id /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/fancy.php 96
ERROR - 2024-07-25 09:41:59 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-25 09:42:00 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-25 09:42:00 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-25 09:42:00 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-25 09:42:00 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-25 09:42:00 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-25 09:42:00 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-25 09:42:01 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-25 09:42:01 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-25 09:42:01 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-25 09:42:01 --> Severity: Warning --> Undefined variable $class_id /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/fancy.php 96
ERROR - 2024-07-25 09:42:01 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-25 09:43:17 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-25 09:43:17 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-25 09:43:17 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-25 09:43:17 --> Severity: Warning --> Undefined variable $class_id /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/fancy.php 96
ERROR - 2024-07-25 09:43:17 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-25 09:43:23 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-25 09:43:23 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-25 09:43:23 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-25 09:43:23 --> Severity: Warning --> Undefined variable $class_id /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/fancy.php 96
ERROR - 2024-07-25 09:43:23 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-25 09:43:28 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-25 09:43:28 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-25 09:43:28 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-25 09:43:28 --> Severity: Warning --> Undefined variable $class_id /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/fancy.php 96
ERROR - 2024-07-25 09:43:28 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-25 09:46:03 --> Severity: Warning --> Undefined variable $ci /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/helpers/global_helper.php 311
ERROR - 2024-07-25 09:46:03 --> Severity: Warning --> Attempt to read property "db" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/helpers/global_helper.php 311
ERROR - 2024-07-25 09:46:03 --> Severity: error --> Exception: Call to a member function insert() on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/helpers/global_helper.php 311
ERROR - 2024-07-25 09:46:27 --> Severity: Warning --> Undefined variable $ci /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/helpers/global_helper.php 311
ERROR - 2024-07-25 09:46:27 --> Severity: Warning --> Attempt to read property "db" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/helpers/global_helper.php 311
ERROR - 2024-07-25 09:46:27 --> Severity: error --> Exception: Call to a member function insert() on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/helpers/global_helper.php 311
ERROR - 2024-07-25 09:47:28 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-25 09:47:28 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-25 09:47:28 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-25 09:47:28 --> Severity: Warning --> Undefined variable $class_id /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/fancy.php 96
ERROR - 2024-07-25 09:47:28 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-25 09:48:59 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-25 09:48:59 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-25 09:48:59 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-25 09:48:59 --> Severity: Warning --> Undefined variable $class_id /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/fancy.php 96
ERROR - 2024-07-25 09:48:59 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-25 09:49:16 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-25 09:49:16 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-25 09:49:16 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-25 09:49:16 --> Severity: Warning --> Undefined variable $class_id /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/fancy.php 96
ERROR - 2024-07-25 09:49:16 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-25 09:49:19 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-25 09:49:19 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-25 09:49:20 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-25 09:49:20 --> Severity: Warning --> Undefined variable $class_id /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/fancy.php 96
ERROR - 2024-07-25 09:49:20 --> 404 Page Not Found: Public/uploads
