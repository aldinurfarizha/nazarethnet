<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-06-26 04:21:39 --> 404 Page Not Found: Assets/js
ERROR - 2024-06-26 08:39:41 --> 404 Page Not Found: Theme/zero
ERROR - 2024-06-26 08:50:14 --> 404 Page Not Found: Js/ckeditor
ERROR - 2024-06-26 09:11:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2024-06-26 09:35:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-06-26 10:54:02 --> 404 Page Not Found: Public/style
ERROR - 2024-06-26 11:20:23 --> 404 Page Not Found: Uploads/e0be4208a38304de945062dba9b202adlogopeque%C3%B1ito-02.jpg
ERROR - 2024-06-26 11:33:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2024-06-26 14:58:23 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Bad Request"
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-06-26 14:58:32 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Bad Request"
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-06-26 14:58:36 --> 404 Page Not Found: Public/uploads
ERROR - 2024-06-26 14:58:36 --> 404 Page Not Found: Public/uploads
ERROR - 2024-06-26 14:58:36 --> 404 Page Not Found: Public/uploads
ERROR - 2024-06-26 14:58:37 --> 404 Page Not Found: Public/uploads
ERROR - 2024-06-26 14:58:59 --> 404 Page Not Found: Public/uploads
ERROR - 2024-06-26 14:59:10 --> 404 Page Not Found: Public/uploads
ERROR - 2024-06-26 16:56:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-06-26 19:52:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2024-06-26 19:55:03 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Bad Request"
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-06-26 19:55:05 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Bad Request"
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-06-26 19:55:25 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Bad Request"
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-06-26 19:55:27 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Bad Request"
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-06-26 19:55:37 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Bad Request"
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-06-26 19:55:39 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Bad Request"
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-06-26 19:56:49 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Bad Request"
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-06-26 19:57:07 --> 404 Page Not Found: Public/uploads
ERROR - 2024-06-26 19:57:53 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Bad Request"
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-06-26 19:58:16 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Bad Request"
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-06-26 21:53:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2024-06-26 22:06:40 --> 404 Page Not Found: Server/index
ERROR - 2024-06-26 22:06:41 --> 404 Page Not Found: Vscode/sftp.json
ERROR - 2024-06-26 22:06:41 --> 404 Page Not Found: Php-cgi/php-cgi.exe
ERROR - 2024-06-26 22:06:41 --> 404 Page Not Found: Debug/default
ERROR - 2024-06-26 22:06:41 --> 404 Page Not Found: Server/index
ERROR - 2024-06-26 22:06:41 --> 404 Page Not Found: V2/_catalog
ERROR - 2024-06-26 22:06:42 --> 404 Page Not Found: Vscode/sftp.json
ERROR - 2024-06-26 22:06:42 --> 404 Page Not Found: Ecp/Current
ERROR - 2024-06-26 22:06:42 --> 404 Page Not Found: Server-status/index
ERROR - 2024-06-26 22:06:42 --> 404 Page Not Found: Loginaction/index
ERROR - 2024-06-26 22:06:43 --> 404 Page Not Found: Debug/default
ERROR - 2024-06-26 22:06:43 --> 404 Page Not Found: _all_dbs/index
ERROR - 2024-06-26 22:06:43 --> 404 Page Not Found: DS_Store/index
ERROR - 2024-06-26 22:06:43 --> 404 Page Not Found: V2/_catalog
ERROR - 2024-06-26 22:06:43 --> 404 Page Not Found: Env/index
ERROR - 2024-06-26 22:06:43 --> 404 Page Not Found: Ecp/Current
ERROR - 2024-06-26 22:06:44 --> 404 Page Not Found: Git/config
ERROR - 2024-06-26 22:06:44 --> 404 Page Not Found: Server-status/index
ERROR - 2024-06-26 22:06:44 --> 404 Page Not Found: Configjson/index
ERROR - 2024-06-26 22:06:44 --> 404 Page Not Found: Loginaction/index
ERROR - 2024-06-26 22:06:44 --> 404 Page Not Found: Telescope/requests
ERROR - 2024-06-26 22:06:45 --> 404 Page Not Found: _all_dbs/index
ERROR - 2024-06-26 22:06:45 --> 404 Page Not Found: DS_Store/index
ERROR - 2024-06-26 22:06:46 --> 404 Page Not Found: Env/index
ERROR - 2024-06-26 22:06:46 --> 404 Page Not Found: Git/config
ERROR - 2024-06-26 22:06:47 --> 404 Page Not Found: Configjson/index
ERROR - 2024-06-26 22:06:47 --> 404 Page Not Found: Telescope/requests
ERROR - 2024-06-26 22:06:49 --> 404 Page Not Found: Git/config
ERROR - 2024-06-26 22:09:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2024-06-26 22:19:14 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Bad Request"
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-06-26 22:19:55 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Bad Request"
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-06-26 22:22:29 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Bad Request"
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-06-26 22:22:30 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Bad Request"
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-06-26 22:22:32 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Bad Request"
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-06-26 22:22:39 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Bad Request"
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-06-26 22:22:47 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Bad Request"
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-06-26 22:22:49 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Bad Request"
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-06-26 22:22:52 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Bad Request"
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-06-26 22:23:15 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Bad Request"
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-06-26 22:23:18 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Bad Request"
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-06-26 22:24:22 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Bad Request"
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-06-26 22:32:43 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Bad Request"
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-06-26 22:32:46 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Bad Request"
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-06-26 22:33:03 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Bad Request"
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-06-26 22:33:06 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Bad Request"
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-06-26 22:35:30 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Bad Request"
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-06-26 22:36:27 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Bad Request"
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-06-26 22:36:29 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Bad Request"
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-06-26 22:38:21 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Bad Request"
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-06-26 22:45:05 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Bad Request"
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-06-26 22:53:42 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Bad Request"
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-06-26 23:02:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2024-06-26 23:02:28 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Bad Request"
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-06-26 23:03:30 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Bad Request"
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-06-26 23:03:41 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Bad Request"
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-06-26 23:03:51 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Bad Request"
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-06-26 23:04:03 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Bad Request"
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-06-26 23:04:05 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Bad Request"
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-06-26 23:10:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2024-06-26 23:10:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2024-06-26 23:16:35 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Bad Request"
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-06-26 23:16:37 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Bad Request"
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-06-26 23:16:40 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Bad Request"
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-06-26 23:16:50 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Bad Request"
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-06-26 23:16:51 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Bad Request"
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-06-26 23:18:31 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Bad Request"
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-06-26 23:18:34 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Bad Request"
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-06-26 23:18:44 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Bad Request"
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-06-26 23:18:47 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Bad Request"
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-06-26 23:18:48 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Bad Request"
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-06-26 23:19:13 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Bad Request"
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-06-26 23:19:19 --> 404 Page Not Found: Public/uploads
ERROR - 2024-06-26 23:19:19 --> 404 Page Not Found: Public/uploads
ERROR - 2024-06-26 23:19:19 --> 404 Page Not Found: Public/uploads
ERROR - 2024-06-26 23:19:19 --> 404 Page Not Found: Public/uploads
ERROR - 2024-06-26 23:24:03 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Bad Request"
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-06-26 23:28:31 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Bad Request"
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
