<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-06-04 07:37:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-06-04 11:47:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-06-04 15:46:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-06-04 16:04:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-06-04 20:15:16 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2024-06-04 21:35:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-06-04 23:33:15 --> 404 Page Not Found: Robotstxt/index
