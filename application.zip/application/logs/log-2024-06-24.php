<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-06-24 00:46:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-06-24 01:01:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-06-24 02:38:25 --> 404 Page Not Found: Wp-json/index
ERROR - 2024-06-24 02:38:45 --> 404 Page Not Found: Wp-json/index
ERROR - 2024-06-24 03:01:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2024-06-24 03:35:23 --> 404 Page Not Found: Sitemap_indexxml/index
ERROR - 2024-06-24 03:43:13 --> 404 Page Not Found: Public/uploads
ERROR - 2024-06-24 03:46:34 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2024-06-24 03:50:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-06-24 04:30:19 --> 404 Page Not Found: Sitemap_indexxml/index
ERROR - 2024-06-24 08:57:01 --> 404 Page Not Found: Wp-admin/setup-config.php
ERROR - 2024-06-24 08:57:01 --> 404 Page Not Found: Wp-admin/install.php
ERROR - 2024-06-24 11:42:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2024-06-24 11:49:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-06-24 12:09:05 --> 404 Page Not Found: Public/uploads
ERROR - 2024-06-24 12:09:05 --> 404 Page Not Found: Public/uploads
ERROR - 2024-06-24 12:09:05 --> 404 Page Not Found: Public/uploads
ERROR - 2024-06-24 12:09:05 --> 404 Page Not Found: Public/uploads
ERROR - 2024-06-24 12:22:04 --> 404 Page Not Found: Assets/editor
ERROR - 2024-06-24 13:34:30 --> 404 Page Not Found: Public/uploads
ERROR - 2024-06-24 13:34:30 --> 404 Page Not Found: Public/uploads
ERROR - 2024-06-24 13:34:30 --> 404 Page Not Found: Public/uploads
ERROR - 2024-06-24 13:34:30 --> 404 Page Not Found: Public/uploads
ERROR - 2024-06-24 13:39:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2024-06-24 13:44:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2024-06-24 14:44:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2024-06-24 14:54:36 --> 404 Page Not Found: Public/assets
ERROR - 2024-06-24 15:07:11 --> 404 Page Not Found: Public/assets
ERROR - 2024-06-24 15:09:28 --> 404 Page Not Found: Public/uploads
ERROR - 2024-06-24 15:09:28 --> 404 Page Not Found: Public/uploads
ERROR - 2024-06-24 15:09:28 --> 404 Page Not Found: Public/uploads
ERROR - 2024-06-24 15:09:28 --> 404 Page Not Found: Public/uploads
ERROR - 2024-06-24 15:13:38 --> 404 Page Not Found: Public/uploads
ERROR - 2024-06-24 15:15:33 --> 404 Page Not Found: Public/uploads
ERROR - 2024-06-24 15:15:33 --> 404 Page Not Found: Public/uploads
ERROR - 2024-06-24 15:15:33 --> 404 Page Not Found: Public/uploads
ERROR - 2024-06-24 15:15:33 --> 404 Page Not Found: Public/uploads
ERROR - 2024-06-24 15:15:41 --> 404 Page Not Found: Public/uploads
ERROR - 2024-06-24 15:15:41 --> 404 Page Not Found: Public/uploads
ERROR - 2024-06-24 15:15:41 --> 404 Page Not Found: Public/uploads
ERROR - 2024-06-24 15:15:41 --> 404 Page Not Found: Public/uploads
ERROR - 2024-06-24 15:19:49 --> 404 Page Not Found: Public/assets
ERROR - 2024-06-24 15:38:44 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Bad Request"
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-06-24 15:38:46 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Bad Request"
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-06-24 15:38:49 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Bad Request"
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-06-24 15:39:03 --> 404 Page Not Found: Public/uploads
ERROR - 2024-06-24 15:43:49 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Bad Request"
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-06-24 18:14:48 --> 404 Page Not Found: Assets/js
ERROR - 2024-06-24 18:17:06 --> 404 Page Not Found: Public/assets
ERROR - 2024-06-24 18:28:28 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Bad Request"
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-06-24 18:28:58 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Bad Request"
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-06-24 18:29:04 --> 404 Page Not Found: Public/uploads
ERROR - 2024-06-24 18:29:04 --> 404 Page Not Found: Public/uploads
ERROR - 2024-06-24 18:29:04 --> 404 Page Not Found: Public/uploads
ERROR - 2024-06-24 18:29:04 --> 404 Page Not Found: Public/uploads
ERROR - 2024-06-24 18:29:11 --> 404 Page Not Found: Public/uploads
ERROR - 2024-06-24 18:29:31 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Bad Request"
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-06-24 18:38:14 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Bad Request"
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-06-24 18:38:21 --> 404 Page Not Found: Public/uploads
ERROR - 2024-06-24 18:38:21 --> 404 Page Not Found: Public/uploads
ERROR - 2024-06-24 18:38:21 --> 404 Page Not Found: Public/uploads
ERROR - 2024-06-24 18:38:21 --> 404 Page Not Found: Public/uploads
ERROR - 2024-06-24 18:39:49 --> 404 Page Not Found: Public/assets
ERROR - 2024-06-24 18:47:41 --> 404 Page Not Found: Public/assets
ERROR - 2024-06-24 18:48:22 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Bad Request"
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-06-24 18:51:03 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Bad Request"
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-06-24 18:51:24 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Bad Request"
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-06-24 18:52:27 --> 404 Page Not Found: Public/assets
ERROR - 2024-06-24 18:52:57 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Bad Request"
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-06-24 18:53:11 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Bad Request"
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-06-24 18:53:14 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Bad Request"
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-06-24 18:53:18 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Bad Request"
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-06-24 18:53:29 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Bad Request"
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-06-24 22:02:31 --> 404 Page Not Found: Ckeditor/plugins
