<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-05-29 06:40:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-05-29 13:40:48 --> 404 Page Not Found: Wp-json/litespeed
ERROR - 2024-05-29 21:28:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-05-29 21:29:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-05-29 21:36:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-05-29 22:33:42 --> 404 Page Not Found: Faviconico/index
