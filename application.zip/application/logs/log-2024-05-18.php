<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-05-18 04:27:47 --> 404 Page Not Found: Env/index
ERROR - 2024-05-18 08:24:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-05-18 08:34:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-05-18 09:28:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-05-18 09:45:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-05-18 10:52:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-05-18 12:27:47 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2024-05-18 12:27:47 --> 404 Page Not Found: Administrator/index.php
ERROR - 2024-05-18 12:27:48 --> 404 Page Not Found: View-source:/index
ERROR - 2024-05-18 12:27:48 --> 404 Page Not Found: Misc/ajax.js
ERROR - 2024-05-18 16:34:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-05-18 16:52:37 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2024-05-18 16:52:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-05-18 16:52:45 --> 404 Page Not Found: Axis2-admin/index
ERROR - 2024-05-18 16:52:47 --> 404 Page Not Found: Axis2/index
ERROR - 2024-05-18 16:52:48 --> 404 Page Not Found: Axis2/axis2-admin
ERROR - 2024-05-18 16:52:49 --> 404 Page Not Found: Phpmyadmin/index.php
ERROR - 2024-05-18 16:52:49 --> 404 Page Not Found: Php/thinkphp
ERROR - 2024-05-18 16:52:50 --> 404 Page Not Found: Index_ssophp/index
