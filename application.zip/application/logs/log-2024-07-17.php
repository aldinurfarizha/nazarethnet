<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-07-17 01:26:43 --> Severity: error --> Exception: Call to a member function select() on null C:\xampp\htdocs\nazarethnet\application\helpers\global_helper.php 184
ERROR - 2024-07-17 01:27:11 --> Severity: Notice --> Undefined variable: ci C:\xampp\htdocs\nazarethnet\application\helpers\global_helper.php 184
ERROR - 2024-07-17 01:27:11 --> Severity: Notice --> Trying to get property 'db' of non-object C:\xampp\htdocs\nazarethnet\application\helpers\global_helper.php 184
ERROR - 2024-07-17 01:27:11 --> Severity: error --> Exception: Call to a member function select() on null C:\xampp\htdocs\nazarethnet\application\helpers\global_helper.php 184
ERROR - 2024-07-17 01:27:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nazarethnet\application\helpers\global_helper.php 192
ERROR - 2024-07-17 01:27:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nazarethnet\application\helpers\global_helper.php 192
ERROR - 2024-07-17 01:27:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nazarethnet\application\helpers\global_helper.php 192
ERROR - 2024-07-17 01:27:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nazarethnet\application\helpers\global_helper.php 192
ERROR - 2024-07-17 01:27:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nazarethnet\application\helpers\global_helper.php 192
ERROR - 2024-07-17 01:27:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nazarethnet\application\helpers\global_helper.php 192
ERROR - 2024-07-17 01:27:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nazarethnet\application\helpers\global_helper.php 192
ERROR - 2024-07-17 01:27:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nazarethnet\application\helpers\global_helper.php 192
ERROR - 2024-07-17 01:27:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nazarethnet\application\helpers\global_helper.php 192
ERROR - 2024-07-17 01:27:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nazarethnet\application\helpers\global_helper.php 192
ERROR - 2024-07-17 01:27:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nazarethnet\application\helpers\global_helper.php 192
ERROR - 2024-07-17 01:27:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nazarethnet\application\helpers\global_helper.php 192
ERROR - 2024-07-17 01:27:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nazarethnet\application\helpers\global_helper.php 192
ERROR - 2024-07-17 01:27:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nazarethnet\application\helpers\global_helper.php 192
ERROR - 2024-07-17 01:27:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nazarethnet\application\helpers\global_helper.php 192
ERROR - 2024-07-17 01:27:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nazarethnet\application\helpers\global_helper.php 192
ERROR - 2024-07-17 01:27:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nazarethnet\application\helpers\global_helper.php 192
ERROR - 2024-07-17 01:31:14 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-17 01:31:14 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-17 01:31:14 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-17 01:31:17 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-17 01:31:17 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-17 01:31:17 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-17 01:31:18 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-17 01:31:18 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-17 01:31:18 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-17 01:31:18 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-17 01:31:18 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-17 01:31:18 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-17 01:31:18 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-17 01:31:18 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-17 01:31:18 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-17 01:31:18 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-17 01:31:18 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-17 01:31:18 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-17 01:31:18 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-17 01:31:18 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-17 01:31:18 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-17 01:31:18 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-17 01:31:18 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-17 01:31:21 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-17 01:31:21 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-17 01:31:21 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-17 01:31:22 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\student_portal.php 98
ERROR - 2024-07-17 01:31:22 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\student_portal.php 98
ERROR - 2024-07-17 01:31:22 --> Severity: Notice --> Trying to get property 'route_name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\student_portal.php 115
ERROR - 2024-07-17 01:31:26 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-17 01:31:26 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-17 01:31:26 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-17 01:31:38 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-17 01:31:38 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-17 01:31:38 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-17 01:31:51 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-17 01:31:51 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-17 01:31:51 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-17 01:31:51 --> Severity: Notice --> Undefined variable: class_id C:\xampp\htdocs\nazarethnet\application\views\backend\admin\fancy.php 96
ERROR - 2024-07-17 01:36:41 --> 404 Page Not Found: Public/uploads
