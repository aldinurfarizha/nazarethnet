<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-06-08 00:40:12 --> 404 Page Not Found: Sftp-configjson/index
ERROR - 2024-06-08 00:40:12 --> 404 Page Not Found: Vscode/sftp.json
ERROR - 2024-06-08 02:38:46 --> 404 Page Not Found: Theme/v2board
ERROR - 2024-06-08 02:38:46 --> 404 Page Not Found: Theme/v2board
ERROR - 2024-06-08 03:43:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-06-08 07:22:33 --> 404 Page Not Found: Img1wsimgcom/traffic-assets
ERROR - 2024-06-08 07:23:24 --> 404 Page Not Found: Img1wsimgcom/traffic-assets
ERROR - 2024-06-08 07:24:10 --> 404 Page Not Found: Img1wsimgcom/traffic-assets
ERROR - 2024-06-08 10:10:06 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home/bosguy7i1szv/public_html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2024-06-08 10:10:06 --> Unable to connect to the database
ERROR - 2024-06-08 22:28:54 --> 404 Page Not Found: Robotstxt/index
