<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-06-18 00:33:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-06-18 01:24:55 --> 404 Page Not Found: Admin/fileman
ERROR - 2024-06-18 03:08:46 --> 404 Page Not Found: Fileman/php
ERROR - 2024-06-18 03:46:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-06-18 07:16:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-06-18 08:42:36 --> 404 Page Not Found: Wp-admin/setup-config.php
ERROR - 2024-06-18 08:42:37 --> 404 Page Not Found: Wp-admin/install.php
ERROR - 2024-06-18 11:24:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-06-18 11:25:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-06-18 19:52:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-06-18 22:38:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-06-18 22:54:30 --> 404 Page Not Found: Extplorer/index.php
