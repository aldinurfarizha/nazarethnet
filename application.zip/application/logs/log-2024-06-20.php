<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-06-20 01:32:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-06-20 03:23:12 --> 404 Page Not Found: Sitemapxmlgz/index
ERROR - 2024-06-20 04:23:27 --> 404 Page Not Found: Sitemapxmlgz/index
ERROR - 2024-06-20 09:56:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-06-20 11:54:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-06-20 15:48:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-06-20 17:36:11 --> 404 Page Not Found: Php-cgi/php-cgi.exe
ERROR - 2024-06-20 17:36:12 --> 404 Page Not Found: Helloworld/index
ERROR - 2024-06-20 17:36:14 --> 404 Page Not Found: Testphp/index
ERROR - 2024-06-20 17:36:14 --> 404 Page Not Found: Testhello/index
ERROR - 2024-06-20 17:57:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-06-20 20:51:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-06-20 20:53:04 --> 404 Page Not Found: Robotstxt/index
