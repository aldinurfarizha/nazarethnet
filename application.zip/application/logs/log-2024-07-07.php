<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-07-07 20:50:21 --> Severity: Notice --> session_start(): A session had already been started - ignoring C:\xampp\htdocs\nazarethnet\public\face\config.php 2
ERROR - 2024-07-07 20:50:26 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-07 20:50:26 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-07 20:50:26 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-07 20:55:47 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-07 20:55:47 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-07 20:55:47 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-07 20:55:50 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-07 20:55:50 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-07 20:55:50 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-07 20:55:50 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-07 20:55:50 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-07 20:55:50 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-07 20:55:50 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-07 20:55:50 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-07 20:55:50 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-07 20:55:51 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-07 20:55:51 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-07 20:55:51 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-07 20:55:51 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-07 20:55:51 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-07 20:55:51 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-07 20:55:51 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-07 20:55:51 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-07 20:55:51 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-07 20:55:51 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-07 20:55:51 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-07 20:55:51 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-07 20:55:55 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-07 20:55:55 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-07 20:55:55 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-07 20:55:56 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\student_portal.php 108
ERROR - 2024-07-07 20:55:56 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\student_portal.php 108
ERROR - 2024-07-07 20:55:56 --> Severity: Notice --> Trying to get property 'route_name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\student_portal.php 132
ERROR - 2024-07-07 20:56:00 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-07 20:56:00 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-07 20:56:00 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-07 20:56:12 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-07 20:56:12 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-07 20:56:12 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-07 20:56:12 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\student_portal.php 108
ERROR - 2024-07-07 20:56:12 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\student_portal.php 108
ERROR - 2024-07-07 20:56:12 --> Severity: Notice --> Trying to get property 'route_name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\student_portal.php 132
ERROR - 2024-07-07 20:56:14 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-07 20:56:14 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-07 20:56:14 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-07 20:56:14 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-07 20:56:14 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-07 20:56:14 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-07 20:56:14 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-07 20:56:14 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-07 20:56:14 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-07 20:56:14 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-07 20:56:14 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-07 20:56:14 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-07 20:56:14 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-07 20:56:14 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-07 20:56:14 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-07 20:56:14 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-07 20:56:14 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-07 20:56:14 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-07 20:56:14 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-07 20:56:14 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-07 20:56:14 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-07 20:56:20 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-07 20:56:20 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-07 20:56:20 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-07 20:56:25 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-07 20:56:25 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-07 20:56:25 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-07 20:56:25 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\student_portal.php 108
ERROR - 2024-07-07 20:56:25 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\student_portal.php 108
ERROR - 2024-07-07 20:56:25 --> Severity: Notice --> Trying to get property 'route_name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\student_portal.php 132
ERROR - 2024-07-07 20:56:32 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-07 20:56:32 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-07 20:56:32 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-07 20:56:32 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-07 20:56:32 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-07 20:56:32 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-07 20:56:32 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-07 20:56:32 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-07 20:56:32 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-07 20:56:32 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-07 20:56:32 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-07 20:56:32 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-07 20:56:32 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-07 20:56:32 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-07 20:56:32 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-07 20:56:32 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-07 20:56:32 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-07 20:56:32 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-07 20:56:33 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-07 20:56:33 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-07 20:56:33 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-07 20:56:42 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-07 20:56:42 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-07 20:56:42 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-07 20:56:46 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-07 20:56:46 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-07 20:56:46 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-07 20:56:50 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-07 20:56:50 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-07 20:56:50 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-07 20:56:53 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-07 20:56:53 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-07 20:56:53 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-07 20:56:57 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-07 20:56:57 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-07 20:56:57 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-07 20:56:58 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\student_portal.php 108
ERROR - 2024-07-07 20:56:58 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\student_portal.php 108
ERROR - 2024-07-07 20:56:58 --> Severity: Notice --> Trying to get property 'route_name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\student_portal.php 132
ERROR - 2024-07-07 20:57:02 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-07 20:57:02 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-07 20:57:02 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-07 21:00:37 --> Severity: Notice --> session_start(): A session had already been started - ignoring C:\xampp\htdocs\nazarethnet\public\face\config.php 2
ERROR - 2024-07-07 21:01:01 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\nazarethnet\application\controllers\Student.php 757
ERROR - 2024-07-07 21:07:49 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-07 21:07:49 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-07 21:07:49 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-07 21:08:16 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-07 21:08:16 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-07 21:08:16 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-07 21:08:23 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-07 21:08:23 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-07 21:08:23 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-07 21:11:21 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\nazarethnet\application\controllers\Student.php 942
ERROR - 2024-07-07 21:11:29 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\student\subject.php 25
ERROR - 2024-07-07 21:12:13 --> 404 Page Not Found: Uploads/e0be4208a38304de945062dba9b202adlogopeque%C3%B1ito-02.jpg
ERROR - 2024-07-07 21:12:13 --> 404 Page Not Found: Uploads/e0be4208a38304de945062dba9b202adlogopeque%C3%B1ito-02.jpg
ERROR - 2024-07-07 22:05:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nazarethnet\application\views\backend\student\subject.php 41
ERROR - 2024-07-07 22:08:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nazarethnet\application\views\backend\student\subject.php 42
ERROR - 2024-07-07 22:08:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nazarethnet\application\views\backend\student\subject.php 42
ERROR - 2024-07-07 22:08:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nazarethnet\application\views\backend\student\subject.php 42
ERROR - 2024-07-07 22:09:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nazarethnet\application\views\backend\student\subject.php 44
ERROR - 2024-07-07 22:10:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nazarethnet\application\views\backend\student\subject.php 44
ERROR - 2024-07-07 22:11:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nazarethnet\application\views\backend\student\subject.php 47
ERROR - 2024-07-07 22:23:14 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ' AND section_id = 2 
                                UNION SELECT question,pub' at line 1 - Invalid query: SELECT description, publish_date, type, news_id FROM news WHERE class_id = 2 AND subject_id = 5 AND section_id = 2 
                                UNION SELECT question,publish_date,type,id FROM polls WHERE class_id = 2 AND subject_id = 5 AND section_id = 2 
                                UNION SELECT homework_code, publish_date, wall_type, homework_id FROM homework WHERE class_id = 2 AND subject_id = 5 AND section_id = 2 
                                UNION SELECT timestamp, publish_date, wall_type, document_id FROM document WHERE class_id = 2 AND subject_id = 5 AND section_id = 2 
                                UNION SELECT code, publish_date, wall_type, online_exam_id FROM online_exam WHERE class_id = 2 AND subject_id = 5 AND section_id = 2 
                                UNION SELECT post_code, publish_date, wall_type, post_id FROM forum WHERE class_id = 2 AND subject_id = 5 AND section_id = 2 ORDER BY publish_date DESC;
ERROR - 2024-07-07 22:23:57 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'UNION SELECT question,publish_date,type,id FROM polls WHERE class_id = 2 AND sub' at line 2 - Invalid query: SELECT description, publish_date, type, news_id FROM news WHERE class_id = 2 AND subject_id = 2 AND section_id =  
                                UNION SELECT question,publish_date,type,id FROM polls WHERE class_id = 2 AND subject_id = 2 AND section_id =  
                                UNION SELECT homework_code, publish_date, wall_type, homework_id FROM homework WHERE class_id = 2 AND subject_id = 2 AND section_id =  
                                UNION SELECT timestamp, publish_date, wall_type, document_id FROM document WHERE class_id = 2 AND subject_id = 2 AND section_id =  
                                UNION SELECT code, publish_date, wall_type, online_exam_id FROM online_exam WHERE class_id = 2 AND subject_id = 2 AND section_id =  
                                UNION SELECT post_code, publish_date, wall_type, post_id FROM forum WHERE class_id = 2 AND subject_id = 2 AND section_id =  ORDER BY publish_date DESC;
ERROR - 2024-07-07 22:24:00 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'UNION SELECT question,publish_date,type,id FROM polls WHERE class_id = 2 AND sub' at line 2 - Invalid query: SELECT description, publish_date, type, news_id FROM news WHERE class_id = 2 AND subject_id = 4 AND section_id =  
                                UNION SELECT question,publish_date,type,id FROM polls WHERE class_id = 2 AND subject_id = 4 AND section_id =  
                                UNION SELECT homework_code, publish_date, wall_type, homework_id FROM homework WHERE class_id = 2 AND subject_id = 4 AND section_id =  
                                UNION SELECT timestamp, publish_date, wall_type, document_id FROM document WHERE class_id = 2 AND subject_id = 4 AND section_id =  
                                UNION SELECT code, publish_date, wall_type, online_exam_id FROM online_exam WHERE class_id = 2 AND subject_id = 4 AND section_id =  
                                UNION SELECT post_code, publish_date, wall_type, post_id FROM forum WHERE class_id = 2 AND subject_id = 4 AND section_id =  ORDER BY publish_date DESC;
ERROR - 2024-07-07 22:24:04 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'UNION SELECT question,publish_date,type,id FROM polls WHERE class_id = 2 AND sub' at line 2 - Invalid query: SELECT description, publish_date, type, news_id FROM news WHERE class_id = 2 AND subject_id = 4 AND section_id =  
                                UNION SELECT question,publish_date,type,id FROM polls WHERE class_id = 2 AND subject_id = 4 AND section_id =  
                                UNION SELECT homework_code, publish_date, wall_type, homework_id FROM homework WHERE class_id = 2 AND subject_id = 4 AND section_id =  
                                UNION SELECT timestamp, publish_date, wall_type, document_id FROM document WHERE class_id = 2 AND subject_id = 4 AND section_id =  
                                UNION SELECT code, publish_date, wall_type, online_exam_id FROM online_exam WHERE class_id = 2 AND subject_id = 4 AND section_id =  
                                UNION SELECT post_code, publish_date, wall_type, post_id FROM forum WHERE class_id = 2 AND subject_id = 4 AND section_id =  ORDER BY publish_date DESC;
ERROR - 2024-07-07 22:24:22 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'UNION SELECT question,publish_date,type,id FROM polls WHERE class_id = 2 AND sub' at line 2 - Invalid query: SELECT description, publish_date, type, news_id FROM news WHERE class_id = 2 AND subject_id = 4 AND section_id =  
                                UNION SELECT question,publish_date,type,id FROM polls WHERE class_id = 2 AND subject_id = 4 AND section_id =  
                                UNION SELECT homework_code, publish_date, wall_type, homework_id FROM homework WHERE class_id = 2 AND subject_id = 4 AND section_id =  
                                UNION SELECT timestamp, publish_date, wall_type, document_id FROM document WHERE class_id = 2 AND subject_id = 4 AND section_id =  
                                UNION SELECT code, publish_date, wall_type, online_exam_id FROM online_exam WHERE class_id = 2 AND subject_id = 4 AND section_id =  
                                UNION SELECT post_code, publish_date, wall_type, post_id FROM forum WHERE class_id = 2 AND subject_id = 4 AND section_id =  ORDER BY publish_date DESC;
ERROR - 2024-07-07 22:31:10 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-07 22:31:10 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-07 23:34:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nazarethnet\application\views\backend\student\marks_print_view.php 64
ERROR - 2024-07-07 23:34:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nazarethnet\application\views\backend\student\marks_print_view.php 64
ERROR - 2024-07-07 23:34:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nazarethnet\application\views\backend\student\marks_print_view.php 64
ERROR - 2024-07-07 23:34:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nazarethnet\application\views\backend\student\marks_print_view.php 64
ERROR - 2024-07-07 23:34:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nazarethnet\application\views\backend\student\marks_print_view.php 64
ERROR - 2024-07-07 23:34:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nazarethnet\application\views\backend\student\marks_print_view.php 64
ERROR - 2024-07-07 23:34:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nazarethnet\application\views\backend\student\marks_print_view.php 64
ERROR - 2024-07-07 23:34:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nazarethnet\application\views\backend\student\marks_print_view.php 64
ERROR - 2024-07-07 23:34:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nazarethnet\application\views\backend\student\marks_print_view.php 64
ERROR - 2024-07-07 23:36:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nazarethnet\application\views\backend\student\marks_print_view.php 64
ERROR - 2024-07-07 23:36:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nazarethnet\application\views\backend\student\marks_print_view.php 64
ERROR - 2024-07-07 23:36:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nazarethnet\application\views\backend\student\marks_print_view.php 64
ERROR - 2024-07-07 23:36:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nazarethnet\application\views\backend\student\marks_print_view.php 64
ERROR - 2024-07-07 23:36:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nazarethnet\application\views\backend\student\marks_print_view.php 64
ERROR - 2024-07-07 23:36:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nazarethnet\application\views\backend\student\marks_print_view.php 64
ERROR - 2024-07-07 23:36:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nazarethnet\application\views\backend\student\marks_print_view.php 64
ERROR - 2024-07-07 23:36:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nazarethnet\application\views\backend\student\marks_print_view.php 64
ERROR - 2024-07-07 23:36:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nazarethnet\application\views\backend\student\marks_print_view.php 64
ERROR - 2024-07-07 23:44:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nazarethnet\application\views\backend\student\marks_print_view.php 66
ERROR - 2024-07-07 23:44:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nazarethnet\application\views\backend\student\marks_print_view.php 66
ERROR - 2024-07-07 23:44:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nazarethnet\application\views\backend\student\marks_print_view.php 66
ERROR - 2024-07-07 23:44:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nazarethnet\application\views\backend\student\marks_print_view.php 66
ERROR - 2024-07-07 23:44:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nazarethnet\application\views\backend\student\marks_print_view.php 66
ERROR - 2024-07-07 23:44:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nazarethnet\application\views\backend\student\marks_print_view.php 66
ERROR - 2024-07-07 23:44:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nazarethnet\application\views\backend\student\marks_print_view.php 66
ERROR - 2024-07-07 23:44:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nazarethnet\application\views\backend\student\marks_print_view.php 66
ERROR - 2024-07-07 23:44:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nazarethnet\application\views\backend\student\marks_print_view.php 66
ERROR - 2024-07-07 23:44:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nazarethnet\application\views\backend\student\marks_print_view.php 66
ERROR - 2024-07-07 23:44:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nazarethnet\application\views\backend\student\marks_print_view.php 66
ERROR - 2024-07-07 23:44:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nazarethnet\application\views\backend\student\marks_print_view.php 66
ERROR - 2024-07-07 23:44:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nazarethnet\application\views\backend\student\marks_print_view.php 66
ERROR - 2024-07-07 23:44:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nazarethnet\application\views\backend\student\marks_print_view.php 66
ERROR - 2024-07-07 23:44:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nazarethnet\application\views\backend\student\marks_print_view.php 66
ERROR - 2024-07-07 23:44:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nazarethnet\application\views\backend\student\marks_print_view.php 66
ERROR - 2024-07-07 23:44:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nazarethnet\application\views\backend\student\marks_print_view.php 66
ERROR - 2024-07-07 23:44:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nazarethnet\application\views\backend\student\marks_print_view.php 66
ERROR - 2024-07-07 23:44:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nazarethnet\application\views\backend\student\marks_print_view.php 66
ERROR - 2024-07-07 23:44:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nazarethnet\application\views\backend\student\marks_print_view.php 66
ERROR - 2024-07-07 23:45:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nazarethnet\application\views\backend\student\marks_print_view.php 66
ERROR - 2024-07-07 23:45:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nazarethnet\application\views\backend\student\marks_print_view.php 66
ERROR - 2024-07-07 23:45:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nazarethnet\application\views\backend\student\marks_print_view.php 66
ERROR - 2024-07-07 23:45:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nazarethnet\application\views\backend\student\marks_print_view.php 66
ERROR - 2024-07-07 23:45:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nazarethnet\application\views\backend\student\marks_print_view.php 66
ERROR - 2024-07-07 23:45:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nazarethnet\application\views\backend\student\marks_print_view.php 66
ERROR - 2024-07-07 23:45:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nazarethnet\application\views\backend\student\marks_print_view.php 66
ERROR - 2024-07-07 23:45:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nazarethnet\application\views\backend\student\marks_print_view.php 66
ERROR - 2024-07-07 23:45:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nazarethnet\application\views\backend\student\marks_print_view.php 66
ERROR - 2024-07-07 23:45:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nazarethnet\application\views\backend\student\marks_print_view.php 66
ERROR - 2024-07-07 23:45:41 --> 404 Page Not Found: Uploads/e0be4208a38304de945062dba9b202adlogopeque%C3%B1ito-02.jpg
ERROR - 2024-07-07 23:46:08 --> 404 Page Not Found: Uploads/e0be4208a38304de945062dba9b202adlogopeque%C3%B1ito-02.jpg
ERROR - 2024-07-07 23:54:37 --> 404 Page Not Found: Uploads/e0be4208a38304de945062dba9b202adlogopeque%C3%B1ito-02.jpg
ERROR - 2024-07-07 23:55:56 --> 404 Page Not Found: Uploads/e0be4208a38304de945062dba9b202adlogopeque%C3%B1ito-02.jpg
ERROR - 2024-07-07 23:58:05 --> 404 Page Not Found: Uploads/e0be4208a38304de945062dba9b202adlogopeque%C3%B1ito-02.jpg
ERROR - 2024-07-07 23:58:19 --> 404 Page Not Found: Uploads/e0be4208a38304de945062dba9b202adlogopeque%C3%B1ito-02.jpg
