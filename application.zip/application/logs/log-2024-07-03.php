<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-07-03 06:17:12 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\nazarethnet\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-07-03 06:17:12 --> Unable to connect to the database
ERROR - 2024-07-03 06:17:12 --> Severity: error --> Exception: Class 'EduAppGT' not found C:\xampp\htdocs\nazarethnet\system\core\CodeIgniter.php 370
