<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-04-29 06:46:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-04-29 06:46:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2024-04-29 11:00:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2024-04-29 11:23:15 --> Severity: Warning --> A non-numeric value encountered /home/bosguy7i1szv/public_html/application/views/backend/admin/upload_marks.php 138
ERROR - 2024-04-29 11:23:15 --> Severity: Warning --> A non-numeric value encountered /home/bosguy7i1szv/public_html/application/views/backend/admin/upload_marks.php 138
ERROR - 2024-04-29 11:23:15 --> Severity: Warning --> A non-numeric value encountered /home/bosguy7i1szv/public_html/application/views/backend/admin/upload_marks.php 138
ERROR - 2024-04-29 11:23:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2024-04-29 11:27:41 --> Severity: Warning --> A non-numeric value encountered /home/bosguy7i1szv/public_html/application/views/backend/admin/upload_marks.php 138
ERROR - 2024-04-29 11:27:41 --> Severity: Warning --> A non-numeric value encountered /home/bosguy7i1szv/public_html/application/views/backend/admin/upload_marks.php 138
ERROR - 2024-04-29 11:27:41 --> Severity: Warning --> A non-numeric value encountered /home/bosguy7i1szv/public_html/application/views/backend/admin/upload_marks.php 138
ERROR - 2024-04-29 11:42:13 --> Severity: Warning --> A non-numeric value encountered /home/bosguy7i1szv/public_html/application/views/backend/admin/upload_marks.php 138
ERROR - 2024-04-29 11:42:13 --> Severity: Warning --> A non-numeric value encountered /home/bosguy7i1szv/public_html/application/views/backend/admin/upload_marks.php 138
ERROR - 2024-04-29 11:42:13 --> Severity: Warning --> A non-numeric value encountered /home/bosguy7i1szv/public_html/application/views/backend/admin/upload_marks.php 138
ERROR - 2024-04-29 11:42:35 --> Severity: Warning --> A non-numeric value encountered /home/bosguy7i1szv/public_html/application/views/backend/admin/upload_marks.php 138
ERROR - 2024-04-29 11:42:35 --> Severity: Warning --> A non-numeric value encountered /home/bosguy7i1szv/public_html/application/views/backend/admin/upload_marks.php 138
ERROR - 2024-04-29 11:42:35 --> Severity: Warning --> A non-numeric value encountered /home/bosguy7i1szv/public_html/application/views/backend/admin/upload_marks.php 138
ERROR - 2024-04-29 11:49:35 --> Severity: Warning --> A non-numeric value encountered /home/bosguy7i1szv/public_html/application/views/backend/admin/upload_marks.php 138
ERROR - 2024-04-29 11:49:35 --> Severity: Warning --> A non-numeric value encountered /home/bosguy7i1szv/public_html/application/views/backend/admin/upload_marks.php 138
ERROR - 2024-04-29 11:49:35 --> Severity: Warning --> A non-numeric value encountered /home/bosguy7i1szv/public_html/application/views/backend/admin/upload_marks.php 138
ERROR - 2024-04-29 11:49:44 --> Severity: Warning --> A non-numeric value encountered /home/bosguy7i1szv/public_html/application/views/backend/admin/upload_marks.php 138
ERROR - 2024-04-29 11:49:44 --> Severity: Warning --> A non-numeric value encountered /home/bosguy7i1szv/public_html/application/views/backend/admin/upload_marks.php 138
ERROR - 2024-04-29 11:49:44 --> Severity: Warning --> A non-numeric value encountered /home/bosguy7i1szv/public_html/application/views/backend/admin/upload_marks.php 138
ERROR - 2024-04-29 11:51:07 --> Severity: Warning --> A non-numeric value encountered /home/bosguy7i1szv/public_html/application/views/backend/admin/upload_marks.php 138
ERROR - 2024-04-29 11:51:07 --> Severity: Warning --> A non-numeric value encountered /home/bosguy7i1szv/public_html/application/views/backend/admin/upload_marks.php 138
ERROR - 2024-04-29 11:51:07 --> Severity: Warning --> A non-numeric value encountered /home/bosguy7i1szv/public_html/application/views/backend/admin/upload_marks.php 138
ERROR - 2024-04-29 11:51:20 --> Severity: Warning --> A non-numeric value encountered /home/bosguy7i1szv/public_html/application/views/backend/admin/upload_marks.php 138
ERROR - 2024-04-29 11:51:20 --> Severity: Warning --> A non-numeric value encountered /home/bosguy7i1szv/public_html/application/views/backend/admin/upload_marks.php 138
ERROR - 2024-04-29 11:51:20 --> Severity: Warning --> A non-numeric value encountered /home/bosguy7i1szv/public_html/application/views/backend/admin/upload_marks.php 138
ERROR - 2024-04-29 11:51:50 --> Severity: Warning --> A non-numeric value encountered /home/bosguy7i1szv/public_html/application/views/backend/admin/upload_marks.php 138
ERROR - 2024-04-29 11:51:50 --> Severity: Warning --> A non-numeric value encountered /home/bosguy7i1szv/public_html/application/views/backend/admin/upload_marks.php 138
ERROR - 2024-04-29 11:51:50 --> Severity: Warning --> A non-numeric value encountered /home/bosguy7i1szv/public_html/application/views/backend/admin/upload_marks.php 138
ERROR - 2024-04-29 11:52:07 --> Severity: Warning --> A non-numeric value encountered /home/bosguy7i1szv/public_html/application/views/backend/admin/upload_marks.php 138
ERROR - 2024-04-29 11:52:07 --> Severity: Warning --> A non-numeric value encountered /home/bosguy7i1szv/public_html/application/views/backend/admin/upload_marks.php 138
ERROR - 2024-04-29 11:52:07 --> Severity: Warning --> A non-numeric value encountered /home/bosguy7i1szv/public_html/application/views/backend/admin/upload_marks.php 138
ERROR - 2024-04-29 11:53:39 --> Severity: Warning --> A non-numeric value encountered /home/bosguy7i1szv/public_html/application/views/backend/admin/upload_marks.php 138
ERROR - 2024-04-29 11:53:39 --> Severity: Warning --> A non-numeric value encountered /home/bosguy7i1szv/public_html/application/views/backend/admin/upload_marks.php 138
ERROR - 2024-04-29 11:53:39 --> Severity: Warning --> A non-numeric value encountered /home/bosguy7i1szv/public_html/application/views/backend/admin/upload_marks.php 138
ERROR - 2024-04-29 11:56:12 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable /home/bosguy7i1szv/public_html/application/models/Crud.php 1862
ERROR - 2024-04-29 11:57:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2024-04-29 11:58:15 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable /home/bosguy7i1szv/public_html/application/models/Crud.php 1862
ERROR - 2024-04-29 11:59:23 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable /home/bosguy7i1szv/public_html/application/models/Crud.php 1892
ERROR - 2024-04-29 11:59:23 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/bosguy7i1szv/public_html/application/models/Crud.php 1904
ERROR - 2024-04-29 12:10:07 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Token has been expired or revoked."
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-04-29 12:10:11 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Token has been expired or revoked."
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-04-29 12:10:23 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Token has been expired or revoked."
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-04-29 12:10:46 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Token has been expired or revoked."
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-04-29 12:11:04 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Token has been expired or revoked."
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-04-29 12:11:16 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Token has been expired or revoked."
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-04-29 12:11:38 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Token has been expired or revoked."
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-04-29 12:13:08 --> 404 Page Not Found: Public/uploads
ERROR - 2024-04-29 12:13:45 --> 404 Page Not Found: Public/uploads
ERROR - 2024-04-29 12:14:12 --> 404 Page Not Found: Public/uploads
ERROR - 2024-04-29 12:14:38 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Token has been expired or revoked."
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-04-29 12:14:40 --> 404 Page Not Found: Public/uploads
ERROR - 2024-04-29 12:15:18 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Token has been expired or revoked."
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-04-29 12:16:15 --> 404 Page Not Found: Public/uploads
ERROR - 2024-04-29 12:16:31 --> 404 Page Not Found: Public/uploads
ERROR - 2024-04-29 12:19:40 --> 404 Page Not Found: Public/uploads
ERROR - 2024-04-29 12:19:40 --> 404 Page Not Found: Public/uploads
ERROR - 2024-04-29 12:23:17 --> 404 Page Not Found: Public/uploads
ERROR - 2024-04-29 12:33:10 --> 404 Page Not Found: Public/uploads
ERROR - 2024-04-29 12:33:10 --> 404 Page Not Found: Public/uploads
ERROR - 2024-04-29 12:38:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2024-04-29 12:39:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2024-04-29 12:41:12 --> 404 Page Not Found: Public/uploads
ERROR - 2024-04-29 12:41:12 --> 404 Page Not Found: Public/uploads
ERROR - 2024-04-29 12:43:34 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Token has been expired or revoked."
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-04-29 12:43:36 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Token has been expired or revoked."
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-04-29 12:43:57 --> 404 Page Not Found: Public/uploads
ERROR - 2024-04-29 12:56:19 --> 404 Page Not Found: Public/uploads
ERROR - 2024-04-29 16:27:28 --> 404 Page Not Found: Vscode/sftp.json
ERROR - 2024-04-29 16:27:28 --> 404 Page Not Found: Sftp-configjson/index
ERROR - 2024-04-29 16:27:28 --> 404 Page Not Found: Sftpjson/index
ERROR - 2024-04-29 18:40:02 --> 404 Page Not Found: Robotstxt/index
