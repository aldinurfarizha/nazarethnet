<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-05-23 08:40:01 --> 404 Page Not Found: Wp-json/litespeed
ERROR - 2024-05-23 11:45:33 --> 404 Page Not Found: Git/config
ERROR - 2024-05-23 12:51:50 --> 404 Page Not Found: Wp-admin/setup-config.php
ERROR - 2024-05-23 12:51:51 --> 404 Page Not Found: Wp-admin/install.php
ERROR - 2024-05-23 12:56:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-05-23 17:22:08 --> 404 Page Not Found: Adstxt/index
ERROR - 2024-05-23 18:01:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-05-23 18:55:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-05-23 22:05:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-05-23 22:05:09 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2024-05-23 22:05:18 --> 404 Page Not Found: Securitytxt/index
ERROR - 2024-05-23 22:05:18 --> 404 Page Not Found: Well-known/security.txt
ERROR - 2024-05-23 22:05:18 --> 404 Page Not Found: Adstxt/index
ERROR - 2024-05-23 22:05:18 --> 404 Page Not Found: Humanstxt/index
ERROR - 2024-05-23 22:45:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-05-23 22:45:33 --> 404 Page Not Found: Enhance/index
