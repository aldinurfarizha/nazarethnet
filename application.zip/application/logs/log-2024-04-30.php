<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-04-30 10:31:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-04-30 10:32:02 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2024-04-30 10:34:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-04-30 10:34:22 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2024-04-30 17:05:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2024-04-30 17:05:35 --> 404 Page Not Found: Public/uploads
ERROR - 2024-04-30 17:23:25 --> 404 Page Not Found: Public/uploads
ERROR - 2024-04-30 17:23:25 --> 404 Page Not Found: Public/uploads
ERROR - 2024-04-30 17:24:49 --> 404 Page Not Found: Public/uploads
ERROR - 2024-04-30 17:24:49 --> 404 Page Not Found: Public/uploads
ERROR - 2024-04-30 17:50:57 --> 404 Page Not Found: Public/uploads
ERROR - 2024-04-30 17:50:57 --> 404 Page Not Found: Public/uploads
ERROR - 2024-04-30 17:57:33 --> 404 Page Not Found: Public/uploads
ERROR - 2024-04-30 17:57:33 --> 404 Page Not Found: Public/uploads
ERROR - 2024-04-30 17:58:48 --> 404 Page Not Found: Public/uploads
ERROR - 2024-04-30 17:58:48 --> 404 Page Not Found: Public/uploads
ERROR - 2024-04-30 17:59:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2024-04-30 18:00:43 --> 404 Page Not Found: Uploads/84c0e48168e2c28e9c2efbd683a671b6logonazarethinstitute.png
ERROR - 2024-04-30 18:15:41 --> 404 Page Not Found: Public/uploads
ERROR - 2024-04-30 18:15:41 --> 404 Page Not Found: Public/uploads
ERROR - 2024-04-30 20:03:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-04-30 23:09:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-04-30 23:35:31 --> 404 Page Not Found: Robotstxt/index
