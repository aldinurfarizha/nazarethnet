<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-07-20 23:09:52 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-20 23:09:52 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-20 23:09:52 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-20 23:09:52 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-20 23:09:52 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-20 23:10:06 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-20 23:10:06 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-20 23:10:06 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-20 23:10:06 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-20 23:10:06 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-20 23:10:09 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-20 23:10:09 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-20 23:10:09 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-20 23:10:09 --> Severity: Warning --> Undefined variable $class_id /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/fancy.php 96
ERROR - 2024-07-20 23:10:09 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-20 23:10:09 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-20 23:10:44 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-20 23:10:44 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-20 23:10:44 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-20 23:10:44 --> Severity: Warning --> Undefined variable $class_id /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/fancy.php 96
ERROR - 2024-07-20 23:10:44 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-20 23:10:44 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-20 23:10:45 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-20 23:10:45 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-20 23:10:45 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-20 23:10:45 --> Severity: Warning --> Undefined variable $class_id /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/fancy.php 96
ERROR - 2024-07-20 23:10:45 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-20 23:10:45 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-20 23:11:56 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-20 23:11:56 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-20 23:11:56 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-20 23:11:56 --> Severity: Warning --> Undefined variable $class_id /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/fancy.php 96
ERROR - 2024-07-20 23:11:56 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-20 23:11:56 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-20 23:12:20 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-20 23:12:20 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-20 23:12:20 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-20 23:12:20 --> Severity: Warning --> Undefined variable $class_id /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/fancy.php 96
ERROR - 2024-07-20 23:12:20 --> Severity: Warning --> Attempt to read property "file_name" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/subject_dashboard.php 592
ERROR - 2024-07-20 23:12:20 --> Severity: Warning --> Attempt to read property "file_name" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/subject_dashboard.php 595
ERROR - 2024-07-20 23:12:20 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-20 23:12:20 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-20 23:12:23 --> Severity: error --> Exception: Too few arguments to function Admin::viewFile(), 0 passed in /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/system/core/CodeIgniter.php on line 533 and exactly 1 expected /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/controllers/Admin.php 86
ERROR - 2024-07-20 23:12:33 --> Severity: error --> Exception: Too few arguments to function Admin::viewFile(), 0 passed in /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/system/core/CodeIgniter.php on line 533 and exactly 1 expected /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/controllers/Admin.php 86
ERROR - 2024-07-20 23:12:39 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-20 23:12:39 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-20 23:12:39 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-20 23:12:39 --> Severity: Warning --> Undefined variable $class_id /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/fancy.php 96
ERROR - 2024-07-20 23:12:39 --> Severity: Warning --> Attempt to read property "file_name" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/subject_dashboard.php 592
ERROR - 2024-07-20 23:12:39 --> Severity: Warning --> Attempt to read property "file_name" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/subject_dashboard.php 595
ERROR - 2024-07-20 23:12:39 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-20 23:12:39 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-20 23:12:52 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-20 23:12:52 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-20 23:12:52 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-20 23:12:52 --> Severity: Warning --> Undefined variable $class_id /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/fancy.php 96
ERROR - 2024-07-20 23:12:52 --> Severity: Warning --> Attempt to read property "file_name" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/subject_dashboard.php 592
ERROR - 2024-07-20 23:12:52 --> Severity: Warning --> Attempt to read property "file_name" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/subject_dashboard.php 595
ERROR - 2024-07-20 23:12:52 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-20 23:12:52 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-20 23:13:05 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-20 23:13:05 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-20 23:13:05 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-20 23:13:05 --> Severity: Warning --> Undefined variable $class_id /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/fancy.php 96
ERROR - 2024-07-20 23:13:05 --> Severity: Warning --> Attempt to read property "file_name" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/subject_dashboard.php 592
ERROR - 2024-07-20 23:13:05 --> Severity: Warning --> Attempt to read property "file_name" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/subject_dashboard.php 595
ERROR - 2024-07-20 23:13:05 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-20 23:13:05 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-20 23:13:30 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-20 23:13:30 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-20 23:13:30 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-20 23:13:30 --> Severity: Warning --> Undefined variable $class_id /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/fancy.php 96
ERROR - 2024-07-20 23:13:30 --> Severity: Warning --> Attempt to read property "file_name" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/subject_dashboard.php 592
ERROR - 2024-07-20 23:13:30 --> Severity: Warning --> Attempt to read property "file_name" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/subject_dashboard.php 595
ERROR - 2024-07-20 23:13:30 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-20 23:13:30 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-20 23:13:31 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-20 23:13:31 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-20 23:13:31 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-20 23:13:31 --> Severity: Warning --> Undefined variable $class_id /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/fancy.php 96
ERROR - 2024-07-20 23:13:31 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-20 23:13:31 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-20 23:14:00 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-20 23:14:00 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-20 23:14:00 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-20 23:14:00 --> Severity: Warning --> Undefined variable $class_id /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/fancy.php 96
ERROR - 2024-07-20 23:14:00 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-20 23:14:00 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-20 23:14:32 --> Severity: error --> Exception: Too few arguments to function Admin::viewFile(), 0 passed in /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/system/core/CodeIgniter.php on line 533 and exactly 1 expected /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/controllers/Admin.php 86
ERROR - 2024-07-20 23:15:09 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-20 23:15:09 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-20 23:15:09 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-20 23:15:09 --> Severity: Warning --> Undefined variable $class_id /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/fancy.php 96
ERROR - 2024-07-20 23:15:09 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-20 23:15:09 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-20 23:17:15 --> Severity: error --> Exception: Too few arguments to function Admin::viewFile(), 0 passed in /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/system/core/CodeIgniter.php on line 533 and exactly 1 expected /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/controllers/Admin.php 86
ERROR - 2024-07-20 23:17:23 --> Severity: error --> Exception: Too few arguments to function Admin::viewFile(), 0 passed in /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/system/core/CodeIgniter.php on line 533 and exactly 1 expected /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/controllers/Admin.php 86
ERROR - 2024-07-20 23:17:26 --> Severity: error --> Exception: Too few arguments to function Admin::viewFile(), 0 passed in /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/system/core/CodeIgniter.php on line 533 and exactly 1 expected /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/controllers/Admin.php 86
ERROR - 2024-07-20 23:18:31 --> Severity: error --> Exception: Too few arguments to function Admin::viewFile(), 0 passed in /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/system/core/CodeIgniter.php on line 533 and exactly 1 expected /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/controllers/Admin.php 86
ERROR - 2024-07-20 23:18:42 --> Severity: error --> Exception: Too few arguments to function Admin::viewFile(), 0 passed in /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/system/core/CodeIgniter.php on line 533 and exactly 1 expected /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/controllers/Admin.php 86
ERROR - 2024-07-20 23:19:51 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-20 23:19:51 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-20 23:19:51 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-20 23:19:51 --> Severity: Warning --> Undefined variable $class_id /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/fancy.php 96
ERROR - 2024-07-20 23:19:51 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-20 23:19:51 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-20 23:20:49 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-20 23:20:49 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-20 23:20:49 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-20 23:20:51 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-20 23:20:51 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-20 23:20:51 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-20 23:20:51 --> 404 Page Not Found: Public/assets
ERROR - 2024-07-20 23:20:53 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-20 23:20:53 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-20 23:20:53 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-20 23:20:56 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-20 23:20:56 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-20 23:20:56 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-20 23:20:56 --> Severity: Warning --> Undefined variable $hrs_fin /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/class_routine_view.php 160
ERROR - 2024-07-20 23:21:12 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-20 23:21:12 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-20 23:21:12 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-20 23:21:12 --> Severity: Warning --> Undefined variable $hrs_fin /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/class_routine_view.php 160
ERROR - 2024-07-20 23:21:58 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-20 23:21:58 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-20 23:21:58 --> Severity: Warning --> Attempt to read property "permissions" on null /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-20 23:21:58 --> Severity: Warning --> Undefined variable $hrs_fin /Applications/XAMPP/xamppfiles/htdocs/nazarethnet/application/views/backend/admin/class_routine_view.php 160
