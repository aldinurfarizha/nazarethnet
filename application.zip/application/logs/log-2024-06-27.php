<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-06-27 00:14:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2024-06-27 00:15:47 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Bad Request"
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-06-27 00:15:52 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Bad Request"
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-06-27 00:16:03 --> 404 Page Not Found: Public/uploads
ERROR - 2024-06-27 00:27:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-06-27 01:44:45 --> 404 Page Not Found: Plugins/fileman
ERROR - 2024-06-27 01:50:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2024-06-27 01:50:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2024-06-27 01:51:12 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Bad Request"
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-06-27 01:51:21 --> 404 Page Not Found: Public/uploads
ERROR - 2024-06-27 01:51:21 --> 404 Page Not Found: Public/uploads
ERROR - 2024-06-27 01:51:21 --> 404 Page Not Found: Public/uploads
ERROR - 2024-06-27 01:51:21 --> 404 Page Not Found: Public/uploads
ERROR - 2024-06-27 01:56:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2024-06-27 01:56:24 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
ERROR - 2024-06-27 01:56:24 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2024-06-27 01:56:25 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2024-06-27 01:56:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2024-06-27 01:56:25 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
ERROR - 2024-06-27 02:18:05 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Bad Request"
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-06-27 02:18:10 --> 404 Page Not Found: Public/uploads
ERROR - 2024-06-27 02:18:10 --> 404 Page Not Found: Public/uploads
ERROR - 2024-06-27 02:18:10 --> 404 Page Not Found: Public/uploads
ERROR - 2024-06-27 02:18:11 --> 404 Page Not Found: Public/uploads
ERROR - 2024-06-27 02:18:34 --> Severity: error --> Exception: Too few arguments to function Admin::viewFile(), 0 passed in /home/bosguy7i1szv/public_html/system/core/CodeIgniter.php on line 533 and exactly 1 expected /home/bosguy7i1szv/public_html/application/controllers/Admin.php 86
ERROR - 2024-06-27 02:18:36 --> Severity: error --> Exception: Too few arguments to function Admin::viewFile(), 0 passed in /home/bosguy7i1szv/public_html/system/core/CodeIgniter.php on line 533 and exactly 1 expected /home/bosguy7i1szv/public_html/application/controllers/Admin.php 86
ERROR - 2024-06-27 02:18:52 --> 404 Page Not Found: Public/uploads
ERROR - 2024-06-27 02:18:52 --> 404 Page Not Found: Public/uploads
ERROR - 2024-06-27 02:18:52 --> 404 Page Not Found: Public/uploads
ERROR - 2024-06-27 02:18:52 --> 404 Page Not Found: Public/uploads
ERROR - 2024-06-27 02:18:56 --> Severity: error --> Exception: Too few arguments to function Admin::viewFile(), 0 passed in /home/bosguy7i1szv/public_html/system/core/CodeIgniter.php on line 533 and exactly 1 expected /home/bosguy7i1szv/public_html/application/controllers/Admin.php 86
ERROR - 2024-06-27 02:19:02 --> Severity: error --> Exception: Too few arguments to function Admin::viewFile(), 0 passed in /home/bosguy7i1szv/public_html/system/core/CodeIgniter.php on line 533 and exactly 1 expected /home/bosguy7i1szv/public_html/application/controllers/Admin.php 86
ERROR - 2024-06-27 02:19:08 --> 404 Page Not Found: Public/uploads
ERROR - 2024-06-27 02:19:15 --> Severity: error --> Exception: Too few arguments to function Admin::viewFile(), 0 passed in /home/bosguy7i1szv/public_html/system/core/CodeIgniter.php on line 533 and exactly 1 expected /home/bosguy7i1szv/public_html/application/controllers/Admin.php 86
ERROR - 2024-06-27 02:19:16 --> Severity: error --> Exception: Too few arguments to function Admin::viewFile(), 0 passed in /home/bosguy7i1szv/public_html/system/core/CodeIgniter.php on line 533 and exactly 1 expected /home/bosguy7i1szv/public_html/application/controllers/Admin.php 86
ERROR - 2024-06-27 02:19:48 --> Severity: error --> Exception: Too few arguments to function Admin::viewFile(), 0 passed in /home/bosguy7i1szv/public_html/system/core/CodeIgniter.php on line 533 and exactly 1 expected /home/bosguy7i1szv/public_html/application/controllers/Admin.php 86
ERROR - 2024-06-27 02:20:17 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Bad Request"
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-06-27 02:20:22 --> 404 Page Not Found: Public/uploads
ERROR - 2024-06-27 02:20:22 --> 404 Page Not Found: Public/uploads
ERROR - 2024-06-27 02:20:22 --> 404 Page Not Found: Public/uploads
ERROR - 2024-06-27 02:20:22 --> 404 Page Not Found: Public/uploads
ERROR - 2024-06-27 02:20:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2024-06-27 02:22:46 --> 404 Page Not Found: Public/uploads
ERROR - 2024-06-27 02:23:01 --> 404 Page Not Found: Public/uploads
ERROR - 2024-06-27 02:23:30 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Bad Request"
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-06-27 02:23:34 --> 404 Page Not Found: Public/uploads
ERROR - 2024-06-27 02:23:34 --> 404 Page Not Found: Public/uploads
ERROR - 2024-06-27 02:23:34 --> 404 Page Not Found: Public/uploads
ERROR - 2024-06-27 02:23:34 --> 404 Page Not Found: Public/uploads
ERROR - 2024-06-27 02:25:14 --> Severity: error --> Exception: Too few arguments to function Admin::viewFile(), 0 passed in /home/bosguy7i1szv/public_html/system/core/CodeIgniter.php on line 533 and exactly 1 expected /home/bosguy7i1szv/public_html/application/controllers/Admin.php 86
ERROR - 2024-06-27 02:30:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2024-06-27 03:34:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-06-27 08:28:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2024-06-27 09:18:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2024-06-27 10:12:06 --> 404 Page Not Found: Public/home
ERROR - 2024-06-27 10:12:06 --> 404 Page Not Found: Public/home
ERROR - 2024-06-27 10:12:07 --> 404 Page Not Found: Static/admin
ERROR - 2024-06-27 10:12:07 --> 404 Page Not Found: Static/admin
ERROR - 2024-06-27 23:15:44 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'eduappgt_app'@'localhost' (using password: YES) /Applications/MAMP/htdocs MAMP/nazarethnet/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2024-06-27 23:15:44 --> Unable to connect to the database
ERROR - 2024-06-27 23:15:44 --> Severity: error --> Exception: Class 'EduAppGT' not found /Applications/MAMP/htdocs MAMP/nazarethnet/system/core/CodeIgniter.php 370
ERROR - 2024-06-27 23:15:46 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'eduappgt_app'@'localhost' (using password: YES) /Applications/MAMP/htdocs MAMP/nazarethnet/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2024-06-27 23:15:46 --> Unable to connect to the database
ERROR - 2024-06-27 23:15:46 --> Severity: error --> Exception: Class 'EduAppGT' not found /Applications/MAMP/htdocs MAMP/nazarethnet/system/core/CodeIgniter.php 370
ERROR - 2024-06-27 23:16:45 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'eduappgt_app'@'localhost' (using password: YES) /Applications/MAMP/htdocs MAMP/nazarethnet/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2024-06-27 23:16:45 --> Unable to connect to the database
ERROR - 2024-06-27 23:16:45 --> Severity: error --> Exception: Class 'EduAppGT' not found /Applications/MAMP/htdocs MAMP/nazarethnet/system/core/CodeIgniter.php 370
ERROR - 2024-06-27 23:17:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'eduappgt_app'@'localhost' (using password: YES) /Applications/MAMP/htdocs MAMP/nazarethnet/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2024-06-27 23:17:07 --> Unable to connect to the database
ERROR - 2024-06-27 23:17:07 --> Severity: error --> Exception: Class 'EduAppGT' not found /Applications/MAMP/htdocs MAMP/nazarethnet/system/core/CodeIgniter.php 370
ERROR - 2024-06-27 23:18:21 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'eduappgt_app' /Applications/MAMP/htdocs MAMP/nazarethnet/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2024-06-27 23:18:21 --> Unable to connect to the database
ERROR - 2024-06-27 23:18:21 --> Severity: error --> Exception: Class 'EduAppGT' not found /Applications/MAMP/htdocs MAMP/nazarethnet/system/core/CodeIgniter.php 370
ERROR - 2024-06-27 11:19:51 --> Severity: 8192 --> Methods with the same name as their class will not be constructors in a future version of PHP; Paypal has a deprecated constructor /Applications/MAMP/htdocs MAMP/nazarethnet/application/libraries/Paypal.php 93
ERROR - 2024-06-27 11:21:16 --> Severity: 8192 --> Methods with the same name as their class will not be constructors in a future version of PHP; Paypal has a deprecated constructor /Applications/MAMP/htdocs MAMP/nazarethnet/application/libraries/Paypal.php 93
ERROR - 2024-06-27 11:21:17 --> Severity: Notice --> session_start(): A session had already been started - ignoring /Applications/MAMP/htdocs MAMP/nazarethnet/public/face/config.php 2
ERROR - 2024-06-27 11:23:00 --> Severity: 8192 --> Methods with the same name as their class will not be constructors in a future version of PHP; Paypal has a deprecated constructor /Applications/MAMP/htdocs MAMP/nazarethnet/application/libraries/Paypal.php 93
ERROR - 2024-06-27 11:23:00 --> Severity: Notice --> session_start(): A session had already been started - ignoring /Applications/MAMP/htdocs MAMP/nazarethnet/public/face/config.php 2
ERROR - 2024-06-27 11:23:10 --> Severity: 8192 --> Methods with the same name as their class will not be constructors in a future version of PHP; Paypal has a deprecated constructor /Applications/MAMP/htdocs MAMP/nazarethnet/application/libraries/Paypal.php 93
ERROR - 2024-06-27 11:23:10 --> Severity: 8192 --> Methods with the same name as their class will not be constructors in a future version of PHP; Paypal has a deprecated constructor /Applications/MAMP/htdocs MAMP/nazarethnet/application/libraries/Paypal.php 93
ERROR - 2024-06-27 11:23:10 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-06-27 11:23:10 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-06-27 11:23:10 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-06-27 11:23:10 --> Query error: Expression #1 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'eduappgt_app.message.message_id' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT *
FROM `message`
WHERE `read_status` = 0
AND `reciever` = 'admin-2'
GROUP BY `message_thread_code`
ERROR - 2024-06-27 11:23:57 --> Severity: 8192 --> Methods with the same name as their class will not be constructors in a future version of PHP; Paypal has a deprecated constructor /Applications/MAMP/htdocs MAMP/nazarethnet/application/libraries/Paypal.php 93
ERROR - 2024-06-27 11:23:57 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-06-27 11:23:57 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-06-27 11:23:57 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-06-27 11:23:58 --> Severity: 8192 --> Methods with the same name as their class will not be constructors in a future version of PHP; Paypal has a deprecated constructor /Applications/MAMP/htdocs MAMP/nazarethnet/application/libraries/Paypal.php 93
ERROR - 2024-06-27 11:23:58 --> Severity: 8192 --> Methods with the same name as their class will not be constructors in a future version of PHP; Paypal has a deprecated constructor /Applications/MAMP/htdocs MAMP/nazarethnet/application/libraries/Paypal.php 93
