<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-05-17 00:45:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-05-17 02:00:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-05-17 03:33:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-05-17 04:53:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-05-17 14:55:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2024-05-17 20:37:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-05-17 22:22:55 --> 404 Page Not Found: Robotstxt/index
