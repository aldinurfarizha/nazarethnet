<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-05-21 02:53:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-05-21 03:31:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-05-21 04:06:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2024-05-21 06:16:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2024-05-21 08:27:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2024-05-21 10:16:36 --> 404 Page Not Found: Archivarixcmsphp/index
ERROR - 2024-05-21 17:30:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-05-21 19:56:30 --> 404 Page Not Found: Git/config
ERROR - 2024-05-21 19:56:32 --> 404 Page Not Found: Git/config
ERROR - 2024-05-21 21:12:40 --> 404 Page Not Found: Faviconico/index
