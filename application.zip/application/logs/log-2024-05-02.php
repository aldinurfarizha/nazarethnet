<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-05-02 07:13:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-05-02 11:48:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2024-05-02 11:49:35 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-02 11:49:35 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-02 11:56:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2024-05-02 09:15:36 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-02 09:15:36 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-02 09:20:34 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable /home/bosguy7i1szv/public_html/application/models/Crud.php 1862
ERROR - 2024-05-02 12:23:28 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-02 12:23:28 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-02 12:26:34 --> Severity: Warning --> A non-numeric value encountered /home/bosguy7i1szv/public_html/application/models/Crud.php 1707
ERROR - 2024-05-02 12:26:34 --> Severity: Warning --> A non-numeric value encountered /home/bosguy7i1szv/public_html/application/models/Crud.php 29
ERROR - 2024-05-02 12:26:58 --> Severity: Warning --> A non-numeric value encountered /home/bosguy7i1szv/public_html/application/models/Crud.php 29
ERROR - 2024-05-02 12:27:56 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable /home/bosguy7i1szv/public_html/application/models/Crud.php 1892
ERROR - 2024-05-02 12:27:56 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/bosguy7i1szv/public_html/application/models/Crud.php 1904
ERROR - 2024-05-02 12:28:01 --> Severity: Warning --> A non-numeric value encountered /home/bosguy7i1szv/public_html/application/models/Crud.php 29
ERROR - 2024-05-02 12:28:29 --> Severity: Warning --> A non-numeric value encountered /home/bosguy7i1szv/public_html/application/models/Crud.php 29
ERROR - 2024-05-02 12:30:36 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-02 12:30:36 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-02 12:30:46 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Token has been expired or revoked."
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-05-02 12:30:48 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Token has been expired or revoked."
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-05-02 12:30:50 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Token has been expired or revoked."
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-05-02 12:31:26 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Token has been expired or revoked."
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-05-02 12:32:56 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Token has been expired or revoked."
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-05-02 12:33:22 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-02 12:33:36 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-02 12:34:57 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Token has been expired or revoked."
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-05-02 12:37:54 --> Query error: Column 'title' cannot be null - Invalid query: INSERT INTO `homework` (`title`, `description`, `time_end`, `date_end`, `type`, `wall_type`, `exp`, `publish_date`, `upload_date`, `year`, `status`, `class_id`, `file_name`, `section_id`, `user`, `subject_id`, `sync_status`, `uploader_type`, `uploader_id`, `homework_code`, `media_type`) VALUES (NULL, NULL, NULL, NULL, NULL, 'homework', NULL, '2024-05-02 12:37:54', '02/05/2024 12:37PM', '2024', NULL, NULL, NULL, NULL, 'admin', NULL, 1, 'admin', '1', NULL, NULL)
ERROR - 2024-05-02 12:38:26 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Token has been expired or revoked."
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-05-02 12:38:48 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Token has been expired or revoked."
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-05-02 12:40:55 --> Query error: Column 'title' cannot be null - Invalid query: INSERT INTO `homework` (`title`, `description`, `time_end`, `date_end`, `type`, `wall_type`, `exp`, `publish_date`, `upload_date`, `year`, `status`, `class_id`, `file_name`, `section_id`, `user`, `subject_id`, `sync_status`, `uploader_type`, `uploader_id`, `homework_code`, `media_type`) VALUES (NULL, NULL, NULL, NULL, NULL, 'homework', NULL, '2024-05-02 12:40:55', '02/05/2024 12:40PM', '2024', NULL, NULL, NULL, NULL, 'admin', NULL, 1, 'admin', '1', NULL, NULL)
ERROR - 2024-05-02 12:42:56 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-02 12:42:56 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-02 12:43:05 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Token has been expired or revoked."
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-05-02 12:43:08 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Token has been expired or revoked."
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-05-02 12:43:17 --> Query error: Column 'title' cannot be null - Invalid query: INSERT INTO `homework` (`title`, `description`, `time_end`, `date_end`, `type`, `wall_type`, `exp`, `publish_date`, `upload_date`, `year`, `status`, `class_id`, `file_name`, `section_id`, `user`, `subject_id`, `sync_status`, `uploader_type`, `uploader_id`, `homework_code`, `media_type`) VALUES (NULL, NULL, NULL, NULL, NULL, 'homework', NULL, '2024-05-02 12:43:17', '02/05/2024 12:43PM', '2024', NULL, NULL, NULL, NULL, 'admin', NULL, 1, 'admin', '1', NULL, NULL)
ERROR - 2024-05-02 12:43:31 --> Query error: Column 'title' cannot be null - Invalid query: INSERT INTO `homework` (`title`, `description`, `time_end`, `date_end`, `type`, `wall_type`, `exp`, `publish_date`, `upload_date`, `year`, `status`, `class_id`, `file_name`, `section_id`, `user`, `subject_id`, `sync_status`, `uploader_type`, `uploader_id`, `homework_code`, `media_type`) VALUES (NULL, NULL, NULL, NULL, NULL, 'homework', NULL, '2024-05-02 12:43:31', '02/05/2024 12:43PM', '2024', NULL, NULL, NULL, NULL, 'admin', NULL, 1, 'admin', '1', NULL, NULL)
ERROR - 2024-05-02 12:45:20 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-02 12:46:07 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-02 12:46:21 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-02 12:46:26 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-02 12:46:26 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-02 12:46:27 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-02 12:46:34 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Token has been expired or revoked."
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-05-02 12:46:41 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-02 12:46:47 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-02 12:47:10 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-02 12:47:20 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-02 12:47:28 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-02 12:47:58 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-02 12:49:08 --> Severity: error --> Exception: Call to undefined function get_phrase() /home/bosguy7i1szv/public_html/application/views/backend/student/homework_room.php 273
ERROR - 2024-05-02 12:49:09 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-02 12:49:09 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-02 12:49:21 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-02 12:50:05 --> Severity: error --> Exception: Call to undefined function get_phrase() /home/bosguy7i1szv/public_html/application/views/backend/student/homework_room.php 273
ERROR - 2024-05-02 12:50:06 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-02 12:50:06 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-02 12:50:11 --> Severity: error --> Exception: Call to undefined function get_phrase() /home/bosguy7i1szv/public_html/application/views/backend/student/homework_room.php 273
ERROR - 2024-05-02 12:50:15 --> Severity: error --> Exception: Call to undefined function get_phrase() /home/bosguy7i1szv/public_html/application/views/backend/student/homework_room.php 273
ERROR - 2024-05-02 12:50:15 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-02 12:50:15 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-02 12:50:21 --> Severity: error --> Exception: Call to undefined function get_phrase() /home/bosguy7i1szv/public_html/application/views/backend/student/homework_room.php 273
ERROR - 2024-05-02 12:50:21 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-02 12:51:25 --> Severity: error --> Exception: Call to undefined function get_phrase() /home/bosguy7i1szv/public_html/application/views/backend/student/homework_room.php 273
ERROR - 2024-05-02 12:51:25 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-02 12:51:25 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-02 12:51:40 --> Severity: error --> Exception: Call to undefined function get_phrase() /home/bosguy7i1szv/public_html/application/views/backend/student/homework_room.php 273
ERROR - 2024-05-02 12:55:50 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Token has been expired or revoked."
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-05-02 12:55:57 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-02 12:56:26 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-02 12:57:21 --> Query error: Column 'title' cannot be null - Invalid query: INSERT INTO `homework` (`title`, `description`, `time_end`, `date_end`, `type`, `wall_type`, `exp`, `publish_date`, `upload_date`, `year`, `status`, `class_id`, `file_name`, `section_id`, `user`, `subject_id`, `sync_status`, `uploader_type`, `uploader_id`, `homework_code`, `media_type`) VALUES (NULL, NULL, NULL, NULL, NULL, 'homework', NULL, '2024-05-02 12:57:21', '02/05/2024 12:57PM', '2024', NULL, NULL, NULL, NULL, 'admin', NULL, 1, 'admin', '1', NULL, NULL)
ERROR - 2024-05-02 12:58:07 --> Query error: Column 'title' cannot be null - Invalid query: INSERT INTO `homework` (`title`, `description`, `time_end`, `date_end`, `type`, `wall_type`, `exp`, `publish_date`, `upload_date`, `year`, `status`, `class_id`, `file_name`, `section_id`, `user`, `subject_id`, `sync_status`, `uploader_type`, `uploader_id`, `homework_code`, `media_type`) VALUES (NULL, NULL, NULL, NULL, NULL, 'homework', NULL, '2024-05-02 12:58:07', '02/05/2024 12:58PM', '2024', NULL, NULL, NULL, NULL, 'admin', NULL, 1, 'admin', '1', NULL, NULL)
ERROR - 2024-05-02 12:58:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2024-05-02 12:59:22 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-02 12:59:22 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-02 12:59:22 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-02 12:59:33 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-02 13:00:37 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Token has been expired or revoked."
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-05-02 13:00:55 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Token has been expired or revoked."
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-05-02 13:02:12 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-02 13:02:12 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-02 13:02:12 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-02 13:02:19 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-02 13:22:18 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-02 13:22:18 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-02 13:22:18 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-02 13:35:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-05-02 13:35:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2024-05-02 16:44:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-05-02 21:34:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-05-02 21:34:09 --> 404 Page Not Found: Sitemaptxt/index
ERROR - 2024-05-02 21:41:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-05-02 21:41:06 --> 404 Page Not Found: Sitemap_indexxml/index
ERROR - 2024-05-02 21:50:36 --> 404 Page Not Found: Git/config
ERROR - 2024-05-02 21:55:09 --> 404 Page Not Found: Atomxml/index
ERROR - 2024-05-02 21:57:15 --> 404 Page Not Found: Sitemapxmlgz/index
ERROR - 2024-05-02 22:18:57 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2024-05-02 22:37:59 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2024-05-02 22:48:50 --> 404 Page Not Found: Atomxml/index
ERROR - 2024-05-02 23:01:08 --> 404 Page Not Found: Sitemaptxt/index
ERROR - 2024-05-02 23:03:27 --> 404 Page Not Found: Sitemapsxml/index
ERROR - 2024-05-02 23:04:11 --> 404 Page Not Found: Sitemap_indexxml/index
ERROR - 2024-05-02 23:07:21 --> 404 Page Not Found: Sitemapxmlgz/index
ERROR - 2024-05-02 23:26:40 --> 404 Page Not Found: Sitemapsxml/index
