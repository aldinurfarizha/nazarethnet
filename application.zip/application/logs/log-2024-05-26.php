<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-05-26 02:31:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-05-26 08:29:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-05-26 08:34:43 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2024-05-26 08:34:46 --> 404 Page Not Found: Wp-cronphp/index
ERROR - 2024-05-26 11:26:58 --> 404 Page Not Found: Wp-includes/ID3
ERROR - 2024-05-26 11:26:58 --> 404 Page Not Found: Feed/index
ERROR - 2024-05-26 11:26:58 --> 404 Page Not Found: Xmlrpcphp/index
ERROR - 2024-05-26 11:26:59 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2024-05-26 11:27:00 --> 404 Page Not Found: Web/wp-includes
ERROR - 2024-05-26 11:27:00 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2024-05-26 11:27:00 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2024-05-26 11:27:00 --> 404 Page Not Found: 2020/wp-includes
ERROR - 2024-05-26 11:27:01 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2024-05-26 11:27:02 --> 404 Page Not Found: 2021/wp-includes
ERROR - 2024-05-26 11:27:02 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2024-05-26 11:27:02 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2024-05-26 11:27:02 --> 404 Page Not Found: Test/wp-includes
ERROR - 2024-05-26 11:27:03 --> 404 Page Not Found: Site/wp-includes
ERROR - 2024-05-26 11:27:05 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2024-05-26 11:27:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-05-26 20:01:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-05-26 20:01:47 --> 404 Page Not Found: Sitemap_indexxml/index
