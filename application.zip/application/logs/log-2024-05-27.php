<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-05-27 06:32:08 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2024-05-27 06:32:08 --> 404 Page Not Found: Xmlrpcphp/index
ERROR - 2024-05-27 06:32:09 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2024-05-27 06:32:09 --> 404 Page Not Found: Web/wp-includes
ERROR - 2024-05-27 06:32:09 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2024-05-27 06:32:09 --> 404 Page Not Found: Website/wp-includes
ERROR - 2024-05-27 06:32:09 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2024-05-27 06:32:09 --> 404 Page Not Found: News/wp-includes
ERROR - 2024-05-27 06:32:10 --> 404 Page Not Found: 2020/wp-includes
ERROR - 2024-05-27 06:32:10 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2024-05-27 06:32:10 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2024-05-27 06:32:10 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2024-05-27 06:32:10 --> 404 Page Not Found: Test/wp-includes
ERROR - 2024-05-27 06:32:10 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2024-05-27 06:32:11 --> 404 Page Not Found: Site/wp-includes
ERROR - 2024-05-27 06:32:11 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2024-05-27 06:32:11 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2024-05-27 08:45:49 --> 404 Page Not Found: Sftp-configjson/index
ERROR - 2024-05-27 08:45:50 --> 404 Page Not Found: Vscode/sftp.json
ERROR - 2024-05-27 09:53:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-05-27 10:13:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-05-27 11:09:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-05-27 12:02:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-05-27 12:09:19 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2024-05-27 12:09:21 --> 404 Page Not Found: Wp-cronphp/index
ERROR - 2024-05-27 17:05:04 --> 404 Page Not Found: Faviconico/index
