<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-07-02 23:28:23 --> Severity: 8192 --> Methods with the same name as their class will not be constructors in a future version of PHP; Paypal has a deprecated constructor C:\xampp\htdocs\nazarethnet\application\libraries\Paypal.php 93
