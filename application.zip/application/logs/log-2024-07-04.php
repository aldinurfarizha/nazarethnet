<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-07-04 02:40:21 --> Severity: error --> Exception: Call to undefined function print_json() C:\xampp\htdocs\nazarethnet\application\controllers\Student.php 785
ERROR - 2024-07-04 02:40:29 --> Severity: error --> Exception: Call to undefined function print_json() C:\xampp\htdocs\nazarethnet\application\controllers\Student.php 785
ERROR - 2024-07-04 02:40:39 --> Severity: error --> Exception: Call to undefined function print_json() C:\xampp\htdocs\nazarethnet\application\controllers\Student.php 785
ERROR - 2024-07-04 02:40:43 --> Severity: error --> Exception: Call to undefined function print_json() C:\xampp\htdocs\nazarethnet\application\controllers\Student.php 785
ERROR - 2024-07-04 02:41:00 --> Severity: 8192 --> Methods with the same name as their class will not be constructors in a future version of PHP; Paypal has a deprecated constructor C:\xampp\htdocs\nazarethnet\application\libraries\Paypal.php 93
ERROR - 2024-07-04 02:41:00 --> Severity: error --> Exception: Call to undefined function print_json() C:\xampp\htdocs\nazarethnet\application\controllers\Student.php 785
ERROR - 2024-07-04 02:41:22 --> Severity: 8192 --> Methods with the same name as their class will not be constructors in a future version of PHP; Paypal has a deprecated constructor C:\xampp\htdocs\nazarethnet\application\libraries\Paypal.php 93
ERROR - 2024-07-04 02:43:56 --> Severity: 8192 --> Methods with the same name as their class will not be constructors in a future version of PHP; Paypal has a deprecated constructor C:\xampp\htdocs\nazarethnet\application\libraries\Paypal.php 94
ERROR - 2024-07-04 02:43:57 --> Severity: 8192 --> Methods with the same name as their class will not be constructors in a future version of PHP; Paypal has a deprecated constructor C:\xampp\htdocs\nazarethnet\application\libraries\Paypal.php 94
ERROR - 2024-07-04 02:51:09 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO), expecting ';' C:\xampp\htdocs\nazarethnet\application\helpers\global_helper.php 4
ERROR - 2024-07-04 02:59:00 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nazarethnet\application\views\backend\student\fancy.php 7
ERROR - 2024-07-04 02:59:51 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nazarethnet\application\views\backend\student\fancy.php 7
ERROR - 2024-07-04 03:03:00 --> Severity: Notice --> Undefined variable: subject C:\xampp\htdocs\nazarethnet\application\views\backend\student\subject.php 41
ERROR - 2024-07-04 03:03:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nazarethnet\application\views\backend\student\subject.php 41
ERROR - 2024-07-04 03:10:19 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\nazarethnet\application\controllers\Student.php 844
ERROR - 2024-07-04 03:10:32 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\nazarethnet\application\controllers\Student.php 973
ERROR - 2024-07-04 03:10:35 --> Severity: Notice --> Trying to get property 'exam_id' of non-object C:\xampp\htdocs\nazarethnet\application\controllers\Student.php 664
ERROR - 2024-07-04 03:10:35 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\nazarethnet\application\controllers\Student.php 669
ERROR - 2024-07-04 03:10:41 --> Severity: Notice --> Trying to get property 'exam_id' of non-object C:\xampp\htdocs\nazarethnet\application\controllers\Student.php 664
ERROR - 2024-07-04 03:10:41 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\nazarethnet\application\controllers\Student.php 669
ERROR - 2024-07-04 03:10:42 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\nazarethnet\application\controllers\Student.php 973
ERROR - 2024-07-04 03:10:47 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\nazarethnet\application\controllers\Student.php 844
ERROR - 2024-07-04 03:10:54 --> Severity: Notice --> Undefined index: wall_type C:\xampp\htdocs\nazarethnet\application\views\backend\student\subject_dashboard.php 170
ERROR - 2024-07-04 03:10:54 --> Severity: Notice --> Undefined index: wall_type C:\xampp\htdocs\nazarethnet\application\views\backend\student\subject_dashboard.php 367
ERROR - 2024-07-04 03:10:54 --> Severity: Notice --> Undefined index: wall_type C:\xampp\htdocs\nazarethnet\application\views\backend\student\subject_dashboard.php 413
ERROR - 2024-07-04 03:10:54 --> Severity: Notice --> Undefined index: wall_type C:\xampp\htdocs\nazarethnet\application\views\backend\student\subject_dashboard.php 463
ERROR - 2024-07-04 03:10:54 --> Severity: Notice --> Undefined index: wall_type C:\xampp\htdocs\nazarethnet\application\views\backend\student\subject_dashboard.php 170
ERROR - 2024-07-04 03:10:54 --> Severity: Notice --> Undefined index: wall_type C:\xampp\htdocs\nazarethnet\application\views\backend\student\subject_dashboard.php 367
ERROR - 2024-07-04 03:10:54 --> Severity: Notice --> Undefined index: wall_type C:\xampp\htdocs\nazarethnet\application\views\backend\student\subject_dashboard.php 413
ERROR - 2024-07-04 03:10:54 --> Severity: Notice --> Undefined index: wall_type C:\xampp\htdocs\nazarethnet\application\views\backend\student\subject_dashboard.php 463
ERROR - 2024-07-04 03:11:00 --> Severity: Notice --> Undefined index: wall_type C:\xampp\htdocs\nazarethnet\application\views\backend\student\subject_dashboard.php 170
ERROR - 2024-07-04 03:11:00 --> Severity: Notice --> Undefined index: wall_type C:\xampp\htdocs\nazarethnet\application\views\backend\student\subject_dashboard.php 367
ERROR - 2024-07-04 03:11:00 --> Severity: Notice --> Undefined index: wall_type C:\xampp\htdocs\nazarethnet\application\views\backend\student\subject_dashboard.php 413
ERROR - 2024-07-04 03:11:00 --> Severity: Notice --> Undefined index: wall_type C:\xampp\htdocs\nazarethnet\application\views\backend\student\subject_dashboard.php 463
ERROR - 2024-07-04 03:11:06 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\nazarethnet\application\controllers\Student.php 844
ERROR - 2024-07-04 03:11:11 --> Severity: Notice --> Undefined index: wall_type C:\xampp\htdocs\nazarethnet\application\views\backend\student\subject_dashboard.php 170
ERROR - 2024-07-04 03:11:11 --> Severity: Notice --> Undefined index: wall_type C:\xampp\htdocs\nazarethnet\application\views\backend\student\subject_dashboard.php 367
ERROR - 2024-07-04 03:11:11 --> Severity: Notice --> Undefined index: wall_type C:\xampp\htdocs\nazarethnet\application\views\backend\student\subject_dashboard.php 413
ERROR - 2024-07-04 03:11:11 --> Severity: Notice --> Undefined index: wall_type C:\xampp\htdocs\nazarethnet\application\views\backend\student\subject_dashboard.php 463
ERROR - 2024-07-04 03:14:05 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 03:14:05 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 03:14:05 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 03:14:21 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 03:14:21 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 03:14:21 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 03:14:28 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 03:14:28 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 03:14:28 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 03:14:28 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Bad Request"
}' C:\xampp\htdocs\nazarethnet\public\GoogleSDK\src\Google\Auth\OAuth2.php 378
ERROR - 2024-07-04 03:14:37 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 03:14:37 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 03:14:37 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 03:14:47 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 03:14:47 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 03:14:47 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 03:14:49 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 03:14:50 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 03:14:50 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 03:14:54 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 03:14:54 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 03:14:55 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 03:14:57 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 03:14:57 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 03:14:57 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 03:15:01 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 03:15:01 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 03:15:01 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 03:15:04 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 03:15:04 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 03:15:04 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 03:15:07 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 03:15:07 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 03:15:07 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 03:15:10 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 03:15:10 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 03:15:10 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 03:15:23 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 03:15:23 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 03:15:23 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 03:16:24 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 03:16:24 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 03:16:24 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 03:16:28 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 03:16:28 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 03:16:28 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 03:16:32 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 03:16:32 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 03:16:32 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 03:16:33 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 03:16:34 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 03:16:34 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 03:16:36 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 03:16:36 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 03:16:36 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 03:16:37 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-04 03:16:37 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-04 03:16:37 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-04 03:16:37 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-04 03:16:37 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-04 03:16:37 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-04 03:16:37 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-04 03:16:37 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-04 03:16:37 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-04 03:16:37 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-04 03:16:37 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-04 03:16:37 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-04 03:16:37 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-04 03:16:37 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-04 03:16:37 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-04 03:16:37 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-04 03:16:37 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-04 03:16:53 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 03:16:54 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 03:16:54 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 03:16:54 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\student_portal.php 104
ERROR - 2024-07-04 03:16:54 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\student_portal.php 104
ERROR - 2024-07-04 03:16:54 --> Severity: Notice --> Trying to get property 'route_name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\student_portal.php 127
ERROR - 2024-07-04 03:17:02 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 03:17:02 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 03:17:02 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 03:19:09 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 03:19:09 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 03:19:09 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 04:18:08 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 04:18:08 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 04:18:08 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 04:18:11 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 04:18:11 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 04:18:11 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 04:18:38 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 04:18:38 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 04:18:38 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 04:18:38 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\student_portal.php 104
ERROR - 2024-07-04 04:18:38 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\student_portal.php 104
ERROR - 2024-07-04 04:18:38 --> Severity: Notice --> Trying to get property 'route_name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\student_portal.php 127
ERROR - 2024-07-04 04:18:40 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 04:18:40 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 04:18:40 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 04:22:19 --> 404 Page Not Found: Admin/student_profile_class_section
ERROR - 2024-07-04 04:22:54 --> 404 Page Not Found: Admin/student_profile_class_section
ERROR - 2024-07-04 04:23:26 --> 404 Page Not Found: Admin/student_profile_class_section
ERROR - 2024-07-04 04:23:29 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 04:23:29 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 04:23:29 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 04:24:22 --> 404 Page Not Found: Admin/student_profile_class_section
ERROR - 2024-07-04 04:25:01 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 04:25:01 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 04:25:01 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 04:27:05 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 04:27:05 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 04:27:05 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 04:27:05 --> Severity: Notice --> Trying to get property 'phrase' of non-object C:\xampp\htdocs\nazarethnet\application\helpers\multi_language_helper.php 13
ERROR - 2024-07-04 04:28:10 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 04:28:10 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 04:28:10 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 04:28:18 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 04:28:18 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 04:28:18 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 04:28:31 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 04:28:31 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 04:28:31 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 04:28:33 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 04:28:33 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 04:28:33 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 04:28:33 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\student_portal.php 104
ERROR - 2024-07-04 04:28:33 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\student_portal.php 104
ERROR - 2024-07-04 04:28:33 --> Severity: Notice --> Trying to get property 'route_name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\student_portal.php 127
ERROR - 2024-07-04 04:28:37 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 04:28:37 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 04:28:37 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 04:28:41 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 04:28:41 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 04:28:41 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 04:28:41 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\student_portal.php 104
ERROR - 2024-07-04 04:28:41 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\student_portal.php 104
ERROR - 2024-07-04 04:28:41 --> Severity: Notice --> Trying to get property 'route_name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\student_portal.php 127
ERROR - 2024-07-04 04:29:18 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 04:29:18 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 04:29:18 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 04:29:18 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\student_portal.php 104
ERROR - 2024-07-04 04:29:18 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\student_portal.php 104
ERROR - 2024-07-04 04:29:18 --> Severity: Notice --> Trying to get property 'route_name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\student_portal.php 127
ERROR - 2024-07-04 04:29:20 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 04:29:20 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 04:29:20 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 04:29:20 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\student_portal.php 104
ERROR - 2024-07-04 04:29:20 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\student_portal.php 104
ERROR - 2024-07-04 04:29:20 --> Severity: Notice --> Trying to get property 'route_name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\student_portal.php 127
ERROR - 2024-07-04 04:29:21 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 04:29:21 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 04:29:21 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 04:29:24 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 04:29:24 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 04:29:24 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 04:29:38 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 04:29:38 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 04:29:38 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 04:29:38 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\student_portal.php 104
ERROR - 2024-07-04 04:29:38 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\student_portal.php 104
ERROR - 2024-07-04 04:29:38 --> Severity: Notice --> Trying to get property 'route_name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\student_portal.php 127
ERROR - 2024-07-04 04:30:03 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 04:30:03 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 04:30:03 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 04:30:05 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 04:30:05 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 04:30:05 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 04:30:22 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 04:30:22 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 04:30:22 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 04:30:38 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 04:30:38 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 04:30:38 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 04:32:36 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 04:32:36 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 04:32:36 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 04:32:36 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\student_portal.php 108
ERROR - 2024-07-04 04:32:36 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\student_portal.php 108
ERROR - 2024-07-04 04:32:36 --> Severity: Notice --> Trying to get property 'route_name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\student_portal.php 132
ERROR - 2024-07-04 04:32:40 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 04:32:40 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 04:32:40 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 04:32:44 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 04:32:44 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 04:32:44 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 04:32:48 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 04:32:48 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 04:32:48 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 04:32:50 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 04:32:50 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 04:32:50 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 04:32:53 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 04:32:53 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 04:32:53 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 04:32:56 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 04:32:56 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 04:32:56 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 04:33:04 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 04:33:04 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 04:33:04 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 04:33:08 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 04:33:08 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 04:33:08 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 04:33:45 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 04:33:45 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 04:33:45 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 04:33:49 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 04:33:49 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 04:33:49 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 04:33:53 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 04:33:53 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 04:33:53 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 04:33:57 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 04:33:57 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 04:33:57 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 04:34:42 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 04:34:42 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 04:34:42 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 04:35:04 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 04:35:05 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 04:35:05 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 04:35:22 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 04:35:22 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 04:35:22 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 04:35:59 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 04:35:59 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 04:35:59 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 04:35:59 --> Severity: Notice --> Trying to get property 'phrase' of non-object C:\xampp\htdocs\nazarethnet\application\helpers\multi_language_helper.php 13
ERROR - 2024-07-04 04:36:20 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 04:36:20 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 04:36:20 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 04:37:30 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 04:37:31 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 04:37:31 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 04:46:51 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 04:46:51 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 04:46:51 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 04:51:11 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 04:51:11 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 04:51:11 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 04:51:11 --> Severity: error --> Exception: Call to undefined function getStudentClassAndSectionById() C:\xampp\htdocs\nazarethnet\application\views\backend\admin\student_profile_class_section.php 73
ERROR - 2024-07-04 04:54:51 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 04:54:51 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 04:54:51 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 04:54:51 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '*
FROM `enroll`, `settings`
WHERE `year` = '2024'
AND `type` = 'running_year'
OR' at line 1 - Invalid query: SELECT *, *
FROM `enroll`, `settings`
WHERE `year` = '2024'
AND `type` = 'running_year'
ORDER BY `creation_timestamp` DESC
ERROR - 2024-07-04 04:56:10 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 04:56:10 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 04:56:10 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 04:56:10 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '*
FROM `enroll`, `settings`
WHERE `year` = '2024'
AND `type` = 'running_year'
OR' at line 1 - Invalid query: SELECT *, *
FROM `enroll`, `settings`
WHERE `year` = '2024'
AND `type` = 'running_year'
ORDER BY `creation_timestamp` DESC
ERROR - 2024-07-04 04:57:04 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 04:57:04 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 04:57:04 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 04:57:04 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '*
FROM `enroll`, `settings`
WHERE `year` = '2024'
AND `type` = 'running_year'
OR' at line 1 - Invalid query: SELECT *, *
FROM `enroll`, `settings`
WHERE `year` = '2024'
AND `type` = 'running_year'
ORDER BY `creation_timestamp` DESC
ERROR - 2024-07-04 04:57:37 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 04:57:37 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 04:57:37 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 04:57:37 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '*
FROM `enroll`, `settings`
WHERE `type` = 'running_year'' at line 1 - Invalid query: SELECT *, *
FROM `enroll`, `settings`
WHERE `type` = 'running_year'
ERROR - 2024-07-04 04:57:47 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 04:57:47 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 04:57:47 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 04:58:08 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 04:58:08 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 04:58:08 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 04:58:39 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 04:58:39 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 04:58:39 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 04:58:39 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '*
FROM `enroll`, `settings`
WHERE `type` = 'running_year'' at line 1 - Invalid query: SELECT *, *
FROM `enroll`, `settings`
WHERE `type` = 'running_year'
ERROR - 2024-07-04 04:59:20 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 04:59:20 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 04:59:20 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 04:59:40 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 04:59:40 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 04:59:40 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 04:59:40 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '*
FROM `enroll`, `settings`
WHERE `type` = 'running_year'' at line 1 - Invalid query: SELECT *, *
FROM `enroll`, `settings`
WHERE `type` = 'running_year'
ERROR - 2024-07-04 05:00:59 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 05:00:59 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 05:00:59 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 05:00:59 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '*
FROM `enroll`, `settings`
WHERE `type` = 'running_year'' at line 1 - Invalid query: SELECT *, *
FROM `enroll`, `settings`
WHERE `type` = 'running_year'
ERROR - 2024-07-04 05:01:51 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 05:01:51 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 05:01:51 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 05:05:07 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 05:05:07 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 05:05:07 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 05:07:55 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 05:07:55 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 05:07:55 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 05:08:08 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 05:08:08 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 05:08:08 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 05:08:13 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 05:08:13 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 05:08:13 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 05:08:15 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 05:08:15 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 05:08:15 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 05:08:15 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\student_portal.php 108
ERROR - 2024-07-04 05:08:15 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\student_portal.php 108
ERROR - 2024-07-04 05:08:15 --> Severity: Notice --> Trying to get property 'route_name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\student_portal.php 132
ERROR - 2024-07-04 05:08:21 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 05:08:21 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 05:08:21 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 05:08:26 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 05:08:26 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 05:08:26 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 05:08:30 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 05:08:31 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 05:08:31 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 05:08:33 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 05:08:33 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 05:08:33 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 05:08:38 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 05:08:38 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 05:08:38 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 05:09:30 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 05:09:30 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 05:09:30 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 05:09:41 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 05:09:41 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 05:09:41 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 05:09:59 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 05:09:59 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 05:09:59 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 05:10:32 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 05:10:32 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 05:10:32 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 05:10:40 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 05:10:40 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 05:10:40 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 05:12:01 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 05:12:01 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 05:12:01 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 05:12:11 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 05:12:11 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 05:12:11 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 05:12:26 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 05:12:26 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 05:12:26 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 05:13:24 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 05:13:24 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 05:13:24 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 05:13:27 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 05:13:27 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 05:13:28 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 05:13:34 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Bad Request"
}' C:\xampp\htdocs\nazarethnet\public\GoogleSDK\src\Google\Auth\OAuth2.php 378
ERROR - 2024-07-04 05:13:37 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 05:13:37 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 05:13:37 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 05:13:40 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 05:13:40 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 05:13:40 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 05:13:40 --> Severity: Notice --> Undefined variable: class_id C:\xampp\htdocs\nazarethnet\application\views\backend\admin\fancy.php 96
ERROR - 2024-07-04 05:13:54 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 05:13:54 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 05:13:54 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 05:13:57 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 05:13:57 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 05:13:57 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 05:14:12 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 05:14:12 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 05:14:12 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 05:14:45 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 05:14:45 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 05:14:45 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 05:15:25 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 05:15:25 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 05:15:25 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 05:15:42 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 05:15:42 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 05:15:42 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 05:15:55 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 05:15:55 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 05:15:55 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 05:16:19 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 05:16:19 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 05:16:19 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 05:16:37 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 05:16:37 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 05:16:37 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 05:17:06 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 05:17:06 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 05:17:06 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 05:17:12 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 05:17:12 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 05:17:12 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 05:18:27 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 05:18:27 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 05:18:28 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 05:18:32 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 05:18:32 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 05:18:32 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 05:18:35 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 05:18:35 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 05:18:35 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 05:18:37 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 05:18:37 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 05:18:37 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 05:18:40 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 05:18:40 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 05:18:40 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 05:18:41 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 05:18:41 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 05:18:41 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 05:18:44 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 05:18:44 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 05:18:44 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 05:19:15 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 05:19:15 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 05:19:15 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 05:19:18 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 05:19:18 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 05:19:18 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 05:19:30 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 05:19:30 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 05:19:30 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 05:19:41 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 05:19:41 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 05:19:41 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 05:19:46 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 05:19:46 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 05:19:46 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 22:42:08 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 22:42:09 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 22:42:09 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 22:42:23 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 22:42:23 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 22:42:23 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 22:42:27 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 22:42:27 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 22:42:27 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 22:42:28 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-04 22:42:28 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-04 22:42:28 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-04 22:42:28 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-04 22:42:28 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-04 22:42:28 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-04 22:42:28 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-04 22:42:28 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-04 22:42:28 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-04 22:42:28 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-04 22:42:28 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-04 22:42:28 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-04 22:42:28 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-04 22:42:28 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-04 22:42:29 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-04 22:42:29 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-04 22:42:29 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-04 22:42:33 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 22:42:33 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 22:42:33 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 22:42:35 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\student_portal.php 108
ERROR - 2024-07-04 22:42:35 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\student_portal.php 108
ERROR - 2024-07-04 22:42:35 --> Severity: Notice --> Trying to get property 'route_name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\student_portal.php 132
ERROR - 2024-07-04 22:42:42 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 22:42:42 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 22:42:42 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 22:42:47 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 22:42:47 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 22:42:47 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 22:45:38 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 22:45:38 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 22:45:38 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 22:45:40 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 22:45:40 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 22:45:40 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 22:45:43 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 22:45:43 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 22:45:43 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 22:46:13 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 22:46:14 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 22:46:15 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 22:46:24 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 22:46:25 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 22:46:25 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 22:50:19 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 22:50:19 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 22:50:19 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 22:50:21 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 22:50:21 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 22:50:21 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 22:50:22 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-04 22:50:22 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-04 22:50:22 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-04 22:50:22 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-04 22:50:22 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-04 22:50:22 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-04 22:50:22 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-04 22:50:22 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-04 22:50:22 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-04 22:50:22 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-04 22:50:22 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-04 22:50:22 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-04 22:50:22 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-04 22:50:22 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-04 22:50:22 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-04 22:50:22 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-04 22:50:22 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-04 22:50:26 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 22:50:26 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 22:50:26 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 22:50:26 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\student_portal.php 108
ERROR - 2024-07-04 22:50:26 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\student_portal.php 108
ERROR - 2024-07-04 22:50:26 --> Severity: Notice --> Trying to get property 'route_name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\student_portal.php 132
ERROR - 2024-07-04 22:50:39 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 22:50:39 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 22:50:39 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 22:50:44 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 22:50:44 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 22:50:44 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 22:51:51 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 22:51:51 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 22:51:51 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 22:51:53 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 22:51:53 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 22:51:53 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 22:51:59 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 22:51:59 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 22:51:59 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 22:52:02 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 22:52:02 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 22:52:02 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 22:52:57 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 22:52:57 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 22:52:57 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 22:52:59 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\nazarethnet\application\views\backend\admin\modal_add_class_section.php 6
ERROR - 2024-07-04 22:52:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nazarethnet\application\views\backend\admin\modal_add_class_section.php 6
ERROR - 2024-07-04 22:52:59 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\nazarethnet\application\views\backend\admin\modal_add_class_section.php 11
ERROR - 2024-07-04 22:52:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nazarethnet\application\views\backend\admin\modal_add_class_section.php 11
ERROR - 2024-07-04 22:52:59 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 22:52:59 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 22:53:00 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 22:53:08 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 22:53:08 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 22:53:09 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 22:53:11 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 22:53:11 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 22:53:11 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 22:53:11 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\nazarethnet\application\views\backend\admin\modal_add_class_section.php 6
ERROR - 2024-07-04 22:53:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nazarethnet\application\views\backend\admin\modal_add_class_section.php 6
ERROR - 2024-07-04 22:53:11 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\nazarethnet\application\views\backend\admin\modal_add_class_section.php 11
ERROR - 2024-07-04 22:53:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nazarethnet\application\views\backend\admin\modal_add_class_section.php 11
ERROR - 2024-07-04 22:54:36 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 22:54:36 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 22:54:36 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 22:54:37 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 22:54:37 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 22:54:38 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 22:54:38 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\nazarethnet\application\views\backend\admin\modal_add_class_section.php 6
ERROR - 2024-07-04 22:54:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nazarethnet\application\views\backend\admin\modal_add_class_section.php 6
ERROR - 2024-07-04 22:54:38 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\nazarethnet\application\views\backend\admin\modal_add_class_section.php 11
ERROR - 2024-07-04 22:54:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nazarethnet\application\views\backend\admin\modal_add_class_section.php 11
ERROR - 2024-07-04 23:00:16 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 23:00:16 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 23:00:16 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 23:00:18 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 23:00:18 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 23:00:18 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 23:09:48 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 23:09:49 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 23:09:49 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 23:10:02 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 23:10:02 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 23:10:02 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 23:10:15 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 23:10:15 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 23:10:15 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 23:10:17 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 23:10:17 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 23:10:18 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 23:10:20 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 23:10:20 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 23:10:20 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 23:13:09 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 23:13:09 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 23:13:09 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 23:13:11 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 23:13:11 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 23:13:11 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 23:14:56 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 23:14:56 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 23:14:56 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 23:14:57 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 23:14:57 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 23:14:57 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 23:15:33 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 23:15:34 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 23:15:34 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 23:15:36 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 23:15:36 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 23:15:36 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 23:15:50 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 23:15:50 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 23:15:50 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 23:15:53 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 23:15:53 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 23:15:53 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 23:25:20 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 23:25:20 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 23:25:21 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 23:25:57 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 23:25:57 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 23:25:57 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 23:36:23 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 23:36:23 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 23:36:23 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 23:36:25 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 23:36:25 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 23:36:25 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 23:37:04 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 23:37:04 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 23:37:04 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 23:37:06 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 23:37:06 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 23:37:06 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 23:44:58 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 23:44:58 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 23:44:58 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 23:45:00 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 23:45:00 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 23:45:01 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 23:46:15 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 23:46:15 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 23:46:15 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 23:46:18 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 23:46:18 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 23:46:18 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 23:46:24 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 23:46:24 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 23:46:24 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 23:46:40 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 23:46:40 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 23:46:40 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 23:48:24 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 23:48:24 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 23:48:24 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 23:48:43 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 23:48:43 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 23:48:43 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 23:48:44 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 23:48:44 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 23:48:44 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 23:48:47 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 23:48:47 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 23:48:47 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 23:49:22 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 23:49:22 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 23:49:22 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 23:49:24 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 23:49:24 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 23:49:24 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 23:49:36 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 23:49:36 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 23:49:36 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 23:49:51 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 23:49:51 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 23:49:51 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 23:49:56 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 23:49:57 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 23:49:57 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 23:50:06 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 23:50:06 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 23:50:06 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 23:50:12 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 23:50:12 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 23:50:12 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 23:50:29 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 23:50:29 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 23:50:29 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 23:50:29 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\student_portal.php 108
ERROR - 2024-07-04 23:50:29 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\student_portal.php 108
ERROR - 2024-07-04 23:50:30 --> Severity: Notice --> Trying to get property 'route_name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\student_portal.php 132
ERROR - 2024-07-04 23:50:31 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 23:50:32 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 23:50:32 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 23:50:34 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 23:50:34 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 23:50:34 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 23:50:38 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 23:50:38 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 23:50:38 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 23:50:56 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 23:50:56 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 23:50:56 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 23:50:59 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 23:50:59 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 23:50:59 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 23:51:03 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 23:51:03 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 23:51:03 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 23:51:08 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 23:51:08 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 23:51:08 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-04 23:51:12 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-04 23:51:12 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-04 23:51:12 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
