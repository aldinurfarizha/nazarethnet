<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-05-16 02:57:41 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2024-05-16 04:01:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-05-16 08:28:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-05-16 09:47:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-05-16 09:59:59 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2024-05-16 15:37:11 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2024-05-16 15:37:12 --> 404 Page Not Found: Administrator/index.php
ERROR - 2024-05-16 15:37:12 --> 404 Page Not Found: View-source:/index
ERROR - 2024-05-16 15:37:13 --> 404 Page Not Found: Misc/ajax.js
ERROR - 2024-05-16 18:43:00 --> 404 Page Not Found: Robotstxt/index
