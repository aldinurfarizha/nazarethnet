<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-05-01 09:05:34 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-01 09:05:34 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-01 00:12:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-05-01 00:12:41 --> 404 Page Not Found: Sitemapsxml/index
ERROR - 2024-05-01 11:54:00 --> 404 Page Not Found: Img1wsimgcom/traffic-assets
ERROR - 2024-05-01 23:26:09 --> 404 Page Not Found: Robotstxt/index
