<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-07-09 07:22:22 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\nazarethnet\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-07-09 07:22:22 --> Unable to connect to the database
ERROR - 2024-07-09 07:22:22 --> Severity: error --> Exception: Class 'EduAppGT' not found C:\xampp\htdocs\nazarethnet\system\core\CodeIgniter.php 370
ERROR - 2024-07-09 00:56:42 --> Severity: error --> Exception: syntax error, unexpected ';' C:\xampp\htdocs\nazarethnet\application\views\backend\admin\new_student.php 165
ERROR - 2024-07-09 01:06:38 --> 404 Page Not Found: Public/style
ERROR - 2024-07-09 01:07:41 --> 404 Page Not Found: Public/style
ERROR - 2024-07-09 01:27:17 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-09 01:27:17 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-09 01:27:17 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-09 01:27:19 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-09 01:27:19 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-09 01:27:19 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-09 01:27:59 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-09 01:27:59 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-09 01:27:59 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-09 01:33:40 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-09 01:33:40 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-09 01:33:40 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-09 01:33:42 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-09 01:33:42 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-09 01:33:42 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-09 01:33:59 --> 404 Page Not Found: Public/style
ERROR - 2024-07-09 01:34:33 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-09 01:34:33 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-09 01:34:33 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-09 01:34:34 --> 404 Page Not Found: Public/style
ERROR - 2024-07-09 01:42:55 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-09 01:42:55 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-09 01:42:55 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-09 01:43:41 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-09 01:43:41 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-09 01:43:41 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-09 01:43:48 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-09 01:43:48 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-09 01:43:48 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-09 01:43:50 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-09 01:43:50 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-09 01:43:50 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-09 01:43:50 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-09 01:43:50 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-09 01:43:50 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-09 01:43:50 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-09 01:43:50 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-09 01:43:50 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-09 01:43:50 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-09 01:43:50 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-09 01:43:50 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-09 01:43:50 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-09 01:43:50 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-09 01:43:50 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-09 01:43:50 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-09 01:43:50 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-09 01:43:50 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-09 01:43:50 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-09 01:43:50 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-09 01:43:57 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-09 01:43:57 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-09 01:43:57 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-09 01:43:57 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\student_portal.php 98
ERROR - 2024-07-09 01:43:57 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\student_portal.php 98
ERROR - 2024-07-09 01:44:05 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-09 01:44:05 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-09 01:44:05 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-09 01:44:07 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-09 01:44:07 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-09 01:44:07 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-09 01:44:23 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-09 01:44:23 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-09 01:44:23 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-09 01:44:31 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-09 01:44:31 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-09 01:44:31 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-09 01:44:36 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-09 01:44:36 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-09 01:44:36 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-09 01:44:36 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\student_portal.php 98
ERROR - 2024-07-09 01:44:36 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\student_portal.php 98
ERROR - 2024-07-09 01:48:32 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-09 01:48:32 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-09 01:48:32 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-09 01:48:38 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-09 01:48:38 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-09 01:48:38 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-09 01:48:59 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-09 01:48:59 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-09 01:48:59 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-09 01:49:09 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-09 01:49:09 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-09 01:49:09 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-09 01:49:09 --> Severity: Notice --> session_start(): A session had already been started - ignoring C:\xampp\htdocs\nazarethnet\public\face\config.php 2
ERROR - 2024-07-09 01:49:16 --> 404 Page Not Found: Public/style
ERROR - 2024-07-09 01:49:16 --> 404 Page Not Found: Public/style
ERROR - 2024-07-09 01:49:16 --> 404 Page Not Found: Public/style
ERROR - 2024-07-09 01:49:16 --> 404 Page Not Found: Public/style
ERROR - 2024-07-09 01:49:38 --> Severity: Notice --> session_start(): A session had already been started - ignoring C:\xampp\htdocs\nazarethnet\public\face\config.php 2
ERROR - 2024-07-09 01:49:42 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-09 01:49:42 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-09 01:49:42 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-09 22:33:18 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-09 22:40:03 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\xampp\htdocs\nazarethnet\system\libraries\Email.php 1903
