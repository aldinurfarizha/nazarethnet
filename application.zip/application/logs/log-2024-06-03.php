<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-06-03 03:12:32 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2024-06-03 03:12:32 --> 404 Page Not Found: Xmlrpcphp/index
ERROR - 2024-06-03 03:12:33 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2024-06-03 03:12:33 --> 404 Page Not Found: Web/wp-includes
ERROR - 2024-06-03 03:12:33 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2024-06-03 03:12:33 --> 404 Page Not Found: Website/wp-includes
ERROR - 2024-06-03 03:12:33 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2024-06-03 03:12:34 --> 404 Page Not Found: News/wp-includes
ERROR - 2024-06-03 03:12:34 --> 404 Page Not Found: 2018/wp-includes
ERROR - 2024-06-03 03:12:34 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2024-06-03 03:12:34 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2024-06-03 03:12:35 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2024-06-03 03:12:35 --> 404 Page Not Found: Test/wp-includes
ERROR - 2024-06-03 03:12:35 --> 404 Page Not Found: Media/wp-includes
ERROR - 2024-06-03 03:12:35 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2024-06-03 03:12:35 --> 404 Page Not Found: Site/wp-includes
ERROR - 2024-06-03 03:12:36 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2024-06-03 03:12:36 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2024-06-03 10:42:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-06-03 15:20:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-06-03 18:14:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-06-03 19:01:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-06-03 19:01:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-06-03 19:39:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-06-03 23:10:38 --> 404 Page Not Found: Robotstxt/index
