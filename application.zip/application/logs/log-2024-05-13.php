<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-05-13 03:18:12 --> 404 Page Not Found: Sitemapxmlgz/index
ERROR - 2024-05-13 04:06:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-05-13 04:13:06 --> 404 Page Not Found: Sitemapxmlgz/index
ERROR - 2024-05-13 09:37:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2024-05-13 11:05:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2024-05-13 11:06:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2024-05-13 12:08:49 --> 404 Page Not Found: Robotstxt/index
