<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-07-05 02:36:03 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-05 02:36:03 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-05 02:36:04 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-05 02:36:06 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-05 02:36:06 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-05 02:36:06 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-05 02:36:06 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-05 02:36:06 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-05 02:36:06 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-05 02:36:06 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-05 02:36:06 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-05 02:36:06 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-05 02:36:06 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-05 02:36:06 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-05 02:36:06 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-05 02:36:06 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-05 02:36:06 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-05 02:36:06 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-05 02:36:06 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-05 02:36:06 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-05 02:36:06 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-05 02:36:06 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-05 02:36:06 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\students.php 109
ERROR - 2024-07-05 02:54:38 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-05 02:54:38 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-05 02:54:38 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-05 02:54:38 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\student_portal.php 108
ERROR - 2024-07-05 02:54:38 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\student_portal.php 108
ERROR - 2024-07-05 02:54:39 --> Severity: Notice --> Trying to get property 'route_name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\student_portal.php 132
ERROR - 2024-07-05 02:54:42 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-05 02:54:42 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-05 02:54:42 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-05 02:54:47 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-05 02:54:47 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-05 02:54:47 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-05 02:54:51 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-05 02:54:51 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-05 02:54:51 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-05 02:56:44 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-05 02:56:44 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-05 02:56:44 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-05 02:56:46 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-05 02:56:46 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-05 02:56:46 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-05 02:56:51 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-05 02:56:51 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-05 02:56:51 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-05 03:12:43 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-05 03:12:43 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-05 03:12:43 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-05 03:13:01 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-05 03:13:01 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-05 03:13:01 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-05 03:13:05 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-05 03:13:05 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-05 03:13:05 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-05 03:13:13 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-05 03:13:13 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-05 03:13:13 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-05 03:49:45 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-05 03:49:45 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-05 03:49:45 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-05 03:50:02 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-05 03:50:02 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-05 03:50:02 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-05 04:08:28 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-05 04:08:28 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-05 04:08:28 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-05 04:08:31 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-05 04:08:31 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-05 04:08:32 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-05 04:08:32 --> Severity: Notice --> Trying to get property 'phrase' of non-object C:\xampp\htdocs\nazarethnet\application\helpers\multi_language_helper.php 13
ERROR - 2024-07-05 04:08:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '*, `class`.`name` as `class_name`, `section`.`name` as `section_name`)
JOIN `cla' at line 2 - Invalid query: SELECT *
FROM (`enroll`.*, `class`.`name` as `class_name`, `section`.`name` as `section_name`)
JOIN `class` ON `class`.`class_id` = `enroll`.`class_id`
JOIN `section` ON `section`.`section_id` = `enroll`.`section_id`
WHERE `enroll` = '3'
ERROR - 2024-07-05 04:09:12 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-05 04:09:12 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-05 04:09:12 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-05 04:09:14 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '*, `class`.`name` as `class_name`, `section`.`name` as `section_name`)
JOIN `cla' at line 2 - Invalid query: SELECT *
FROM (`enroll`.*, `class`.`name` as `class_name`, `section`.`name` as `section_name`)
JOIN `class` ON `class`.`class_id` = `enroll`.`class_id`
JOIN `section` ON `section`.`section_id` = `enroll`.`section_id`
WHERE `enroll` = '3'
ERROR - 2024-07-05 04:09:14 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-05 04:09:14 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-05 04:09:14 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-05 04:09:22 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-05 04:09:22 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-05 04:09:22 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-05 04:09:56 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-05 04:09:56 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-05 04:09:56 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-05 04:09:59 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '*, `class`.`name` as `class_name`, `section`.`name` as `section_name`)
JOIN `cla' at line 2 - Invalid query: SELECT *
FROM (`enroll`.*, `class`.`name` as `class_name`, `section`.`name` as `section_name`)
JOIN `class` ON `class`.`class_id` = `enroll`.`class_id`
JOIN `section` ON `section`.`section_id` = `enroll`.`section_id`
WHERE `enroll` = '37'
ERROR - 2024-07-05 04:09:59 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-05 04:09:59 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-05 04:09:59 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-05 04:10:04 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-05 04:10:04 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-05 04:10:04 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-05 04:10:06 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '*, `class`.`name` as `class_name`, `section`.`name` as `section_name`)
JOIN `cla' at line 2 - Invalid query: SELECT *
FROM (`enroll`.*, `class`.`name` as `class_name`, `section`.`name` as `section_name`)
JOIN `class` ON `class`.`class_id` = `enroll`.`class_id`
JOIN `section` ON `section`.`section_id` = `enroll`.`section_id`
WHERE `enroll` = '37'
ERROR - 2024-07-05 04:10:06 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-05 04:10:07 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-05 04:10:07 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-05 04:11:00 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-05 04:11:00 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-05 04:11:00 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-05 04:11:39 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-05 04:11:39 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-05 04:11:39 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-05 04:11:39 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '*, `class`.`name` as `class_name`, `section`.`name` as `section_name`)
JOIN `cla' at line 2 - Invalid query: SELECT *
FROM (`enroll`.*, `class`.`name` as `class_name`, `section`.`name` as `section_name`)
JOIN `class` ON `class`.`class_id` = `enroll`.`class_id`
JOIN `section` ON `section`.`section_id` = `enroll`.`section_id`
WHERE `enroll` = '3'
ERROR - 2024-07-05 04:12:34 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-05 04:12:34 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-05 04:12:34 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-05 04:12:40 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-05 04:12:40 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-05 04:12:40 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-05 04:12:40 --> Severity: Notice --> Undefined variable: enrollData C:\xampp\htdocs\nazarethnet\application\views\backend\admin\modal_edit_class_section.php 12
ERROR - 2024-07-05 04:12:40 --> Severity: Notice --> Trying to get property 'roll' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\modal_edit_class_section.php 12
ERROR - 2024-07-05 04:13:01 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-05 04:13:01 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-05 04:13:01 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-05 04:13:04 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-05 04:13:04 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-05 04:13:04 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-05 04:13:04 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '*, `class`.`name` as `class_name`, `section`.`name` as `section_name`)
JOIN `cla' at line 2 - Invalid query: SELECT *
FROM (`enroll`.*, `class`.`name` as `class_name`, `section`.`name` as `section_name`)
JOIN `class` ON `class`.`class_id` = `enroll`.`class_id`
JOIN `section` ON `section`.`section_id` = `enroll`.`section_id`
WHERE `enroll` = '3'
ERROR - 2024-07-05 04:13:26 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-05 04:13:26 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-05 04:13:26 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-05 04:13:29 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-05 04:13:29 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-05 04:13:29 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-05 04:13:29 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '*, `class`.`name` as `class_name`, `section`.`name` as `section_name`)
JOIN `cla' at line 2 - Invalid query: SELECT `enroll`.*, `class`.`name` as `class_name`, `section`.`name` as `section_name`
FROM (`enroll`.*, `class`.`name` as `class_name`, `section`.`name` as `section_name`)
JOIN `class` ON `class`.`class_id` = `enroll`.`class_id`
JOIN `section` ON `section`.`section_id` = `enroll`.`section_id`
WHERE `enroll` = '3'
ERROR - 2024-07-05 04:13:53 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-05 04:13:53 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-05 04:13:53 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-05 04:13:55 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '*, `class`.`name` as `class_name`, `section`.`name` as `section_name`)
JOIN `cla' at line 2 - Invalid query: SELECT `enroll`.*, `class`.`name` as `class_name`, `section`.`name` as `section_name`
FROM (`enroll`.*, `class`.`name` as `class_name`, `section`.`name` as `section_name`)
JOIN `class` ON `class`.`class_id` = `enroll`.`class_id`
JOIN `section` ON `section`.`section_id` = `enroll`.`section_id`
WHERE `enroll` = '3'
ERROR - 2024-07-05 04:13:55 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-05 04:13:55 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-05 04:13:55 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-05 04:14:12 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-05 04:14:12 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-05 04:14:12 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-05 04:14:14 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-05 04:14:14 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-05 04:14:14 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-05 04:14:14 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '*, `class`.`name` as `class_name`, `section`.`name` as `section_name`)
JOIN `cla' at line 2 - Invalid query: SELECT `enroll`.*, `class`.`name` as `class_name`, `section`.`name` as `section_name`
FROM (`enroll`.*, `class`.`name` as `class_name`, `section`.`name` as `section_name`)
JOIN `class` ON `class`.`class_id` = `enroll`.`class_id`
JOIN `section` ON `section`.`section_id` = `enroll`.`section_id`
WHERE `enroll` = '3'
ERROR - 2024-07-05 04:14:17 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-05 04:14:17 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-05 04:14:17 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-05 04:14:20 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-05 04:14:20 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-05 04:14:20 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-05 04:14:21 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '*, `class`.`name` as `class_name`, `section`.`name` as `section_name`)
JOIN `cla' at line 2 - Invalid query: SELECT `enroll`.*, `class`.`name` as `class_name`, `section`.`name` as `section_name`
FROM (`enroll`.*, `class`.`name` as `class_name`, `section`.`name` as `section_name`)
JOIN `class` ON `class`.`class_id` = `enroll`.`class_id`
JOIN `section` ON `section`.`section_id` = `enroll`.`section_id`
WHERE `enroll` = '3'
ERROR - 2024-07-05 04:14:29 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-05 04:14:29 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-05 04:14:29 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-05 04:14:31 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '*, `class`.`name` as `class_name`, `section`.`name` as `section_name`)
JOIN `cla' at line 2 - Invalid query: SELECT `enroll`.*, `class`.`name` as `class_name`, `section`.`name` as `section_name`
FROM (`enroll`.*, `class`.`name` as `class_name`, `section`.`name` as `section_name`)
JOIN `class` ON `class`.`class_id` = `enroll`.`class_id`
JOIN `section` ON `section`.`section_id` = `enroll`.`section_id`
WHERE `enroll` = '3'
ERROR - 2024-07-05 04:14:32 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-05 04:14:32 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-05 04:14:32 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-05 04:14:48 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-05 04:14:48 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-05 04:14:48 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-05 04:14:50 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-05 04:14:50 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-05 04:14:50 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-05 04:14:50 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '*, `class`.`name` as `class_name`, `section`.`name` as `section_name`)
JOIN `cla' at line 2 - Invalid query: SELECT `enroll`.*, `class`.`name` as `class_name`, `section`.`name` as `section_name`
FROM (`enroll`.*, `class`.`name` as `class_name`, `section`.`name` as `section_name`)
JOIN `class` ON `class`.`class_id` = `enroll`.`class_id`
JOIN `section` ON `section`.`section_id` = `enroll`.`section_id`
WHERE `enroll` = '3'
ERROR - 2024-07-05 04:15:34 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-05 04:15:34 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-05 04:15:34 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-05 04:15:37 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-05 04:15:37 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-05 04:15:37 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-05 04:15:37 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '*, `class`.`name` as `class_name`, `section`.`name` as `section_name`)
JOIN `cla' at line 2 - Invalid query: SELECT `enroll`.*, `class`.`name` as `class_name`, `section`.`name` as `section_name`
FROM (`enroll`.*, `class`.`name` as `class_name`, `section`.`name` as `section_name`)
JOIN `class` ON `class`.`class_id` = `enroll`.`class_id`
JOIN `section` ON `section`.`section_id` = `enroll`.`section_id`
WHERE `enroll` = '3'
ERROR - 2024-07-05 04:15:57 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-05 04:15:57 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-05 04:15:57 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-05 04:16:02 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-05 04:16:02 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-05 04:16:02 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-05 04:16:02 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '*, `class`.`name` as `class_name`, `section`.`name` as `section_name`)
JOIN `cla' at line 2 - Invalid query: SELECT `enroll`.*, `class`.`name` as `class_name`, `section`.`name` as `section_name`
FROM (`enroll`.*, `class`.`name` as `class_name`, `section`.`name` as `section_name`)
JOIN `class` ON `class`.`class_id` = `enroll`.`class_id`
JOIN `section` ON `section`.`section_id` = `enroll`.`section_id`
WHERE `enroll` = '3'
ERROR - 2024-07-05 04:16:51 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-05 04:16:51 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-05 04:16:51 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-05 04:16:53 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-05 04:16:54 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-05 04:16:54 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-05 04:17:05 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-05 04:17:06 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-05 04:17:06 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-05 04:17:10 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '*, `class`.`name` as `class_name`, `section`.`name` as `section_name`)
JOIN `cla' at line 2 - Invalid query: SELECT `enroll`.*, `class`.`name` as `class_name`, `section`.`name` as `section_name`
FROM (`enroll`.*, `class`.`name` as `class_name`, `section`.`name` as `section_name`)
JOIN `class` ON `class`.`class_id` = `enroll`.`class_id`
JOIN `section` ON `section`.`section_id` = `enroll`.`section_id`
WHERE `enroll` = '3'
ERROR - 2024-07-05 04:17:10 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-05 04:17:10 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-05 04:17:10 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-05 04:17:37 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-05 04:17:37 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-05 04:17:38 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-05 04:17:40 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-05 04:17:40 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-05 04:17:40 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-05 04:17:40 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '*, `class`.`name` as `class_name`, `section`.`name` as `section_name`)
JOIN `cla' at line 2 - Invalid query: SELECT `enroll`.*, `class`.`name` as `class_name`, `section`.`name` as `section_name`
FROM (`enroll`.*, `class`.`name` as `class_name`, `section`.`name` as `section_name`)
JOIN `class` ON `class`.`class_id` = `enroll`.`class_id`
JOIN `section` ON `section`.`section_id` = `enroll`.`section_id`
WHERE `enroll` = '3'
ERROR - 2024-07-05 04:17:56 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-05 04:17:56 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-05 04:17:56 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-05 04:18:37 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-05 04:18:37 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-05 04:18:37 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-05 04:18:37 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '*, `class`.`name` as `class_name`, `section`.`name` as `section_name`)
JOIN `cla' at line 2 - Invalid query: SELECT `enroll`.*, `class`.`name` as `class_name`, `section`.`name` as `section_name`
FROM (`enroll`.*, `class`.`name` as `class_name`, `section`.`name` as `section_name`)
JOIN `class` ON `class`.`class_id` = `enroll`.`class_id`
JOIN `section` ON `section`.`section_id` = `enroll`.`section_id`
WHERE `enroll` = '3'
ERROR - 2024-07-05 04:19:18 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-05 04:19:18 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-05 04:19:18 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-05 04:19:18 --> Query error: Unknown column 'enroll' in 'where clause' - Invalid query: SELECT `enroll`.*, `class`.`name` as `class_name`, `section`.`name` as `section_name`
FROM `enroll`
JOIN `class` ON `class`.`class_id` = `enroll`.`class_id`
JOIN `section` ON `section`.`section_id` = `enroll`.`section_id`
WHERE `enroll` = '3'
ERROR - 2024-07-05 04:19:37 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-05 04:19:37 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-05 04:19:37 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-05 04:19:46 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-05 04:19:46 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-05 04:19:46 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-05 04:19:52 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-05 04:19:52 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-05 04:19:52 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-05 04:19:55 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\nazarethnet\application\views\backend\admin\modal_edit_class_section.php 35
ERROR - 2024-07-05 04:19:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nazarethnet\application\views\backend\admin\modal_edit_class_section.php 35
ERROR - 2024-07-05 04:19:55 --> Severity: Notice --> Trying to get property 'class_id' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\modal_edit_class_section.php 35
ERROR - 2024-07-05 04:19:55 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-05 04:19:55 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-05 04:19:55 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-05 04:20:16 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-05 04:20:16 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-05 04:20:16 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-05 04:20:21 --> Severity: Notice --> Undefined variable: class_id C:\xampp\htdocs\nazarethnet\application\views\backend\admin\modal_edit_class_section.php 37
ERROR - 2024-07-05 04:20:21 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-05 04:20:21 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-05 04:20:21 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-05 04:20:59 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-05 04:20:59 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-05 04:20:59 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-05 04:21:05 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-05 04:21:05 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-05 04:21:05 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-05 04:22:22 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-05 04:22:22 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-05 04:22:22 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-05 04:22:25 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-05 04:22:25 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-05 04:22:25 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-05 04:22:33 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-05 04:22:33 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-05 04:22:33 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-05 04:22:39 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-05 04:22:39 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-05 04:22:39 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-05 04:22:39 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\student_portal.php 108
ERROR - 2024-07-05 04:22:39 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\student_portal.php 108
ERROR - 2024-07-05 04:22:39 --> Severity: Notice --> Trying to get property 'route_name' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\student_portal.php 132
ERROR - 2024-07-05 04:22:42 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-05 04:22:42 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-05 04:22:42 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-05 04:23:53 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-05 04:23:53 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-05 04:23:53 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-05 04:23:56 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-05 04:23:56 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-05 04:23:56 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-05 04:24:10 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-05 04:24:10 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-05 04:24:10 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-05 04:24:32 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-05 04:24:32 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-05 04:24:32 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-05 04:25:33 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-05 04:25:33 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-05 04:25:33 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-05 04:25:35 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-05 04:25:35 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-05 04:25:35 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-05 04:25:42 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-05 04:25:42 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-05 04:25:42 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-05 09:12:10 --> Severity: Notice --> session_start(): A session had already been started - ignoring /Applications/MAMP/htdocs MAMP/nazarethnet/public/face/config.php 2
ERROR - 2024-07-05 09:12:58 --> Severity: Notice --> session_start(): A session had already been started - ignoring /Applications/MAMP/htdocs MAMP/nazarethnet/public/face/config.php 2
ERROR - 2024-07-05 09:13:22 --> Severity: Notice --> session_start(): A session had already been started - ignoring /Applications/MAMP/htdocs MAMP/nazarethnet/public/face/config.php 2
ERROR - 2024-07-05 09:13:22 --> Severity: Notice --> session_start(): A session had already been started - ignoring /Applications/MAMP/htdocs MAMP/nazarethnet/public/face/config.php 2
ERROR - 2024-07-05 09:13:29 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-05 09:13:29 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-05 09:13:29 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-05 09:13:29 --> Query error: Expression #1 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'eduappgt_app.message.message_id' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT *
FROM `message`
WHERE `read_status` = 0
AND `reciever` = 'admin-2'
GROUP BY `message_thread_code`
ERROR - 2024-07-05 09:15:39 --> Severity: Notice --> session_start(): A session had already been started - ignoring /Applications/MAMP/htdocs MAMP/nazarethnet/public/face/config.php 2
ERROR - 2024-07-05 09:15:44 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-05 09:15:44 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-05 09:15:44 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-05 09:15:44 --> Query error: Expression #1 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'eduappgt_app.message.message_id' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT *
FROM `message`
WHERE `read_status` = 0
AND `reciever` = 'admin-2'
GROUP BY `message_thread_code`
ERROR - 2024-07-05 09:16:04 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-05 09:16:04 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-05 09:16:04 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-05 09:16:11 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-05 09:16:11 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-05 09:16:11 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-05 09:16:14 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-05 09:16:14 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-05 09:16:14 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-05 09:16:15 --> Severity: Notice --> Trying to get property 'name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-05 09:16:15 --> Severity: Notice --> Trying to get property 'name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-05 09:16:15 --> Severity: Notice --> Trying to get property 'name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-05 09:16:15 --> Severity: Notice --> Trying to get property 'name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-05 09:16:15 --> Severity: Notice --> Trying to get property 'name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-05 09:16:15 --> Severity: Notice --> Trying to get property 'name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-05 09:16:15 --> Severity: Notice --> Trying to get property 'name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-05 09:16:15 --> Severity: Notice --> Trying to get property 'name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-05 09:16:15 --> Severity: Notice --> Trying to get property 'name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-05 09:16:15 --> Severity: Notice --> Trying to get property 'name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-05 09:16:15 --> Severity: Notice --> Trying to get property 'name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-05 09:16:15 --> Severity: Notice --> Trying to get property 'name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-05 09:16:15 --> Severity: Notice --> Trying to get property 'name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-05 09:16:15 --> Severity: Notice --> Trying to get property 'name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-05 09:16:15 --> Severity: Notice --> Trying to get property 'name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-05 09:16:15 --> Severity: Notice --> Trying to get property 'name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-05 09:16:15 --> Severity: Notice --> Trying to get property 'name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-05 09:16:15 --> Severity: Notice --> Trying to get property 'name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-05 09:16:17 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-05 09:16:17 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-05 09:16:17 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-05 09:16:18 --> Severity: Notice --> Trying to get property 'first_name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/student_portal.php 108
ERROR - 2024-07-05 09:16:18 --> Severity: Notice --> Trying to get property 'last_name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/student_portal.php 108
ERROR - 2024-07-05 09:16:18 --> Severity: Notice --> Trying to get property 'route_name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/student_portal.php 132
ERROR - 2024-07-05 09:16:22 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-05 09:16:22 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-05 09:16:22 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-05 09:16:22 --> Severity: Notice --> Trying to get property 'name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-05 09:16:22 --> Severity: Notice --> Trying to get property 'name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-05 09:16:22 --> Severity: Notice --> Trying to get property 'name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-05 09:16:22 --> Severity: Notice --> Trying to get property 'name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-05 09:16:23 --> Severity: Notice --> Trying to get property 'name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-05 09:16:23 --> Severity: Notice --> Trying to get property 'name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-05 09:16:23 --> Severity: Notice --> Trying to get property 'name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-05 09:16:23 --> Severity: Notice --> Trying to get property 'name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-05 09:16:23 --> Severity: Notice --> Trying to get property 'name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-05 09:16:23 --> Severity: Notice --> Trying to get property 'name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-05 09:16:23 --> Severity: Notice --> Trying to get property 'name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-05 09:16:23 --> Severity: Notice --> Trying to get property 'name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-05 09:16:23 --> Severity: Notice --> Trying to get property 'name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-05 09:16:23 --> Severity: Notice --> Trying to get property 'name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-05 09:16:23 --> Severity: Notice --> Trying to get property 'name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-05 09:16:23 --> Severity: Notice --> Trying to get property 'name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-05 09:16:23 --> Severity: Notice --> Trying to get property 'name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-05 09:16:23 --> Severity: Notice --> Trying to get property 'name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-05 09:16:30 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-05 09:16:30 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-05 09:16:30 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-05 09:16:33 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-05 09:16:33 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-05 09:16:33 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-05 09:16:33 --> Severity: Notice --> Trying to get property 'name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-05 09:16:33 --> Severity: Notice --> Trying to get property 'name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-05 09:16:33 --> Severity: Notice --> Trying to get property 'name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-05 09:16:33 --> Severity: Notice --> Trying to get property 'name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-05 09:16:33 --> Severity: Notice --> Trying to get property 'name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-05 09:16:33 --> Severity: Notice --> Trying to get property 'name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-05 09:16:33 --> Severity: Notice --> Trying to get property 'name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-05 09:16:34 --> Severity: Notice --> Trying to get property 'name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-05 09:16:34 --> Severity: Notice --> Trying to get property 'name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-05 09:16:34 --> Severity: Notice --> Trying to get property 'name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-05 09:16:34 --> Severity: Notice --> Trying to get property 'name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-05 09:16:34 --> Severity: Notice --> Trying to get property 'name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-05 09:16:34 --> Severity: Notice --> Trying to get property 'name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-05 09:16:34 --> Severity: Notice --> Trying to get property 'name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-05 09:16:34 --> Severity: Notice --> Trying to get property 'name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-05 09:16:34 --> Severity: Notice --> Trying to get property 'name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-05 09:16:34 --> Severity: Notice --> Trying to get property 'name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-05 09:16:34 --> Severity: Notice --> Trying to get property 'name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-05 09:16:38 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-05 09:16:38 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-05 09:16:38 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-05 09:16:38 --> Severity: Notice --> Trying to get property 'first_name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/student_portal.php 108
ERROR - 2024-07-05 09:16:38 --> Severity: Notice --> Trying to get property 'last_name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/student_portal.php 108
ERROR - 2024-07-05 09:16:38 --> Severity: Notice --> Trying to get property 'route_name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/student_portal.php 132
ERROR - 2024-07-05 09:16:50 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-05 09:16:50 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-05 09:16:50 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-05 09:16:51 --> Severity: Notice --> Trying to get property 'first_name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/student_portal.php 108
ERROR - 2024-07-05 09:16:51 --> Severity: Notice --> Trying to get property 'last_name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/student_portal.php 108
ERROR - 2024-07-05 09:16:51 --> Severity: Notice --> Trying to get property 'route_name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/student_portal.php 132
ERROR - 2024-07-05 09:16:54 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-05 09:16:54 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-05 09:16:54 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-05 09:16:55 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-05 09:16:55 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-05 09:16:55 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-05 09:16:56 --> Severity: Notice --> Trying to get property 'name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-05 09:16:56 --> Severity: Notice --> Trying to get property 'name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-05 09:16:56 --> Severity: Notice --> Trying to get property 'name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-05 09:16:56 --> Severity: Notice --> Trying to get property 'name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-05 09:16:56 --> Severity: Notice --> Trying to get property 'name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-05 09:16:56 --> Severity: Notice --> Trying to get property 'name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-05 09:16:56 --> Severity: Notice --> Trying to get property 'name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-05 09:16:56 --> Severity: Notice --> Trying to get property 'name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-05 09:16:56 --> Severity: Notice --> Trying to get property 'name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-05 09:16:56 --> Severity: Notice --> Trying to get property 'name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-05 09:16:56 --> Severity: Notice --> Trying to get property 'name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-05 09:16:56 --> Severity: Notice --> Trying to get property 'name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-05 09:16:56 --> Severity: Notice --> Trying to get property 'name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-05 09:16:56 --> Severity: Notice --> Trying to get property 'name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-05 09:16:56 --> Severity: Notice --> Trying to get property 'name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-05 09:16:56 --> Severity: Notice --> Trying to get property 'name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-05 09:16:56 --> Severity: Notice --> Trying to get property 'name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-05 09:16:56 --> Severity: Notice --> Trying to get property 'name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-05 09:17:15 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-05 09:17:16 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-05 09:17:16 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-05 09:17:16 --> Severity: Notice --> Trying to get property 'first_name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/student_portal.php 108
ERROR - 2024-07-05 09:17:16 --> Severity: Notice --> Trying to get property 'last_name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/student_portal.php 108
ERROR - 2024-07-05 09:17:16 --> Severity: Notice --> Trying to get property 'route_name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/student_portal.php 132
ERROR - 2024-07-05 09:17:18 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-05 09:17:18 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-05 09:17:18 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-05 09:17:22 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-05 09:17:22 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-05 09:17:22 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-05 21:17:51 --> Severity: Warning --> mysqli::real_connect(): Error while reading greeting packet. PID=97914 /Applications/MAMP/htdocs MAMP/nazarethnet/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2024-07-05 21:17:51 --> Severity: Warning --> mysqli::real_connect(): (HY000/2006): MySQL server has gone away /Applications/MAMP/htdocs MAMP/nazarethnet/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2024-07-05 21:17:51 --> Unable to connect to the database
ERROR - 2024-07-05 21:17:51 --> Severity: error --> Exception: Class 'EduAppGT' not found /Applications/MAMP/htdocs MAMP/nazarethnet/system/core/CodeIgniter.php 370
ERROR - 2024-07-05 09:18:02 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-05 09:18:02 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-05 09:18:02 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-05 09:18:06 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-05 09:18:06 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-05 09:18:06 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-05 09:40:39 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-05 09:40:39 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-05 09:40:39 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-05 09:40:39 --> Query error: Expression #1 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'eduappgt_app.message.message_id' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT *
FROM `message`
WHERE `read_status` = 0
AND `reciever` = 'admin-2'
GROUP BY `message_thread_code`
ERROR - 2024-07-05 09:40:51 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-05 09:40:51 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-05 09:40:51 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-05 09:42:02 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-05 09:42:02 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-05 09:42:02 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-05 09:42:42 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-05 09:42:42 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-05 09:42:42 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-05 09:42:45 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-05 09:42:45 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-05 09:42:45 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-05 09:42:52 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-05 09:42:52 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-05 09:42:52 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-05 09:44:20 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-05 09:44:20 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-05 09:44:20 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-05 09:44:58 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-05 09:44:58 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-05 09:44:59 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-05 09:48:31 --> Severity: Notice --> session_start(): A session had already been started - ignoring /Applications/MAMP/htdocs MAMP/nazarethnet/public/face/config.php 2
ERROR - 2024-07-05 09:48:43 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-05 09:48:43 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-05 09:48:43 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-05 09:49:28 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-05 09:49:28 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-05 09:49:28 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-05 09:49:36 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-05 09:49:36 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-05 09:49:36 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-05 09:49:36 --> Severity: Notice --> Trying to get property 'name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-05 09:49:36 --> Severity: Notice --> Trying to get property 'name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-05 09:49:36 --> Severity: Notice --> Trying to get property 'name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-05 09:49:36 --> Severity: Notice --> Trying to get property 'name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-05 09:49:36 --> Severity: Notice --> Trying to get property 'name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-05 09:49:36 --> Severity: Notice --> Trying to get property 'name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-05 09:49:36 --> Severity: Notice --> Trying to get property 'name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-05 09:49:36 --> Severity: Notice --> Trying to get property 'name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-05 09:49:36 --> Severity: Notice --> Trying to get property 'name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-05 09:49:36 --> Severity: Notice --> Trying to get property 'name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-05 09:49:36 --> Severity: Notice --> Trying to get property 'name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-05 09:49:36 --> Severity: Notice --> Trying to get property 'name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-05 09:49:36 --> Severity: Notice --> Trying to get property 'name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-05 09:49:36 --> Severity: Notice --> Trying to get property 'name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-05 09:49:36 --> Severity: Notice --> Trying to get property 'name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-05 09:49:36 --> Severity: Notice --> Trying to get property 'name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-05 09:49:36 --> Severity: Notice --> Trying to get property 'name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/students.php 109
ERROR - 2024-07-05 09:49:39 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-05 09:49:39 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-05 09:49:39 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-05 09:49:40 --> Severity: Notice --> Trying to get property 'first_name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/student_portal.php 108
ERROR - 2024-07-05 09:49:40 --> Severity: Notice --> Trying to get property 'last_name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/student_portal.php 108
ERROR - 2024-07-05 09:49:40 --> Severity: Notice --> Trying to get property 'route_name' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/student_portal.php 132
ERROR - 2024-07-05 09:49:43 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-05 09:49:43 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-05 09:49:43 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-05 09:49:48 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-05 09:49:48 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-05 09:49:48 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-05 09:49:58 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-05 09:49:58 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-05 09:49:58 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-05 09:52:21 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-05 09:52:21 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-05 09:52:21 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-05 09:52:22 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-05 09:52:22 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-05 09:52:22 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-05 09:52:31 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-05 09:52:31 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-05 09:52:31 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-05 09:53:45 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-05 09:53:45 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-05 09:53:45 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-05 09:53:54 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-05 09:53:54 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-05 09:53:54 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-05 09:54:00 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-05 09:54:00 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-05 09:54:00 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-05 09:54:53 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-05 09:54:53 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-05 09:54:53 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-05 09:55:00 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-05 09:55:00 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-05 09:55:01 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-05 09:55:40 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-05 09:55:40 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-05 09:55:40 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-05 09:56:17 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-05 09:56:17 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-05 09:56:17 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-05 09:56:19 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-05 09:56:19 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-05 09:56:19 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-05 09:56:34 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-05 09:56:34 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-05 09:56:34 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-05 09:56:37 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-05 09:56:37 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-05 09:56:37 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-05 09:56:47 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-05 09:56:47 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-05 09:56:48 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-05 09:56:50 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-05 09:56:50 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-05 09:56:50 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-05 09:56:55 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-05 09:56:55 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-05 09:56:55 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-05 09:58:03 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-05 09:58:03 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-05 09:58:04 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-05 09:58:07 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-05 09:58:07 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-05 09:58:07 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-05 09:58:10 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-05 09:58:10 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-05 09:58:10 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-05 09:58:14 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-05 09:58:14 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-05 09:58:14 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-05 10:02:03 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-05 10:02:03 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-05 10:02:03 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-05 10:02:17 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-05 10:02:17 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-05 10:02:17 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-05 10:03:38 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-05 10:03:38 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-05 10:03:38 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-05 10:03:44 --> Severity: Notice --> Undefined variable: student_id /Applications/MAMP/htdocs MAMP/nazarethnet/application/controllers/Admin.php 2281
ERROR - 2024-07-05 10:03:44 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-05 10:03:44 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-05 10:03:44 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-05 10:04:07 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-05 10:04:07 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-05 10:04:07 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-05 10:04:08 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-05 10:04:08 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-05 10:04:08 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-05 10:05:24 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-05 10:05:24 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-05 10:05:24 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-05 10:05:28 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-05 10:05:28 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-05 10:05:28 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-05 10:06:18 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-05 10:06:18 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-05 10:06:18 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-05 10:06:25 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-05 10:06:25 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-05 10:06:25 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-05 10:06:25 --> Query error: Expression #1 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'eduappgt_app.message.message_id' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT *
FROM `message`
WHERE `read_status` = 0
AND `reciever` = 'admin-2'
GROUP BY `message_thread_code`
ERROR - 2024-07-05 10:06:47 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-05 10:06:47 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-05 10:06:47 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-05 10:06:54 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-05 10:06:54 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-05 10:06:54 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 549
ERROR - 2024-07-05 10:06:59 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 71
ERROR - 2024-07-05 10:06:59 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 298
ERROR - 2024-07-05 10:06:59 --> Severity: Notice --> Trying to get property 'permissions' of non-object /Applications/MAMP/htdocs MAMP/nazarethnet/application/views/backend/admin/navigation.php 549
