<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-06-22 02:08:29 --> 404 Page Not Found: Archivarixcmsphp/index
ERROR - 2024-06-22 03:12:02 --> 404 Page Not Found: Sitemaptxt/index
ERROR - 2024-06-22 03:40:55 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2024-06-22 04:01:26 --> 404 Page Not Found: Sitemaptxt/index
ERROR - 2024-06-22 04:30:51 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2024-06-22 05:33:12 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2024-06-22 05:52:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-06-22 10:05:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-06-22 10:44:04 --> 404 Page Not Found: Js/tinymce
ERROR - 2024-06-22 12:45:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2024-06-22 14:13:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2024-06-22 17:21:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2024-06-22 17:31:58 --> 404 Page Not Found: Public/uploads
ERROR - 2024-06-22 17:31:58 --> 404 Page Not Found: Public/uploads
ERROR - 2024-06-22 17:31:58 --> 404 Page Not Found: Public/uploads
ERROR - 2024-06-22 17:31:58 --> 404 Page Not Found: Public/uploads
ERROR - 2024-06-22 18:29:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-06-22 20:03:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-06-22 22:45:23 --> 404 Page Not Found: Robotstxt/index
