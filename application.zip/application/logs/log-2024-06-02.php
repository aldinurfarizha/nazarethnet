<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-06-02 07:07:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-06-02 13:20:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-06-02 14:30:52 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2024-06-02 18:16:35 --> 404 Page Not Found: Wp-includes/ID3
ERROR - 2024-06-02 18:16:35 --> 404 Page Not Found: Feed/index
ERROR - 2024-06-02 18:16:35 --> 404 Page Not Found: Xmlrpcphp/index
ERROR - 2024-06-02 18:16:35 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2024-06-02 18:16:35 --> 404 Page Not Found: Web/wp-includes
ERROR - 2024-06-02 18:16:36 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2024-06-02 18:16:36 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2024-06-02 18:16:36 --> 404 Page Not Found: 2020/wp-includes
ERROR - 2024-06-02 18:16:36 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2024-06-02 18:16:36 --> 404 Page Not Found: 2021/wp-includes
ERROR - 2024-06-02 18:16:37 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2024-06-02 18:16:37 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2024-06-02 18:16:37 --> 404 Page Not Found: Test/wp-includes
ERROR - 2024-06-02 18:16:37 --> 404 Page Not Found: Site/wp-includes
ERROR - 2024-06-02 18:16:37 --> 404 Page Not Found: Cms/wp-includes
