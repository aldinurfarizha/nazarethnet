<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-05-08 07:37:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-05-08 07:37:50 --> 404 Page Not Found: Sitemapsxml/index
ERROR - 2024-05-08 08:44:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-05-08 09:13:10 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2024-05-08 09:13:10 --> 404 Page Not Found: Xmlrpcphp/index
ERROR - 2024-05-08 09:13:11 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2024-05-08 09:13:11 --> 404 Page Not Found: Web/wp-includes
ERROR - 2024-05-08 09:13:11 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2024-05-08 09:13:11 --> 404 Page Not Found: Website/wp-includes
ERROR - 2024-05-08 09:13:11 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2024-05-08 09:13:12 --> 404 Page Not Found: News/wp-includes
ERROR - 2024-05-08 09:13:12 --> 404 Page Not Found: 2018/wp-includes
ERROR - 2024-05-08 09:13:12 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2024-05-08 09:13:12 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2024-05-08 09:13:12 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2024-05-08 09:13:12 --> 404 Page Not Found: Test/wp-includes
ERROR - 2024-05-08 09:13:13 --> 404 Page Not Found: Media/wp-includes
ERROR - 2024-05-08 09:13:13 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2024-05-08 09:13:13 --> 404 Page Not Found: Site/wp-includes
ERROR - 2024-05-08 09:13:13 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2024-05-08 09:13:13 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2024-05-08 13:22:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-05-08 14:42:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-05-08 18:15:00 --> 404 Page Not Found: Proxyphp/index
ERROR - 2024-05-08 21:00:00 --> 404 Page Not Found: Robotstxt/index
