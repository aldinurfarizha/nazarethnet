<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-05-22 12:51:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-05-22 12:51:04 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2024-05-22 12:51:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-05-22 12:51:44 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2024-05-22 18:00:56 --> 404 Page Not Found: Git/config
ERROR - 2024-05-22 18:00:57 --> 404 Page Not Found: Git/config
ERROR - 2024-05-22 20:01:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-05-22 20:01:39 --> 404 Page Not Found: Sitemapsxml/index
ERROR - 2024-05-22 21:43:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-05-22 21:43:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-05-22 21:43:26 --> 404 Page Not Found: Faviconico/index
