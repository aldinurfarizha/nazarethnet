<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-05-19 02:57:26 --> 404 Page Not Found: Site/wp-includes
ERROR - 2024-05-19 02:57:26 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2024-05-19 02:57:26 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2024-05-19 08:31:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-05-19 08:47:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2024-05-19 09:23:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-05-19 09:23:37 --> 404 Page Not Found: Sitemap_indexxml/index
ERROR - 2024-05-19 11:10:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-05-19 13:13:49 --> 404 Page Not Found: DS_Store/index
ERROR - 2024-05-19 17:02:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-05-19 20:18:44 --> 404 Page Not Found: Img1wsimgcom/traffic-assets
ERROR - 2024-05-19 21:59:21 --> 404 Page Not Found: Faviconico/index
