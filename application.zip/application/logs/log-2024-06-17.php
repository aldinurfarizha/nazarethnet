<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-06-17 02:44:41 --> 404 Page Not Found: Admin/ckeditor
ERROR - 2024-06-17 06:48:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-06-17 09:07:16 --> 404 Page Not Found: Phpinfophp/index
ERROR - 2024-06-17 09:07:16 --> 404 Page Not Found: _profiler/phpinfo
ERROR - 2024-06-17 16:09:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-06-17 16:11:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2024-06-17 21:43:33 --> 404 Page Not Found: Robotstxt/index
