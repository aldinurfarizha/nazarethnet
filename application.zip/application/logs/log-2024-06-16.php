<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-06-16 03:19:18 --> 404 Page Not Found: Sitemapsxml/index
ERROR - 2024-06-16 04:13:36 --> 404 Page Not Found: Sitemapsxml/index
ERROR - 2024-06-16 05:23:09 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2024-06-16 05:23:09 --> 404 Page Not Found: Xmlrpcphp/index
ERROR - 2024-06-16 05:23:10 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2024-06-16 05:23:10 --> 404 Page Not Found: Web/wp-includes
ERROR - 2024-06-16 05:23:10 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2024-06-16 05:23:10 --> 404 Page Not Found: Website/wp-includes
ERROR - 2024-06-16 05:23:11 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2024-06-16 05:23:11 --> 404 Page Not Found: News/wp-includes
ERROR - 2024-06-16 05:23:11 --> 404 Page Not Found: 2020/wp-includes
ERROR - 2024-06-16 05:23:11 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2024-06-16 05:23:11 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2024-06-16 05:23:11 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2024-06-16 05:23:12 --> 404 Page Not Found: Test/wp-includes
ERROR - 2024-06-16 05:23:12 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2024-06-16 05:23:12 --> 404 Page Not Found: Site/wp-includes
ERROR - 2024-06-16 05:23:12 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2024-06-16 05:23:12 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2024-06-16 06:03:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-06-16 06:10:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-06-16 06:31:27 --> 404 Page Not Found: Admin/fileman
ERROR - 2024-06-16 08:17:40 --> 404 Page Not Found: Fileman/php
ERROR - 2024-06-16 19:31:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-06-16 23:33:25 --> 404 Page Not Found: Ckeditor/fileman
