<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-05-24 02:29:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-05-24 09:08:34 --> 404 Page Not Found: Wp-json/litespeed
ERROR - 2024-05-24 10:12:02 --> 404 Page Not Found: Wp-admin/css
ERROR - 2024-05-24 10:12:04 --> 404 Page Not Found: Well-known/index
ERROR - 2024-05-24 10:12:07 --> 404 Page Not Found: Sites/default
ERROR - 2024-05-24 10:12:09 --> 404 Page Not Found: Admin/controller
ERROR - 2024-05-24 10:12:09 --> 404 Page Not Found: Uploads/index
ERROR - 2024-05-24 10:12:10 --> 404 Page Not Found: Files/index
ERROR - 2024-05-24 15:53:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-05-24 15:55:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-05-24 16:05:53 --> 404 Page Not Found: Robotstxt/index
