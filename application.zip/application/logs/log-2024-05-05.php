<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-05-05 00:20:29 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2024-05-05 00:20:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-05-05 00:23:24 --> 404 Page Not Found: Axis2-admin/index
ERROR - 2024-05-05 00:23:25 --> 404 Page Not Found: Axis2/index
ERROR - 2024-05-05 00:23:25 --> 404 Page Not Found: Axis2/axis2-admin
ERROR - 2024-05-05 00:23:27 --> 404 Page Not Found: Phpmyadmin/index.php
ERROR - 2024-05-05 00:23:27 --> 404 Page Not Found: Php/thinkphp
ERROR - 2024-05-05 00:23:28 --> 404 Page Not Found: Index_ssophp/index
ERROR - 2024-05-05 00:46:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-05-05 00:46:12 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2024-05-05 00:46:29 --> 404 Page Not Found: Axis2-admin/index
ERROR - 2024-05-05 00:46:31 --> 404 Page Not Found: Axis2/index
ERROR - 2024-05-05 00:46:32 --> 404 Page Not Found: Axis2/axis2-admin
ERROR - 2024-05-05 00:46:33 --> 404 Page Not Found: Phpmyadmin/index.php
ERROR - 2024-05-05 00:46:34 --> 404 Page Not Found: Php/thinkphp
ERROR - 2024-05-05 00:46:35 --> 404 Page Not Found: Index_ssophp/index
ERROR - 2024-05-05 05:11:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-05-05 05:46:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-05-05 16:02:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-05-05 16:02:30 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2024-05-05 17:14:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-05-05 17:14:17 --> 404 Page Not Found: Sitemaptxt/index
ERROR - 2024-05-05 20:18:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-05-05 21:20:20 --> 404 Page Not Found: Robotstxt/index
