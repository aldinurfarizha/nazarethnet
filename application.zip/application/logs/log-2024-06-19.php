<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-06-19 00:05:27 --> 404 Page Not Found: Mambots/editors
ERROR - 2024-06-19 03:14:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-06-19 03:14:10 --> 404 Page Not Found: Sitemap_indexxml/index
ERROR - 2024-06-19 04:03:35 --> 404 Page Not Found: Sitemap_indexxml/index
ERROR - 2024-06-19 11:47:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-06-19 15:06:09 --> 404 Page Not Found: Php-cgi/php-cgi.exe
ERROR - 2024-06-19 15:06:10 --> 404 Page Not Found: Helloworld/index
ERROR - 2024-06-19 15:06:12 --> 404 Page Not Found: Testphp/index
ERROR - 2024-06-19 15:06:13 --> 404 Page Not Found: Testhello/index
ERROR - 2024-06-19 23:29:12 --> 404 Page Not Found: Robotstxt/index
