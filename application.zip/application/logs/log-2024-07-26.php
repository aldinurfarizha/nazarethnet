<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-07-26 02:28:17 --> Severity: Notice --> session_start(): A session had already been started - ignoring C:\xampp\htdocs\nazarethnet\public\face\config.php 2
ERROR - 2024-07-26 02:28:23 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-26 02:28:23 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-26 02:28:23 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-26 02:28:33 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-26 02:28:33 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-26 02:28:33 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-26 02:28:39 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-26 02:28:39 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-26 02:28:39 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-26 02:28:39 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Bad Request"
}' C:\xampp\htdocs\nazarethnet\public\GoogleSDK\src\Google\Auth\OAuth2.php 378
ERROR - 2024-07-26 02:36:49 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-26 02:36:49 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-26 02:36:49 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-26 02:36:50 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Bad Request"
}' C:\xampp\htdocs\nazarethnet\public\GoogleSDK\src\Google\Auth\OAuth2.php 378
ERROR - 2024-07-26 02:37:22 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-26 02:37:22 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-26 02:37:22 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-26 02:37:22 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Bad Request"
}' C:\xampp\htdocs\nazarethnet\public\GoogleSDK\src\Google\Auth\OAuth2.php 378
ERROR - 2024-07-26 02:39:54 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-26 02:39:54 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-26 02:39:55 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-26 02:55:05 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-26 02:55:05 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-26 02:55:05 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-26 02:55:44 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-26 02:55:44 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-26 02:55:44 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-26 02:56:53 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-26 02:56:53 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-26 02:56:53 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-26 02:58:51 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-26 02:58:51 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-26 02:58:51 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-26 03:00:20 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-26 03:00:20 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-26 03:00:20 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-26 03:00:46 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-26 03:00:46 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-26 03:00:46 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-26 03:00:46 --> Severity: error --> Exception: Object of class Google_Client could not be converted to string C:\xampp\htdocs\nazarethnet\application\views\backend\admin\gdrive.php 93
ERROR - 2024-07-26 03:01:42 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-26 03:01:42 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-26 03:01:42 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-26 03:02:06 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-26 03:02:06 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-26 03:02:06 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-26 03:03:02 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-26 03:03:02 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-26 03:03:02 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-26 03:03:06 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-26 03:03:06 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-26 03:03:07 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-26 03:03:11 --> Severity: error --> Exception: Error calling POST https://www.googleapis.com/drive/v3/files: (404) File not found: 1bjPufD-RRiVHITGK6_D8rH4RIbbXO00_. C:\xampp\htdocs\nazarethnet\public\GoogleSDK\src\Google\Http\REST.php 110
ERROR - 2024-07-26 03:03:22 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-26 03:03:22 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-26 03:03:22 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-26 03:03:27 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-26 03:03:27 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-26 03:03:27 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-26 03:03:29 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-26 03:03:29 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-26 03:03:29 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-26 03:03:42 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-26 03:03:42 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-26 03:03:42 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-26 03:03:42 --> Severity: Notice --> Undefined variable: class_id C:\xampp\htdocs\nazarethnet\application\views\backend\admin\fancy.php 96
ERROR - 2024-07-26 03:03:43 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-26 03:04:16 --> 404 Page Not Found: Public/uploads
ERROR - 2024-07-26 03:42:45 --> Severity: error --> Exception: Could not json decode the token C:\xampp\htdocs\nazarethnet\public\GoogleSDK\src\Google\Auth\OAuth2.php 186
ERROR - 2024-07-26 03:43:43 --> Severity: error --> Exception: Could not json decode the token C:\xampp\htdocs\nazarethnet\public\GoogleSDK\src\Google\Auth\OAuth2.php 186
ERROR - 2024-07-26 03:44:32 --> Severity: error --> Exception: Could not json decode the token C:\xampp\htdocs\nazarethnet\public\GoogleSDK\src\Google\Auth\OAuth2.php 186
ERROR - 2024-07-26 03:45:49 --> Severity: error --> Exception: Could not json decode the token C:\xampp\htdocs\nazarethnet\public\GoogleSDK\src\Google\Auth\OAuth2.php 186
ERROR - 2024-07-26 03:46:08 --> Severity: error --> Exception: Could not json decode the token C:\xampp\htdocs\nazarethnet\public\GoogleSDK\src\Google\Auth\OAuth2.php 186
ERROR - 2024-07-26 03:46:44 --> Severity: error --> Exception: Could not json decode the token C:\xampp\htdocs\nazarethnet\public\GoogleSDK\src\Google\Auth\OAuth2.php 186
ERROR - 2024-07-26 03:46:54 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-26 03:46:54 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-26 03:46:54 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-26 03:46:55 --> Severity: error --> Exception: Could not json decode the token C:\xampp\htdocs\nazarethnet\public\GoogleSDK\src\Google\Auth\OAuth2.php 186
ERROR - 2024-07-26 03:50:17 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-26 03:50:17 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-26 03:50:17 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-26 03:51:01 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-26 03:51:01 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-26 03:51:01 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-26 03:54:01 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-26 03:54:02 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-26 03:54:02 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-26 03:54:46 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-26 03:54:46 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-26 03:54:46 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-26 03:56:10 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-26 03:56:10 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-26 03:56:10 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-26 03:56:37 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-26 03:56:37 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-26 03:56:37 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-26 04:02:58 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-26 04:02:58 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-26 04:02:58 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-26 04:03:45 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-26 04:03:45 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-26 04:03:45 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-26 04:05:26 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-26 04:05:26 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-26 04:05:26 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-26 04:06:00 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-26 04:06:00 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-26 04:06:00 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-26 04:06:18 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-26 04:06:18 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-26 04:06:18 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-26 04:10:13 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-26 04:10:13 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-26 04:10:13 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
ERROR - 2024-07-26 04:16:52 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 71
ERROR - 2024-07-26 04:16:52 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 298
ERROR - 2024-07-26 04:16:52 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\nazarethnet\application\views\backend\admin\navigation.php 549
