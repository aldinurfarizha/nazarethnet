<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-06-25 03:37:00 --> 404 Page Not Found: Sitemapsxml/index
ERROR - 2024-06-25 04:29:20 --> 404 Page Not Found: Sitemapsxml/index
ERROR - 2024-06-25 06:57:41 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2024-06-25 06:57:41 --> 404 Page Not Found: Xmlrpcphp/index
ERROR - 2024-06-25 06:57:41 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2024-06-25 06:57:42 --> 404 Page Not Found: Web/wp-includes
ERROR - 2024-06-25 06:57:42 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2024-06-25 06:57:42 --> 404 Page Not Found: Website/wp-includes
ERROR - 2024-06-25 06:57:42 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2024-06-25 06:57:42 --> 404 Page Not Found: News/wp-includes
ERROR - 2024-06-25 06:57:42 --> 404 Page Not Found: 2018/wp-includes
ERROR - 2024-06-25 06:57:42 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2024-06-25 06:57:42 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2024-06-25 06:57:42 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2024-06-25 06:57:42 --> 404 Page Not Found: Test/wp-includes
ERROR - 2024-06-25 06:57:42 --> 404 Page Not Found: Media/wp-includes
ERROR - 2024-06-25 06:57:42 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2024-06-25 06:57:42 --> 404 Page Not Found: Site/wp-includes
ERROR - 2024-06-25 06:57:42 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2024-06-25 06:57:42 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2024-06-25 07:49:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-06-25 07:49:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-06-25 08:48:59 --> 404 Page Not Found: Admin/ckeditor
ERROR - 2024-06-25 08:55:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-06-25 09:56:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-06-25 13:10:38 --> 404 Page Not Found: Static/sspanel
ERROR - 2024-06-25 14:50:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-06-25 15:48:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-06-25 16:25:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2024-06-25 16:36:19 --> 404 Page Not Found: Public/assets
ERROR - 2024-06-25 17:09:40 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Bad Request"
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-06-25 17:09:45 --> Severity: error --> Exception: Error refreshing the OAuth2 token, message: '{
  "error": "invalid_grant",
  "error_description": "Bad Request"
}' /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Auth/OAuth2.php 378
ERROR - 2024-06-25 17:31:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-06-25 18:13:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2024-06-25 21:41:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2024-06-25 21:42:37 --> 404 Page Not Found: Public/style
ERROR - 2024-06-25 21:42:37 --> 404 Page Not Found: Public/style
ERROR - 2024-06-25 21:42:37 --> 404 Page Not Found: Public/style
ERROR - 2024-06-25 21:42:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2024-06-25 22:09:48 --> 404 Page Not Found: Public/assets
ERROR - 2024-06-25 22:18:00 --> 404 Page Not Found: Public/uploads
ERROR - 2024-06-25 22:22:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-06-25 22:55:31 --> 404 Page Not Found: Public/uploads
