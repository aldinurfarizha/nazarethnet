<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-05-11 04:07:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-05-11 05:50:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-05-11 05:50:49 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2024-05-11 05:51:02 --> 404 Page Not Found: Axis2-admin/index
ERROR - 2024-05-11 05:51:03 --> 404 Page Not Found: Axis2/index
ERROR - 2024-05-11 05:51:03 --> 404 Page Not Found: Axis2/axis2-admin
ERROR - 2024-05-11 05:51:04 --> 404 Page Not Found: Phpmyadmin/index.php
ERROR - 2024-05-11 05:51:05 --> 404 Page Not Found: Php/thinkphp
ERROR - 2024-05-11 05:51:05 --> 404 Page Not Found: Index_ssophp/index
ERROR - 2024-05-11 06:11:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-05-11 06:11:14 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2024-05-11 06:11:15 --> 404 Page Not Found: Axis2-admin/index
ERROR - 2024-05-11 06:11:16 --> 404 Page Not Found: Axis2/index
ERROR - 2024-05-11 06:11:18 --> 404 Page Not Found: Axis2/axis2-admin
ERROR - 2024-05-11 06:11:19 --> 404 Page Not Found: Phpmyadmin/index.php
ERROR - 2024-05-11 06:11:20 --> 404 Page Not Found: Php/thinkphp
ERROR - 2024-05-11 06:11:21 --> 404 Page Not Found: Index_ssophp/index
ERROR - 2024-05-11 09:52:15 --> 404 Page Not Found: Wp-admin/install.php
ERROR - 2024-05-11 09:52:15 --> 404 Page Not Found: Feed/index
ERROR - 2024-05-11 12:18:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2024-05-11 12:19:38 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-11 12:19:38 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-11 12:19:38 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-11 12:19:38 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-11 12:19:46 --> Severity: Warning --> unlink(public/uploads/homework/): Is a directory /home/bosguy7i1szv/public_html/application/models/Crud.php 2652
ERROR - 2024-05-11 12:24:53 --> Severity: error --> Exception: Argument 1 passed to Google_Service_Drive::__construct() must be an instance of Google_Client, string given, called in /home/bosguy7i1szv/public_html/application/models/Drive_model.php on line 16 /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Service/Drive.php 69
ERROR - 2024-05-11 12:24:56 --> Severity: error --> Exception: Argument 1 passed to Google_Service_Drive::__construct() must be an instance of Google_Client, string given, called in /home/bosguy7i1szv/public_html/application/models/Drive_model.php on line 16 /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Service/Drive.php 69
ERROR - 2024-05-11 12:25:25 --> Severity: error --> Exception: Argument 1 passed to Google_Service_Drive::__construct() must be an instance of Google_Client, string given, called in /home/bosguy7i1szv/public_html/application/models/Drive_model.php on line 16 /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Service/Drive.php 69
ERROR - 2024-05-11 12:27:07 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-11 12:27:07 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-11 12:27:07 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-11 12:29:17 --> Severity: error --> Exception: Argument 1 passed to Google_Service_Drive::__construct() must be an instance of Google_Client, string given, called in /home/bosguy7i1szv/public_html/application/models/Drive_model.php on line 16 /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Service/Drive.php 69
ERROR - 2024-05-11 12:29:21 --> Severity: error --> Exception: Argument 1 passed to Google_Service_Drive::__construct() must be an instance of Google_Client, string given, called in /home/bosguy7i1szv/public_html/application/models/Drive_model.php on line 16 /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Service/Drive.php 69
ERROR - 2024-05-11 12:29:31 --> Severity: error --> Exception: Argument 1 passed to Google_Service_Drive::__construct() must be an instance of Google_Client, string given, called in /home/bosguy7i1szv/public_html/application/models/Drive_model.php on line 16 /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Service/Drive.php 69
ERROR - 2024-05-11 12:29:39 --> Severity: error --> Exception: Argument 1 passed to Google_Service_Drive::__construct() must be an instance of Google_Client, string given, called in /home/bosguy7i1szv/public_html/application/models/Drive_model.php on line 16 /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Service/Drive.php 69
ERROR - 2024-05-11 12:30:07 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-11 12:31:21 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-11 12:31:34 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-11 12:31:34 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-11 12:31:34 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-11 12:31:34 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-11 12:31:42 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-11 12:33:04 --> Severity: error --> Exception: Argument 1 passed to Google_Service_Drive::__construct() must be an instance of Google_Client, string given, called in /home/bosguy7i1szv/public_html/application/models/Drive_model.php on line 16 /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Service/Drive.php 69
ERROR - 2024-05-11 12:34:08 --> Severity: error --> Exception: Argument 1 passed to Google_Service_Drive::__construct() must be an instance of Google_Client, string given, called in /home/bosguy7i1szv/public_html/application/models/Drive_model.php on line 16 /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Service/Drive.php 69
ERROR - 2024-05-11 12:34:18 --> Severity: error --> Exception: Argument 1 passed to Google_Service_Drive::__construct() must be an instance of Google_Client, string given, called in /home/bosguy7i1szv/public_html/application/models/Drive_model.php on line 16 /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Service/Drive.php 69
ERROR - 2024-05-11 12:34:22 --> Severity: error --> Exception: Argument 1 passed to Google_Service_Drive::__construct() must be an instance of Google_Client, string given, called in /home/bosguy7i1szv/public_html/application/models/Drive_model.php on line 16 /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Service/Drive.php 69
ERROR - 2024-05-11 12:36:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2024-05-11 12:40:30 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-11 12:40:49 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-11 12:41:34 --> Severity: error --> Exception: Argument 1 passed to Google_Service_Drive::__construct() must be an instance of Google_Client, string given, called in /home/bosguy7i1szv/public_html/application/models/Drive_model.php on line 16 /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Service/Drive.php 69
ERROR - 2024-05-11 12:41:36 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-11 12:42:08 --> Severity: error --> Exception: Argument 1 passed to Google_Service_Drive::__construct() must be an instance of Google_Client, string given, called in /home/bosguy7i1szv/public_html/application/models/Drive_model.php on line 16 /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Service/Drive.php 69
ERROR - 2024-05-11 12:42:35 --> Severity: error --> Exception: Argument 1 passed to Google_Service_Drive::__construct() must be an instance of Google_Client, string given, called in /home/bosguy7i1szv/public_html/application/models/Drive_model.php on line 16 /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Service/Drive.php 69
ERROR - 2024-05-11 12:42:39 --> Severity: error --> Exception: Argument 1 passed to Google_Service_Drive::__construct() must be an instance of Google_Client, string given, called in /home/bosguy7i1szv/public_html/application/models/Drive_model.php on line 16 /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Service/Drive.php 69
ERROR - 2024-05-11 12:42:52 --> Severity: error --> Exception: Argument 1 passed to Google_Service_Drive::__construct() must be an instance of Google_Client, string given, called in /home/bosguy7i1szv/public_html/application/models/Drive_model.php on line 16 /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Service/Drive.php 69
ERROR - 2024-05-11 12:45:00 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-11 12:45:31 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-11 12:45:52 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-11 12:46:21 --> Severity: error --> Exception: Argument 1 passed to Google_Service_Drive::__construct() must be an instance of Google_Client, string given, called in /home/bosguy7i1szv/public_html/application/models/Drive_model.php on line 16 /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Service/Drive.php 69
ERROR - 2024-05-11 12:46:26 --> Severity: error --> Exception: Argument 1 passed to Google_Service_Drive::__construct() must be an instance of Google_Client, string given, called in /home/bosguy7i1szv/public_html/application/models/Drive_model.php on line 16 /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Service/Drive.php 69
ERROR - 2024-05-11 12:46:28 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-11 12:46:41 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-11 12:46:49 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-11 12:46:54 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-11 12:46:54 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-11 12:46:55 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-11 12:46:55 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-11 12:47:00 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-11 12:47:50 --> Severity: error --> Exception: Argument 1 passed to Google_Service_Drive::__construct() must be an instance of Google_Client, string given, called in /home/bosguy7i1szv/public_html/application/models/Drive_model.php on line 16 /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Service/Drive.php 69
ERROR - 2024-05-11 12:47:54 --> Severity: error --> Exception: Argument 1 passed to Google_Service_Drive::__construct() must be an instance of Google_Client, string given, called in /home/bosguy7i1szv/public_html/application/models/Drive_model.php on line 16 /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Service/Drive.php 69
ERROR - 2024-05-11 12:51:37 --> Severity: error --> Exception: Argument 1 passed to Google_Service_Drive::__construct() must be an instance of Google_Client, string given, called in /home/bosguy7i1szv/public_html/application/models/Drive_model.php on line 16 /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Service/Drive.php 69
ERROR - 2024-05-11 12:53:17 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-11 12:53:33 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-11 12:53:41 --> Severity: error --> Exception: Argument 1 passed to Google_Service_Drive::__construct() must be an instance of Google_Client, string given, called in /home/bosguy7i1szv/public_html/application/models/Drive_model.php on line 16 /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Service/Drive.php 69
ERROR - 2024-05-11 12:54:31 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-11 12:54:34 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-11 12:54:39 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-11 12:54:39 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-11 12:55:15 --> Severity: error --> Exception: Argument 1 passed to Google_Service_Drive::__construct() must be an instance of Google_Client, string given, called in /home/bosguy7i1szv/public_html/application/models/Drive_model.php on line 16 /home/bosguy7i1szv/public_html/public/GoogleSDK/src/Google/Service/Drive.php 69
ERROR - 2024-05-11 12:58:25 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, string given /home/bosguy7i1szv/public_html/application/controllers/Authorizeapp.php 44
ERROR - 2024-05-11 12:58:53 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-11 12:58:53 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-11 12:58:53 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-11 12:58:53 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-11 12:58:57 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-11 13:01:01 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-11 13:01:02 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-11 13:01:02 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-11 13:01:02 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-11 13:03:45 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-11 13:03:45 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-11 13:03:45 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-11 13:03:45 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-11 13:03:56 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-11 13:03:56 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-11 13:03:56 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-11 13:03:56 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-11 13:04:29 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-11 13:04:29 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-11 13:04:29 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-11 13:04:29 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-11 13:04:48 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-11 13:04:48 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-11 13:04:48 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-11 13:04:48 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-11 13:04:58 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-11 13:04:58 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-11 13:04:58 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-11 13:04:58 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-11 13:05:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2024-05-11 13:08:47 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-11 13:08:47 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-11 13:08:47 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-11 13:08:47 --> 404 Page Not Found: Public/uploads
ERROR - 2024-05-11 13:31:22 --> Severity: error --> Exception: Class 'Twilio\Rest\Client' not found /home/bosguy7i1szv/public_html/application/models/Crud.php 2184
ERROR - 2024-05-11 14:56:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2024-05-11 16:05:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2024-05-11 19:44:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-05-11 19:45:01 --> 404 Page Not Found: Sitemap_indexxml/index
ERROR - 2024-05-11 20:56:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2024-05-11 22:19:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2024-05-11 22:57:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2024-05-11 22:57:41 --> 404 Page Not Found: Sitemapsxml/index
ERROR - 2024-05-11 22:59:22 --> 404 Page Not Found: Sitemapsxml/index
