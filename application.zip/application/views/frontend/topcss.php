    <link href="<?php echo base_url();?>public/assets/frontend/icon_fonts_assets/picons-thin/style.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Poppins&display=swap" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>public/assets/frontend/css.css">
    <link rel="stylesheet" href="<?php echo base_url();?>public/assets/frontend/dist/css/lightbox.min.css">