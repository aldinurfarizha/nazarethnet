    <div class="modal-body">
         <div class="ui-block-title mdl-header">
          <h6 class="title text-white"><?php echo getEduAppGTLang('image');?></h6>
        </div>
        <div class="ui-block-content">
            <div class="row">
                <div class="col col-lg-12 col-md-12 col-sm-12 col-12">
                   <center><img src="<?php echo base_url();?>public/uploads/online_exam/<?php echo $param2;?>"></center>
                </div>
            </div>
        </div>
    </div>