    <div class="full-chat-middle">
        <div class="">
            <div class="">
    			<div class="centeredu">
    				<img src="<?php echo base_url();?>public/uploads/mensajeseducaby.svg" class="chat-home"><br>			   
            	</div>                        
          	</div>
    	</div>
    </div>