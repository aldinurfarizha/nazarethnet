    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="crearadmin" aria-hidden="true">
        <div class="modal-dialog window-popup edit-my-poll-popup" role="document">
            <div class="modal-content tp50">
                <a href="#" class="close icon-close" data-dismiss="modal" aria-label="Close"></a>
                <div class="modal-body">
                    <div class="modal-header mdl-header">
                        <h6 class="title text-white"><?php echo $this->crud->getInfo('system_name');?></h6>
                    </div>
                </div>
            </div>
        </div>
    </div>