    <script src="<?php echo base_url();?>public/style/js/Chart.bundle.js"></script>
    <link href="https://fonts.googleapis.com/css?family=Rubik:300,400,500" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
    <link rel='stylesheet' type='text/css' href='<?php echo base_url();?>public/style/fullcalendar/lib/main.min.css'/>
    <link href="<?php echo base_url();?>public/style/picker.css" rel="stylesheet" type="text/css">
    <link href="<?php echo base_url()?>public/style/cms/icon_fonts_assets/themefy/themify-icons.css" rel="stylesheet">
    <link href="<?php echo base_url()?>public/style/cms/bower_components/bootstrap-clockpicker/bootstrap-clockpicker.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>public/style/olapp/Bootstrap/dist/css/bootstrap-reboot.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>public/style/olapp/Bootstrap/dist/css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>public/style/olapp/Bootstrap/dist/css/bootstrap-grid.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>public/style/olapp/css/main.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>public/style/olapp/css/fonts.min.css">
    <link href="<?php echo base_url();?>public/style/cms/bower_components/perfect-scrollbar/css/perfect-scrollbar.min.css" rel="stylesheet">
    <link href="<?php echo base_url();?>public/style/cms/icon_fonts_assets/picons-thin/style.css" rel="stylesheet">
    <link href="<?php echo base_url();?>public/style/cms/icon_fonts_assets/simple-line-icons/css/simple-line-icons.css" rel="stylesheet">
    <link href="<?php echo base_url();?>public/style/cms/icon_fonts_assets/picons-social/style.css" rel="stylesheet">
	<link href="<?php echo base_url();?>public/style/cms/icon_fonts_assets/feather/style.css" rel="stylesheet">
    <script src="<?php echo base_url();?>public/style/js//dropzone.min.js"></script>
    <link rel="stylesheet" href="<?php echo base_url();?>public/style/cms//css/dropzone.min.css" type="text/css" />