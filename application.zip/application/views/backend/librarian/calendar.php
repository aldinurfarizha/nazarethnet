    <div class="content-w" > 
        <?php include 'fancy.php';?>
        <div class="header-spacer"></div>
        <div class="conty"><br>
            <div class="container-fluid">
                <div class="layout-w">
                    <div class="content-w">
                        <div class="container-fluid"> 
                            <div class="element-box">
                                <h3 class="form-header"><?php echo getEduAppGTLang('calendar_events');?></h3><br>
                                <div class="table-responsive">
                                    <div id="calendar" class="col-centered"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="display-type"></div>
            </div>
        </div>
    </div>