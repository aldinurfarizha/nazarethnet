    <div class="full-chat-middle">
        <div class="">
            <div class="">
    			<div class="centeredu">
    				<img src="<?php echo base_url();?>public/uploads/mensajeseducaby.svg" class="chat-home">	<br>			   
    			    <a href="<?php echo base_url();?>librarian/message/message_new/" class="msjsbtn mt"><span><?php echo getEduAppGTLang('create_message');?></span><i class="picons-thin-icon-thin-0317_send_post_paper_plane"></i></a>				   
            	</div>                        
          	</div>
    	</div>
    </div>