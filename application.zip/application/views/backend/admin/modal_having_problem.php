<div class="modal-body">
    <div class="modal-header mdl-header">
        <h6 class="title text-white">Having Problem ? auto update file to google drive not working</h6>
    </div>
    <div class="ui-block-content">
        <div class="row">
           <div class="col-md-12">
            <p>Some time google drive need create new folder on your drive account, you can create new folder on your google drive account without loosing your exiting folder and data, this function will create new.</p>
           </div>
           <div class="col-md-12">
           <a class="btn btn-warning full-width" href="<?php echo base_url(); ?>admin/generategdrive">
                                                            Create New Folder On Gdrive Account
                                                        </a>
           </div>
        </div>
    </div>
</div>